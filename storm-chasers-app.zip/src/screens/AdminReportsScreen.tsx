import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, Alert, Modal, TextInput } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useAdminStore } from '../state/admin';
import { Report } from '../types';

export default function AdminReportsScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const { reports, resolveReport } = useAdminStore();

  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'investigating' | 'resolved'>('all');
  const [filterPriority, setFilterPriority] = useState<'all' | 'urgent' | 'high' | 'medium' | 'low'>('all');
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [showReportModal, setShowReportModal] = useState(false);
  const [resolution, setResolution] = useState('');

  const filteredReports = reports.filter(report => {
    const matchesStatus = filterStatus === 'all' || report.status === filterStatus;
    const matchesPriority = filterPriority === 'all' || report.priority === filterPriority;
    return matchesStatus && matchesPriority;
  });

  const handleResolveReport = async () => {
    if (!selectedReport || !resolution.trim()) return;
    
    const success = await resolveReport(selectedReport.id, resolution.trim());
    if (success) {
      setShowReportModal(false);
      setResolution('');
      Alert.alert('Success', 'Report has been resolved successfully.');
    } else {
      Alert.alert('Error', 'Failed to resolve report. Please try again.');
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return '#ef4444';
      case 'high': return '#f59e0b';
      case 'medium': return '#0ea5e9';
      case 'low': return '#10b981';
      default: return '#64748b';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return '#f59e0b';
      case 'investigating': return '#0ea5e9';
      case 'resolved': return '#10b981';
      case 'dismissed': return '#64748b';
      default: return '#64748b';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'inappropriate_content': return 'warning';
      case 'harassment': return 'person-remove';
      case 'spam': return 'mail-unread';
      case 'fake_alert': return 'alert-circle';
      case 'other': return 'help-circle';
      default: return 'flag';
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h ago`;
    if (hours < 168) return `${Math.floor(hours / 24)}d ago`;
    return date.toLocaleDateString();
  };

  return (
    <>
      <View className="flex-1 bg-storm-900" style={{ paddingTop: insets.top }}>
        {/* Header */}
        <View className="px-4 py-6 bg-storm-800 border-b border-storm-700">
          <View className="flex-row items-center">
            <Pressable onPress={() => navigation.goBack()} className="mr-4">
              <Ionicons name="chevron-back" size={24} color="#0ea5e9" />
            </Pressable>
            <View>
              <Text className="text-2xl font-bold text-storm-50">Reports & Moderation</Text>
              <Text className="text-lightning-300 mt-1">{filteredReports.length} reports</Text>
            </View>
          </View>
        </View>

        {/* Filters */}
        <View className="p-4 bg-storm-800 border-b border-storm-700">
          <Text className="text-storm-300 text-sm mb-3">Status Filter</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} className="mb-4">
            {['all', 'pending', 'investigating', 'resolved'].map((status) => (
              <Pressable
                key={status}
                onPress={() => setFilterStatus(status as any)}
                className={`mr-3 px-4 py-2 rounded-full border ${
                  filterStatus === status
                    ? 'bg-lightning-500 border-lightning-500'
                    : 'bg-transparent border-storm-600'
                }`}
              >
                <Text className={`text-sm font-medium ${
                  filterStatus === status ? 'text-white' : 'text-storm-300'
                }`}>
                  {status.charAt(0).toUpperCase() + status.slice(1)}
                </Text>
              </Pressable>
            ))}
          </ScrollView>
          
          <Text className="text-storm-300 text-sm mb-3">Priority Filter</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {['all', 'urgent', 'high', 'medium', 'low'].map((priority) => (
              <Pressable
                key={priority}
                onPress={() => setFilterPriority(priority as any)}
                className={`mr-3 px-4 py-2 rounded-full border ${
                  filterPriority === priority
                    ? 'bg-lightning-500 border-lightning-500'
                    : 'bg-transparent border-storm-600'
                }`}
              >
                <Text className={`text-sm font-medium ${
                  filterPriority === priority ? 'text-white' : 'text-storm-300'
                }`}>
                  {priority.charAt(0).toUpperCase() + priority.slice(1)}
                </Text>
              </Pressable>
            ))}
          </ScrollView>
        </View>

        {/* Reports List */}
        <ScrollView className="flex-1">
          {filteredReports.map((report) => (
            <Pressable
              key={report.id}
              onPress={() => {
                setSelectedReport(report);
                setShowReportModal(true);
              }}
              className="p-4 border-b border-storm-700 bg-storm-900"
            >
              <View className="flex-row items-start">
                <View className="mr-3 mt-1">
                  <Ionicons 
                    name={getTypeIcon(report.type)} 
                    size={20} 
                    color={getPriorityColor(report.priority)} 
                  />
                </View>
                
                <View className="flex-1">
                  <View className="flex-row items-center justify-between mb-2">
                    <Text className="text-storm-50 font-semibold">{report.reason}</Text>
                    <Text className="text-storm-500 text-xs">{formatTimeAgo(report.createdAt)}</Text>
                  </View>
                  
                  <Text className="text-storm-300 text-sm mb-3" numberOfLines={2}>
                    {report.description}
                  </Text>
                  
                  <View className="flex-row items-center justify-between">
                    <View className="flex-row items-center">
                      <View 
                        className="px-2 py-1 rounded-full mr-2"
                        style={{ backgroundColor: getPriorityColor(report.priority) + '20' }}
                      >
                        <Text 
                          className="text-xs font-medium capitalize"
                          style={{ color: getPriorityColor(report.priority) }}
                        >
                          {report.priority}
                        </Text>
                      </View>
                      
                      <View 
                        className="px-2 py-1 rounded-full"
                        style={{ backgroundColor: getStatusColor(report.status) + '20' }}
                      >
                        <Text 
                          className="text-xs font-medium capitalize"
                          style={{ color: getStatusColor(report.status) }}
                        >
                          {report.status}
                        </Text>
                      </View>
                    </View>
                    
                    <Ionicons name="chevron-forward" size={16} color="#64748b" />
                  </View>
                </View>
              </View>
            </Pressable>
          ))}
          
          {filteredReports.length === 0 && (
            <View className="p-8 items-center">
              <Ionicons name="checkmark-circle" size={48} color="#10b981" />
              <Text className="text-storm-400 text-center mt-4">
                No reports found matching your criteria
              </Text>
            </View>
          )}
        </ScrollView>
      </View>

      {/* Report Details Modal */}
      <Modal
        visible={showReportModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View className="flex-1 bg-storm-900" style={{ paddingTop: insets.top }}>
          {selectedReport && (
            <>
              <View className="flex-row items-center justify-between p-4 border-b border-storm-700">
                <Text className="text-lg font-semibold text-storm-50">Report Details</Text>
                <Pressable onPress={() => setShowReportModal(false)}>
                  <Ionicons name="close" size={24} color="#64748b" />
                </Pressable>
              </View>
              
              <ScrollView className="flex-1 p-4">
                {/* Report Info */}
                <View className="bg-storm-800 rounded-lg p-4 border border-storm-700 mb-4">
                  <View className="flex-row items-center mb-3">
                    <Ionicons 
                      name={getTypeIcon(selectedReport.type)} 
                      size={24} 
                      color={getPriorityColor(selectedReport.priority)} 
                    />
                    <Text className="text-storm-50 font-bold text-lg ml-3">{selectedReport.reason}</Text>
                  </View>
                  
                  <View className="space-y-3">
                    <View>
                      <Text className="text-storm-400 text-sm">Type:</Text>
                      <Text className="text-storm-50">{selectedReport.type.replace('_', ' ')}</Text>
                    </View>
                    
                    <View>
                      <Text className="text-storm-400 text-sm">Description:</Text>
                      <Text className="text-storm-50">{selectedReport.description}</Text>
                    </View>
                    
                    <View className="flex-row justify-between">
                      <View>
                        <Text className="text-storm-400 text-sm">Priority:</Text>
                        <Text 
                          className="font-medium capitalize"
                          style={{ color: getPriorityColor(selectedReport.priority) }}
                        >
                          {selectedReport.priority}
                        </Text>
                      </View>
                      <View>
                        <Text className="text-storm-400 text-sm">Status:</Text>
                        <Text 
                          className="font-medium capitalize"
                          style={{ color: getStatusColor(selectedReport.status) }}
                        >
                          {selectedReport.status}
                        </Text>
                      </View>
                    </View>
                    
                    <View>
                      <Text className="text-storm-400 text-sm">Reported:</Text>
                      <Text className="text-storm-50">{selectedReport.createdAt.toLocaleString()}</Text>
                    </View>
                    
                    {selectedReport.resolvedAt && (
                      <View>
                        <Text className="text-storm-400 text-sm">Resolved:</Text>
                        <Text className="text-storm-50">{selectedReport.resolvedAt.toLocaleString()}</Text>
                      </View>
                    )}
                  </View>
                </View>

                {/* Resolution */}
                {selectedReport.status === 'resolved' ? (
                  <View className="bg-green-900 rounded-lg p-4 border border-green-700">
                    <Text className="text-green-300 font-semibold mb-2">Resolution</Text>
                    <Text className="text-green-200">{selectedReport.resolution}</Text>
                  </View>
                ) : (
                  <View className="bg-storm-800 rounded-lg p-4 border border-storm-700">
                    <Text className="text-storm-50 font-semibold mb-3">Resolve Report</Text>
                    
                    <TextInput
                      value={resolution}
                      onChangeText={setResolution}
                      placeholder="Enter resolution details..."
                      placeholderTextColor="#64748b"
                      className="bg-storm-700 border border-storm-600 rounded-lg px-4 py-3 text-storm-50 mb-4"
                      multiline
                      numberOfLines={4}
                    />
                    
                    <Pressable
                      onPress={handleResolveReport}
                      disabled={!resolution.trim()}
                      className={`py-3 rounded-lg ${
                        resolution.trim() ? 'bg-green-600' : 'bg-storm-600'
                      }`}
                    >
                      <Text className="text-white font-semibold text-center">
                        Mark as Resolved
                      </Text>
                    </Pressable>
                  </View>
                )}
              </ScrollView>
            </>
          )}
        </View>
      </Modal>
    </>
  );
}