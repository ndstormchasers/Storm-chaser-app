import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Pressable, TextInput, KeyboardAvoidingView, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { useStormChaserStore } from '../state/stormChasers';
import { RootStackParamList, Chat } from '../types';

type StreamDetailScreenNavigationProp = NativeStackNavigationProp<RootStackParamList, 'StreamDetail'>;
type StreamDetailScreenRouteProp = RouteProp<RootStackParamList, 'StreamDetail'>;

export default function StreamDetailScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<StreamDetailScreenNavigationProp>();
  const route = useRoute<StreamDetailScreenRouteProp>();
  const { streamId } = route.params;
  
  const { chasers, liveStreams, chats, addChat, updateViewerCount } = useStormChaserStore();
  const [chatMessage, setChatMessage] = useState('');
  const [isFollowing, setIsFollowing] = useState(false);

  const stream = liveStreams.find(s => s.id === streamId);
  const chaser = stream ? chasers.find(c => c.id === stream.chaserId) : null;
  const streamChats = chats.filter(c => c.streamId === streamId);

  // Simulate viewer count updates
  useEffect(() => {
    if (stream) {
      const interval = setInterval(() => {
        const change = Math.floor(Math.random() * 10) - 5;
        updateViewerCount(stream.id, Math.max(0, stream.viewers + change));
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [stream?.id]);

  const sendMessage = () => {
    if (chatMessage.trim() && stream) {
      const newChat: Chat = {
        id: Date.now().toString(),
        streamId: stream.id,
        userId: 'current-user',
        username: 'You',
        message: chatMessage.trim(),
        timestamp: new Date(),
      };
      addChat(newChat);
      setChatMessage('');
    }
  };

  if (!stream || !chaser) {
    return (
      <View className="flex-1 items-center justify-center bg-gray-50">
        <Text className="text-gray-600">Stream not found</Text>
      </View>
    );
  }

  const streamDuration = Math.floor((Date.now() - stream.startTime.getTime()) / 60000);

  return (
    <KeyboardAvoidingView 
      className="flex-1 bg-gray-50"
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView className="flex-1">
        {/* Stream Video Placeholder */}
        <View className="bg-black aspect-video items-center justify-center">
          <Text className="text-8xl">{stream.thumbnail}</Text>
          <View className="absolute top-4 left-4 bg-red-500 px-2 py-1 rounded">
            <Text className="text-white text-xs font-bold">LIVE</Text>
          </View>
          <View className="absolute top-4 right-4 bg-black bg-opacity-50 px-2 py-1 rounded">
            <Text className="text-white text-xs">{stream.viewers.toLocaleString()} viewers</Text>
          </View>
        </View>

        {/* Stream Info */}
        <View className="bg-white p-4 border-b border-gray-200">
          <Text className="text-lg font-semibold text-gray-900 mb-2">{stream.title}</Text>
          <Text className="text-gray-600 mb-3">{stream.description}</Text>
          
          <View className="flex-row items-center justify-between">
            <View className="flex-row items-center">
              <View className="w-10 h-10 bg-red-100 rounded-full items-center justify-center">
                <Text className="text-xl">{chaser.avatar}</Text>
              </View>
              <View className="ml-3">
                <Text className="font-medium text-gray-900">{chaser.name}</Text>
                <Text className="text-sm text-gray-600">{streamDuration}m ago</Text>
              </View>
            </View>
            <Pressable
              onPress={() => setIsFollowing(!isFollowing)}
              className={`px-4 py-2 rounded-full ${
                isFollowing ? 'bg-gray-200' : 'bg-red-500'
              }`}
            >
              <Text className={`font-medium ${
                isFollowing ? 'text-gray-700' : 'text-white'
              }`}>
                {isFollowing ? 'Following' : 'Follow'}
              </Text>
            </Pressable>
          </View>
        </View>

        {/* Stream Details */}
        <View className="bg-white p-4 mb-4 border-b border-gray-200">
          <View className="flex-row items-center justify-between mb-3">
            <View className="flex-row items-center">
              <Ionicons name="location" size={16} color="#6b7280" />
              <Text className="text-sm text-gray-600 ml-2">{stream.location}</Text>
            </View>
            <View className="flex-row items-center">
              <Ionicons name="thunderstorm" size={16} color="#6b7280" />
              <Text className="text-sm text-gray-600 ml-2">{stream.weatherCondition}</Text>
            </View>
          </View>
          {stream.platform && (
            <View className="flex-row items-center mb-3">
              <Text className="text-lg mr-2">
                {stream.platform === 'youtube' ? '📺' : stream.platform === 'twitch' ? '🎮' : '📡'}
              </Text>
              <Text className="text-sm text-gray-600">
                Streaming on {stream.platform === 'youtube' ? 'YouTube Live' : stream.platform === 'twitch' ? 'Twitch' : 'Live Platform'}
              </Text>
            </View>
          )}
          <Pressable
            onPress={() => navigation.navigate('Profile', { chaserId: chaser.id })}
            className="flex-row items-center justify-between"
          >
            <Text className="text-blue-600 font-medium">View {chaser.name}'s Profile</Text>
            <Ionicons name="chevron-forward" size={16} color="#3b82f6" />
          </Pressable>
        </View>

        {/* Chat Section */}
        <View className="bg-white p-4">
          <Text className="font-semibold text-gray-900 mb-3">
            Live Chat ({streamChats.length})
          </Text>
          <View className="space-y-2 mb-4">
            {streamChats.length > 0 ? (
              streamChats.map((chat) => (
                <View key={chat.id} className="flex-row">
                  <Text className="font-medium text-gray-900">{chat.username}: </Text>
                  <Text className="text-gray-600 flex-1">{chat.message}</Text>
                </View>
              ))
            ) : (
              <Text className="text-gray-500 text-center py-4">
                No messages yet. Be the first to chat!
              </Text>
            )}
          </View>
        </View>
      </ScrollView>

      {/* Chat Input */}
      <View className="bg-white border-t border-gray-200 p-4" style={{ paddingBottom: insets.bottom }}>
        <View className="flex-row items-center">
          <TextInput
            value={chatMessage}
            onChangeText={setChatMessage}
            placeholder="Type a message..."
            className="flex-1 bg-gray-100 rounded-full px-4 py-2 mr-2"
            returnKeyType="send"
            onSubmitEditing={sendMessage}
          />
          <Pressable
            onPress={sendMessage}
            className="bg-red-500 rounded-full p-2"
            disabled={!chatMessage.trim()}
          >
            <Ionicons name="send" size={20} color="white" />
          </Pressable>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}