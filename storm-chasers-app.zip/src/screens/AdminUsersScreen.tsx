import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, Alert, Modal, TextInput } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useAdminStore } from '../state/admin';
import { User } from '../types';

export default function AdminUsersScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const {
    allUsers,
    updateUserStatus,
    updateUserRole,
    verifyUser,
    deleteUser,
  } = useAdminStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'suspended' | 'banned'>('all');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [showUserModal, setShowUserModal] = useState(false);

  const filteredUsers = allUsers.filter(user => {
    const matchesSearch = user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         `${user.firstName} ${user.lastName}`.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || user.status === filterStatus;
    
    return matchesSearch && matchesStatus;
  });

  const handleUserAction = (user: User, action: string) => {
    setSelectedUser(user);
    
    switch (action) {
      case 'suspend':
        Alert.alert(
          'Suspend User',
          `Are you sure you want to suspend @${user.username}?`,
          [
            { text: 'Cancel', style: 'cancel' },
            { 
              text: 'Suspend', 
              style: 'destructive',
              onPress: () => updateUserStatus(user.id, 'suspended')
            },
          ]
        );
        break;
      case 'activate':
        updateUserStatus(user.id, 'active');
        break;
      case 'ban':
        Alert.alert(
          'Ban User',
          `Are you sure you want to permanently ban @${user.username}? This action cannot be undone.`,
          [
            { text: 'Cancel', style: 'cancel' },
            { 
              text: 'Ban', 
              style: 'destructive',
              onPress: () => updateUserStatus(user.id, 'banned')
            },
          ]
        );
        break;
      case 'verify':
        verifyUser(user.id, !user.isVerified);
        break;
      case 'delete':
        Alert.alert(
          'Delete User',
          `Are you sure you want to permanently delete @${user.username}? This action cannot be undone.`,
          [
            { text: 'Cancel', style: 'cancel' },
            { 
              text: 'Delete', 
              style: 'destructive',
              onPress: () => deleteUser(user.id)
            },
          ]
        );
        break;
      case 'details':
        setShowUserModal(true);
        break;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return '#10b981';
      case 'suspended': return '#f59e0b';
      case 'banned': return '#ef4444';
      default: return '#64748b';
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return '#8b5cf6';
      case 'moderator': return '#0ea5e9';
      case 'user': return '#64748b';
      default: return '#64748b';
    }
  };

  const formatLastActive = (date?: Date) => {
    if (!date) return 'Never';
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h ago`;
    if (hours < 168) return `${Math.floor(hours / 24)}d ago`;
    return date.toLocaleDateString();
  };

  return (
    <>
      <View className="flex-1 bg-storm-900" style={{ paddingTop: insets.top }}>
        {/* Header */}
        <View className="px-4 py-6 bg-storm-800 border-b border-storm-700">
          <View className="flex-row items-center">
            <Pressable onPress={() => navigation.goBack()} className="mr-4">
              <Ionicons name="chevron-back" size={24} color="#0ea5e9" />
            </Pressable>
            <View>
              <Text className="text-2xl font-bold text-storm-50">User Management</Text>
              <Text className="text-lightning-300 mt-1">{filteredUsers.length} users</Text>
            </View>
          </View>
        </View>

        {/* Search and Filters */}
        <View className="p-4 bg-storm-800 border-b border-storm-700">
          <View className="mb-4">
            <TextInput
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Search users..."
              placeholderTextColor="#64748b"
              className="bg-storm-700 border border-storm-600 rounded-lg px-4 py-3 text-storm-50"
            />
          </View>
          
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {['all', 'active', 'suspended', 'banned'].map((status) => (
              <Pressable
                key={status}
                onPress={() => setFilterStatus(status as any)}
                className={`mr-3 px-4 py-2 rounded-full border ${
                  filterStatus === status
                    ? 'bg-lightning-500 border-lightning-500'
                    : 'bg-transparent border-storm-600'
                }`}
              >
                <Text className={`text-sm font-medium ${
                  filterStatus === status ? 'text-white' : 'text-storm-300'
                }`}>
                  {status.charAt(0).toUpperCase() + status.slice(1)}
                </Text>
              </Pressable>
            ))}
          </ScrollView>
        </View>

        {/* Users List */}
        <ScrollView className="flex-1">
          {filteredUsers.map((user) => (
            <View key={user.id} className="border-b border-storm-700">
              <Pressable
                onPress={() => handleUserAction(user, 'details')}
                className="p-4 bg-storm-900"
              >
                <View className="flex-row items-center">
                  <View className="w-12 h-12 bg-storm-700 rounded-full items-center justify-center">
                    <Text className="text-xl">{user.avatar}</Text>
                  </View>
                  
                  <View className="flex-1 ml-3">
                    <View className="flex-row items-center">
                      <Text className="text-storm-50 font-semibold">{user.firstName} {user.lastName}</Text>
                      {user.isVerified && (
                        <Ionicons name="checkmark-circle" size={16} color="#10b981" style={{ marginLeft: 4 }} />
                      )}
                    </View>
                    <Text className="text-storm-400 text-sm">@{user.username}</Text>
                    <Text className="text-storm-500 text-xs">{user.email}</Text>
                    
                    <View className="flex-row items-center mt-2">
                      <View 
                        className="px-2 py-1 rounded-full mr-2"
                        style={{ backgroundColor: getStatusColor(user.status || 'active') + '20' }}
                      >
                        <Text 
                          className="text-xs font-medium capitalize"
                          style={{ color: getStatusColor(user.status || 'active') }}
                        >
                          {user.status || 'active'}
                        </Text>
                      </View>
                      
                      <View 
                        className="px-2 py-1 rounded-full mr-2"
                        style={{ backgroundColor: getRoleColor(user.role || 'user') + '20' }}
                      >
                        <Text 
                          className="text-xs font-medium capitalize"
                          style={{ color: getRoleColor(user.role || 'user') }}
                        >
                          {user.role || 'user'}
                        </Text>
                      </View>
                      
                      <Text className="text-storm-500 text-xs">
                        Active: {formatLastActive(user.lastActive)}
                      </Text>
                    </View>
                  </View>
                  
                  <Ionicons name="chevron-forward" size={20} color="#64748b" />
                </View>
              </Pressable>
            </View>
          ))}
          
          {filteredUsers.length === 0 && (
            <View className="p-8 items-center">
              <Ionicons name="people" size={48} color="#64748b" />
              <Text className="text-storm-400 text-center mt-4">
                No users found matching your criteria
              </Text>
            </View>
          )}
        </ScrollView>
      </View>

      {/* User Details Modal */}
      <Modal
        visible={showUserModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View className="flex-1 bg-storm-900" style={{ paddingTop: insets.top }}>
          {selectedUser && (
            <>
              <View className="flex-row items-center justify-between p-4 border-b border-storm-700">
                <Text className="text-lg font-semibold text-storm-50">User Details</Text>
                <Pressable onPress={() => setShowUserModal(false)}>
                  <Ionicons name="close" size={24} color="#64748b" />
                </Pressable>
              </View>
              
              <ScrollView className="flex-1 p-4">
                {/* User Info */}
                <View className="bg-storm-800 rounded-lg p-4 border border-storm-700 mb-4">
                  <View className="items-center mb-4">
                    <View className="w-20 h-20 bg-storm-700 rounded-full items-center justify-center mb-3">
                      <Text className="text-3xl">{selectedUser.avatar}</Text>
                    </View>
                    <Text className="text-xl font-bold text-storm-50">
                      {selectedUser.firstName} {selectedUser.lastName}
                    </Text>
                    <Text className="text-storm-400">@{selectedUser.username}</Text>
                  </View>
                  
                  <View className="space-y-3">
                    <View className="flex-row justify-between">
                      <Text className="text-storm-400">Email:</Text>
                      <Text className="text-storm-50">{selectedUser.email}</Text>
                    </View>
                    <View className="flex-row justify-between">
                      <Text className="text-storm-400">Location:</Text>
                      <Text className="text-storm-50">{selectedUser.location}</Text>
                    </View>
                    <View className="flex-row justify-between">
                      <Text className="text-storm-400">Joined:</Text>
                      <Text className="text-storm-50">
                        {selectedUser.joinedDate.toLocaleDateString()}
                      </Text>
                    </View>
                    <View className="flex-row justify-between">
                      <Text className="text-storm-400">Last Active:</Text>
                      <Text className="text-storm-50">
                        {formatLastActive(selectedUser.lastActive)}
                      </Text>
                    </View>
                  </View>
                </View>

                {/* Actions */}
                <View className="space-y-3">
                  <Text className="text-storm-50 font-semibold mb-2">Actions</Text>
                  
                  <Pressable
                    onPress={() => handleUserAction(selectedUser, 'verify')}
                    className="bg-storm-800 rounded-lg p-4 border border-storm-700"
                  >
                    <View className="flex-row items-center">
                      <Ionicons 
                        name={selectedUser.isVerified ? "checkmark-circle" : "checkmark-circle-outline"} 
                        size={20} 
                        color="#10b981" 
                      />
                      <Text className="text-storm-50 ml-3">
                        {selectedUser.isVerified ? 'Remove Verification' : 'Verify User'}
                      </Text>
                    </View>
                  </Pressable>
                  
                  {selectedUser.status === 'active' ? (
                    <Pressable
                      onPress={() => handleUserAction(selectedUser, 'suspend')}
                      className="bg-storm-800 rounded-lg p-4 border border-storm-700"
                    >
                      <View className="flex-row items-center">
                        <Ionicons name="pause-circle" size={20} color="#f59e0b" />
                        <Text className="text-storm-50 ml-3">Suspend User</Text>
                      </View>
                    </Pressable>
                  ) : (
                    <Pressable
                      onPress={() => handleUserAction(selectedUser, 'activate')}
                      className="bg-storm-800 rounded-lg p-4 border border-storm-700"
                    >
                      <View className="flex-row items-center">
                        <Ionicons name="play-circle" size={20} color="#10b981" />
                        <Text className="text-storm-50 ml-3">Activate User</Text>
                      </View>
                    </Pressable>
                  )}
                  
                  <Pressable
                    onPress={() => handleUserAction(selectedUser, 'ban')}
                    className="bg-storm-800 rounded-lg p-4 border border-storm-700"
                  >
                    <View className="flex-row items-center">
                      <Ionicons name="ban" size={20} color="#ef4444" />
                      <Text className="text-storm-50 ml-3">Ban User</Text>
                    </View>
                  </Pressable>
                  
                  <Pressable
                    onPress={() => handleUserAction(selectedUser, 'delete')}
                    className="bg-red-900 rounded-lg p-4 border border-red-700"
                  >
                    <View className="flex-row items-center">
                      <Ionicons name="trash" size={20} color="#ef4444" />
                      <Text className="text-red-300 ml-3">Delete User</Text>
                    </View>
                  </Pressable>
                </View>
              </ScrollView>
            </>
          )}
        </View>
      </Modal>
    </>
  );
}