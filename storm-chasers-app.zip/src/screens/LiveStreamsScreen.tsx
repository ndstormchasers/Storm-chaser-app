import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { useStormChaserStore } from '../state/stormChasers';
import { RootStackParamList } from '../types';

type LiveStreamsScreenNavigationProp = NativeStackNavigationProp<RootStackParamList, 'LiveStreams'>;

export default function LiveStreamsScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<LiveStreamsScreenNavigationProp>();
  const { chasers, liveStreams } = useStormChaserStore();
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = () => {
    setRefreshing(true);
    // Simulate refresh
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  };

  const sortedStreams = [...liveStreams].sort((a, b) => b.viewers - a.viewers);

  return (
    <ScrollView 
      className="flex-1 bg-storm-900"
      style={{ paddingTop: insets.top }}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
    >
      {/* Header */}
      <View className="px-4 py-6 bg-storm-800 border-b border-storm-700">
        <Text className="text-3xl font-bold text-storm-50">Live Streams</Text>
        <Text className="text-lightning-300 mt-1">
          {liveStreams.length} active storm{liveStreams.length !== 1 ? 's' : ''} being tracked
        </Text>
      </View>

      {/* Live Streams */}
      <View className="px-4 py-6">
        {sortedStreams.length > 0 ? (
          <View className="space-y-4">
            {sortedStreams.map((stream) => {
              const chaser = chasers.find(c => c.id === stream.chaserId);
              const streamDuration = Math.floor((Date.now() - stream.startTime.getTime()) / 60000);
              
              return (
                <Pressable
                  key={stream.id}
                  onPress={() => navigation.navigate('StreamDetail', { streamId: stream.id })}
                  className="bg-white rounded-lg shadow-sm border border-gray-200"
                >
                  <View className="p-4">
                    {/* Stream Header */}
                    <View className="flex-row items-center mb-3">
                      <View className="w-12 h-12 bg-red-100 rounded-full items-center justify-center">
                        <Text className="text-2xl">{stream.thumbnail}</Text>
                      </View>
                      <View className="flex-1 ml-3">
                        <Text className="font-semibold text-gray-900">{chaser?.name}</Text>
                        <View className="flex-row items-center mt-1">
                          <View className="w-2 h-2 bg-red-500 rounded-full mr-2" />
                          <Text className="text-sm text-red-500 font-medium">LIVE</Text>
                          <Text className="text-sm text-gray-600 ml-2">
                            {streamDuration}m ago
                          </Text>
                        </View>
                      </View>
                      <View className="items-end">
                        <View className="flex-row items-center">
                          <Ionicons name="eye" size={16} color="#6b7280" />
                          <Text className="text-sm text-gray-600 ml-1 font-medium">
                            {stream.viewers.toLocaleString()}
                          </Text>
                        </View>
                      </View>
                    </View>

                    {/* Stream Content */}
                    <Text className="font-medium text-gray-900 mb-2">{stream.title}</Text>
                    <Text className="text-sm text-gray-600 mb-3">{stream.description}</Text>

                    {/* Stream Info */}
                    <View className="flex-row items-center justify-between">
                      <View className="flex-row items-center">
                        <Ionicons name="location" size={14} color="#6b7280" />
                        <Text className="text-sm text-gray-600 ml-1">{stream.location}</Text>
                      </View>
                      <View className="flex-row items-center">
                        <Ionicons name="thunderstorm" size={14} color="#6b7280" />
                        <Text className="text-sm text-gray-600 ml-1">{stream.weatherCondition}</Text>
                      </View>
                    </View>
                  </View>
                </Pressable>
              );
            })}
          </View>
        ) : (
          <View className="bg-white rounded-lg p-8 items-center">
            <Text className="text-6xl mb-4">🌤️</Text>
            <Text className="text-gray-600 text-center text-lg font-medium mb-2">
              No Live Streams
            </Text>
            <Text className="text-gray-500 text-center">
              Storm chasers are currently offline. Check back later for live storm tracking!
            </Text>
          </View>
        )}
      </View>

      {/* Quick Actions */}
      <View className="px-4 pb-6">
        <View className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
          <Text className="font-semibold text-gray-900 mb-3">Quick Actions</Text>
          <View className="space-y-3">
            <Pressable 
              onPress={() => navigation.navigate('GoLive')}
              className="flex-row items-center p-3 bg-red-50 rounded-lg"
            >
              <Ionicons name="radio" size={20} color="#ef4444" />
              <Text className="text-red-600 font-medium ml-3">Start Live Stream</Text>
            </Pressable>
            <Pressable 
              onPress={() => navigation.navigate('Alerts')}
              className="flex-row items-center p-3 bg-thunder-900 rounded-lg border border-thunder-700"
            >
              <Ionicons name="warning" size={20} color="#f59e0b" />
              <Text className="text-thunder-400 font-medium ml-3">Weather Alerts</Text>
            </Pressable>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}