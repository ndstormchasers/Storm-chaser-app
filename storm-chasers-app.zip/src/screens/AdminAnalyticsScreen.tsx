import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useAdminStore } from '../state/admin';
import { useStormChaserStore } from '../state/stormChasers';
import { useWeatherStore } from '../state/weather';

export default function AdminAnalyticsScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const { stats, allUsers, reports } = useAdminStore();
  const { liveStreams, chasers } = useStormChaserStore();
  const { alerts } = useWeatherStore();
  
  const [timeRange, setTimeRange] = useState<'24h' | '7d' | '30d' | '90d'>('7d');

  // Calculate analytics data
  const now = new Date();
  const last24h = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  const last7d = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const last30d = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

  const getTimeRangeDate = () => {
    switch (timeRange) {
      case '24h': return last24h;
      case '7d': return last7d;
      case '30d': return last30d;
      case '90d': return new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
      default: return last7d;
    }
  };

  const rangeDate = getTimeRangeDate();

  // Calculate metrics
  const newUsers = allUsers.filter(user => user.joinedDate >= rangeDate).length;
  const newReports = reports.filter(report => report.createdAt >= rangeDate).length;
  const activeStreams = liveStreams.length;
  const totalViewers = liveStreams.reduce((sum, stream) => sum + stream.viewers, 0);

  const userGrowthRate = ((newUsers / Math.max(allUsers.length - newUsers, 1)) * 100).toFixed(1);
  const avgViewersPerStream = activeStreams > 0 ? Math.round(totalViewers / activeStreams) : 0;

  const reportsByType = reports.reduce((acc, report) => {
    acc[report.type] = (acc[report.type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const usersByStatus = allUsers.reduce((acc, user) => {
    const status = user.status || 'active';
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const chartData = [
    { label: 'Users', value: stats.totalUsers, color: '#0ea5e9', icon: 'people' },
    { label: 'Active Streams', value: activeStreams, color: '#ef4444', icon: 'radio' },
    { label: 'Total Viewers', value: totalViewers, color: '#10b981', icon: 'eye' },
    { label: 'Weather Alerts', value: alerts.length, color: '#f59e0b', icon: 'warning' },
  ];

  return (
    <View className="flex-1 bg-storm-900" style={{ paddingTop: insets.top }}>
      {/* Header */}
      <View className="px-4 py-6 bg-storm-800 border-b border-storm-700">
        <View className="flex-row items-center">
          <Pressable onPress={() => navigation.goBack()} className="mr-4">
            <Ionicons name="chevron-back" size={24} color="#0ea5e9" />
          </Pressable>
          <View>
            <Text className="text-2xl font-bold text-storm-50">Analytics & Reports</Text>
            <Text className="text-lightning-300 mt-1">Platform insights and metrics</Text>
          </View>
        </View>
      </View>

      <ScrollView className="flex-1">
        {/* Time Range Selector */}
        <View className="p-4 bg-storm-800 border-b border-storm-700">
          <Text className="text-storm-300 text-sm mb-3">Time Range</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {(['24h', '7d', '30d', '90d'] as const).map((range) => (
              <Pressable
                key={range}
                onPress={() => setTimeRange(range)}
                className={`mr-3 px-4 py-2 rounded-full border ${
                  timeRange === range
                    ? 'bg-lightning-500 border-lightning-500'
                    : 'bg-transparent border-storm-600'
                }`}
              >
                <Text className={`text-sm font-medium ${
                  timeRange === range ? 'text-white' : 'text-storm-300'
                }`}>
                  {range === '24h' ? 'Last 24 Hours' : 
                   range === '7d' ? 'Last 7 Days' :
                   range === '30d' ? 'Last 30 Days' : 'Last 90 Days'}
                </Text>
              </Pressable>
            ))}
          </ScrollView>
        </View>

        {/* Key Metrics */}
        <View className="p-4">
          <Text className="text-storm-50 text-xl font-semibold mb-4">Key Metrics</Text>
          
          <View className="flex-row flex-wrap">
            {chartData.map((item, index) => (
              <View key={index} className="w-1/2 pr-2 pb-4">
                <View className="bg-storm-800 rounded-lg p-4 border border-storm-700">
                  <View className="flex-row items-center justify-between mb-2">
                    <Ionicons name={item.icon as any} size={24} color={item.color} />
                    <Text className="text-2xl font-bold text-storm-50">{item.value}</Text>
                  </View>
                  <Text className="text-storm-400 text-sm">{item.label}</Text>
                </View>
              </View>
            ))}
          </View>
        </View>

        {/* Growth Metrics */}
        <View className="px-4 pb-4">
          <Text className="text-storm-50 text-xl font-semibold mb-4">Growth Analytics</Text>
          
          <View className="bg-storm-800 rounded-lg p-4 border border-storm-700 mb-4">
            <Text className="text-storm-50 font-semibold mb-3">User Growth</Text>
            <View className="flex-row justify-between items-center mb-2">
              <Text className="text-storm-400">New Users ({timeRange})</Text>
              <Text className="text-storm-50 font-bold">{newUsers}</Text>
            </View>
            <View className="flex-row justify-between items-center">
              <Text className="text-storm-400">Growth Rate</Text>
              <Text className="text-green-400 font-bold">+{userGrowthRate}%</Text>
            </View>
          </View>

          <View className="bg-storm-800 rounded-lg p-4 border border-storm-700">
            <Text className="text-storm-50 font-semibold mb-3">Streaming Metrics</Text>
            <View className="flex-row justify-between items-center mb-2">
              <Text className="text-storm-400">Average Viewers/Stream</Text>
              <Text className="text-storm-50 font-bold">{avgViewersPerStream}</Text>
            </View>
            <View className="flex-row justify-between items-center">
              <Text className="text-storm-400">Peak Concurrent Viewers</Text>
              <Text className="text-storm-50 font-bold">{Math.max(...liveStreams.map(s => s.viewers), 0)}</Text>
            </View>
          </View>
        </View>

        {/* User Status Breakdown */}
        <View className="px-4 pb-4">
          <Text className="text-storm-50 text-xl font-semibold mb-4">User Status</Text>
          
          <View className="bg-storm-800 rounded-lg p-4 border border-storm-700">
            {Object.entries(usersByStatus).map(([status, count]) => (
              <View key={status} className="flex-row justify-between items-center mb-2">
                <View className="flex-row items-center">
                  <View 
                    className="w-3 h-3 rounded-full mr-3"
                    style={{ 
                      backgroundColor: 
                        status === 'active' ? '#10b981' :
                        status === 'suspended' ? '#f59e0b' :
                        status === 'banned' ? '#ef4444' : '#64748b'
                    }}
                  />
                  <Text className="text-storm-300 capitalize">{status} Users</Text>
                </View>
                <Text className="text-storm-50 font-bold">{count}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Reports Breakdown */}
        <View className="px-4 pb-4">
          <Text className="text-storm-50 text-xl font-semibold mb-4">Report Analytics</Text>
          
          <View className="bg-storm-800 rounded-lg p-4 border border-storm-700 mb-4">
            <View className="flex-row justify-between items-center mb-3">
              <Text className="text-storm-50 font-semibold">New Reports ({timeRange})</Text>
              <Text className="text-storm-50 font-bold">{newReports}</Text>
            </View>
            
            {Object.entries(reportsByType).map(([type, count]) => (
              <View key={type} className="flex-row justify-between items-center mb-2">
                <Text className="text-storm-400 capitalize">{type.replace('_', ' ')}</Text>
                <Text className="text-storm-50">{count}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* System Health */}
        <View className="px-4 pb-8">
          <Text className="text-storm-50 text-xl font-semibold mb-4">System Health</Text>
          
          <View className="space-y-3">
            <View className="bg-storm-800 rounded-lg p-4 border border-storm-700">
              <View className="flex-row items-center justify-between">
                <View className="flex-row items-center">
                  <Ionicons name="checkmark-circle" size={20} color="#10b981" />
                  <Text className="text-storm-50 ml-3">Platform Status</Text>
                </View>
                <Text className="text-green-400 font-medium">Operational</Text>
              </View>
            </View>
            
            <View className="bg-storm-800 rounded-lg p-4 border border-storm-700">
              <View className="flex-row items-center justify-between">
                <View className="flex-row items-center">
                  <Ionicons name="speedometer" size={20} color="#0ea5e9" />
                  <Text className="text-storm-50 ml-3">Response Time</Text>
                </View>
                <Text className="text-lightning-400 font-medium">~150ms</Text>
              </View>
            </View>
            
            <View className="bg-storm-800 rounded-lg p-4 border border-storm-700">
              <View className="flex-row items-center justify-between">
                <View className="flex-row items-center">
                  <Ionicons name="cloud" size={20} color="#10b981" />
                  <Text className="text-storm-50 ml-3">Uptime</Text>
                </View>
                <Text className="text-green-400 font-medium">99.9%</Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}