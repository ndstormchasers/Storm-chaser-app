import React from 'react';
import { View, Text, Pressable, ImageBackground } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { AuthStackParamList } from '../types';

type WelcomeScreenNavigationProp = NativeStackNavigationProp<AuthStackParamList, 'Welcome'>;

export default function WelcomeScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<WelcomeScreenNavigationProp>();

  return (
    <View className="flex-1 bg-storm-900" style={{ paddingTop: insets.top }}>
      {/* Background */}
      <View className="flex-1" style={{ backgroundColor: '#0f172a' }}>
        {/* Header */}
        <View className="flex-1 px-6 pt-12">
          <View className="items-center mb-8">
            <Text className="text-6xl mb-4">🌪️</Text>
            <Text className="text-4xl font-bold text-storm-50 text-center">Storm Chasers</Text>
            <Text className="text-xl text-lightning-300 text-center mt-2">
              Live Storm Tracking Community
            </Text>
          </View>

          {/* Features */}
          <View className="space-y-6 mt-12">
            <View className="flex-row items-center">
              <View className="w-12 h-12 bg-lightning-500 rounded-full items-center justify-center mr-4">
                <Ionicons name="radio" size={24} color="white" />
              </View>
              <View className="flex-1">
                <Text className="text-storm-50 font-semibold text-lg">Live Streaming</Text>
                <Text className="text-storm-400">
                  Broadcast your storm chases to YouTube and Twitch
                </Text>
              </View>
            </View>

            <View className="flex-row items-center">
              <View className="w-12 h-12 bg-thunder-500 rounded-full items-center justify-center mr-4">
                <Ionicons name="people" size={24} color="white" />
              </View>
              <View className="flex-1">
                <Text className="text-storm-50 font-semibold text-lg">Community</Text>
                <Text className="text-storm-400">
                  Connect with storm chasers around the world
                </Text>
              </View>
            </View>

            <View className="flex-row items-center">
              <View className="w-12 h-12 bg-thunder-400 rounded-full items-center justify-center mr-4">
                <Ionicons name="warning" size={24} color="white" />
              </View>
              <View className="flex-1">
                <Text className="text-storm-50 font-semibold text-lg">Real-time Alerts</Text>
                <Text className="text-storm-400">
                  Get notified about severe weather in your area
                </Text>
              </View>
            </View>

            <View className="flex-row items-center">
              <View className="w-12 h-12 bg-lightning-600 rounded-full items-center justify-center mr-4">
                <Ionicons name="location" size={24} color="white" />
              </View>
              <View className="flex-1">
                <Text className="text-storm-50 font-semibold text-lg">Track Storms</Text>
                <Text className="text-storm-400">
                  Follow live storm tracking from experienced chasers
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* Action Buttons */}
        <View className="px-6 pb-8" style={{ paddingBottom: insets.bottom + 32 }}>
          <Pressable
            onPress={() => navigation.navigate('SignUp')}
            className="bg-lightning-500 py-4 rounded-lg mb-4 shadow-lg"
          >
            <Text className="text-white font-semibold text-center text-lg">
              Get Started
            </Text>
          </Pressable>

          <Pressable
            onPress={() => navigation.navigate('Login')}
            className="bg-transparent border border-storm-600 py-4 rounded-lg"
          >
            <Text className="text-white font-semibold text-center text-lg">
              Sign In
            </Text>
          </Pressable>

          <Text className="text-storm-500 text-center mt-6 text-sm">
            Join thousands of storm chasers worldwide
          </Text>
        </View>
      </View>
    </View>
  );
}