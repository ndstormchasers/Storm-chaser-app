import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Pressable, Alert, TextInput, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/auth';
import { useStormChaserStore } from '../state/stormChasers';
import { useAdminStore } from '../state/admin';

export default function MyProfileScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const { user, logout, updateProfile } = useAuthStore();
  const { liveStreams } = useStormChaserStore();
  const { isAdmin, checkAdminAccess } = useAdminStore();
  const [showEditModal, setShowEditModal] = useState(false);
  const [editForm, setEditForm] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    bio: user?.bio || '',
    location: user?.location || '',
  });

  const myStreams = liveStreams.filter(stream => stream.chaserId === user?.id);
  const joinedDate = user?.joinedDate ? new Date(user.joinedDate) : new Date();

  useEffect(() => {
    checkAdminAccess(user);
  }, [user]);

  const handleLogout = () => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Sign Out', 
          style: 'destructive',
          onPress: logout 
        },
      ]
    );
  };

  const handleSaveProfile = () => {
    if (user) {
      updateProfile({
        firstName: editForm.firstName.trim(),
        lastName: editForm.lastName.trim(),
        bio: editForm.bio.trim(),
        location: editForm.location.trim(),
      });
      setShowEditModal(false);
      Alert.alert('Success', 'Profile updated successfully!');
    }
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long' 
    });
  };

  if (!user) {
    return (
      <View className="flex-1 items-center justify-center bg-gray-50">
        <Text className="text-gray-600">No user data available</Text>
      </View>
    );
  }

  return (
    <>
      <ScrollView 
        className="flex-1 bg-storm-900"
        style={{ paddingTop: insets.top }}
      >
        {/* Header */}
        <View className="px-4 py-6 bg-storm-800 border-b border-storm-700">
          <View className="flex-row items-center justify-between">
            <View>
              <Text className="text-3xl font-bold text-storm-50">My Profile</Text>
              <Text className="text-storm-400 mt-1">Manage your storm chasing profile</Text>
            </View>
            <Pressable
              onPress={() => {
                setEditForm({
                  firstName: user.firstName,
                  lastName: user.lastName,
                  bio: user.bio,
                  location: user.location,
                });
                setShowEditModal(true);
              }}
              className="bg-lightning-500 px-4 py-2 rounded-lg shadow-lg"
            >
              <Text className="text-white font-medium">Edit</Text>
            </Pressable>
          </View>
        </View>

        {/* Profile Info */}
        <View className="bg-storm-800 p-6 border-b border-storm-700">
          <View className="items-center mb-6">
            <View className="w-24 h-24 bg-lightning-900 rounded-full items-center justify-center mb-4 border-2 border-lightning-600">
              <Text className="text-5xl">{user.avatar}</Text>
            </View>
            <Text className="text-2xl font-bold text-storm-50">
              {user.firstName} {user.lastName}
            </Text>
            <Text className="text-storm-400 text-lg">@{user.username}</Text>
            {user.isVerified && (
              <View className="flex-row items-center mt-2">
                <Ionicons name="checkmark-circle" size={20} color="#10b981" />
                <Text className="text-lightning-400 font-medium ml-1">Verified Chaser</Text>
              </View>
            )}
          </View>

          <View className="flex-row items-center justify-center mb-4">
            <Ionicons name="location" size={16} color="#94a3b8" />
            <Text className="text-storm-400 ml-1">{user.location}</Text>
          </View>

          <Text className="text-storm-300 text-center leading-6">{user.bio}</Text>
        </View>

        {/* Stats */}
        <View className="bg-storm-800 p-6 mb-4 border-b border-storm-700">
          <Text className="font-semibold text-storm-50 mb-4">Account Stats</Text>
          <View className="space-y-4">
            <View className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                <Ionicons name="calendar" size={20} color="#94a3b8" />
                <Text className="text-storm-300 ml-3">Member Since</Text>
              </View>
              <Text className="font-semibold text-storm-50">
                {formatDate(joinedDate)}
              </Text>
            </View>
            <View className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                <Ionicons name="radio" size={20} color="#94a3b8" />
                <Text className="text-storm-300 ml-3">Live Streams</Text>
              </View>
              <Text className="font-semibold text-storm-50">{myStreams.length}</Text>
            </View>
            <View className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                <Ionicons name="mail" size={20} color="#94a3b8" />
                <Text className="text-storm-300 ml-3">Email</Text>
              </View>
              <Text className="font-semibold text-storm-50">{user.email}</Text>
            </View>
          </View>
        </View>

        {/* My Streams */}
        {myStreams.length > 0 && (
          <View className="bg-storm-800 p-6 mb-4 border border-storm-700 rounded-lg mx-4">
            <Text className="font-semibold text-storm-50 mb-4">My Live Streams</Text>
            <View className="space-y-3">
              {myStreams.map((stream) => (
                <View key={stream.id} className="border border-storm-600 rounded-lg p-4 bg-storm-700">
                  <View className="flex-row items-center mb-2">
                    <View className="w-2 h-2 bg-lightning-400 rounded-full mr-2" />
                    <Text className="font-medium text-storm-50 flex-1">{stream.title}</Text>
                    <Text className="text-sm text-storm-400">
                      {stream.viewers.toLocaleString()} viewers
                    </Text>
                  </View>
                  <Text className="text-storm-300 text-sm mb-2">{stream.description}</Text>
                  <View className="flex-row items-center">
                    <Ionicons name="location" size={14} color="#94a3b8" />
                    <Text className="text-sm text-storm-400 ml-1">{stream.location}</Text>
                  </View>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Admin Access */}
        {isAdmin && (
          <View className="bg-storm-800 p-6 mb-4 border border-lightning-700 rounded-lg mx-4">
            <Text className="font-semibold text-storm-50 mb-4">⚡ Admin Panel</Text>
            <Pressable 
              onPress={() => navigation.navigate('AdminDashboard')}
              className="flex-row items-center justify-between bg-lightning-900 p-4 rounded-lg border border-lightning-600"
            >
              <View className="flex-row items-center">
                <Ionicons name="shield-checkmark" size={20} color="#0ea5e9" />
                <Text className="text-lightning-300 ml-3 font-medium">Admin Dashboard</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#0ea5e9" />
            </Pressable>
          </View>
        )}

        {/* Settings */}
        <View className="bg-storm-800 p-6 mb-4 border border-storm-700 rounded-lg mx-4">
          <Text className="font-semibold text-storm-50 mb-4">Settings</Text>
          <View className="space-y-4">
            <Pressable className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                <Ionicons name="notifications" size={20} color="#94a3b8" />
                <Text className="text-storm-300 ml-3">Notifications</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#475569" />
            </Pressable>
            <Pressable className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                <Ionicons name="shield" size={20} color="#94a3b8" />
                <Text className="text-storm-300 ml-3">Privacy & Security</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#475569" />
            </Pressable>
            <Pressable className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                <Ionicons name="help-circle" size={20} color="#94a3b8" />
                <Text className="text-storm-300 ml-3">Help & Support</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#475569" />
            </Pressable>
          </View>
        </View>

        {/* Logout */}
        <View className="px-6 pb-8" style={{ paddingBottom: insets.bottom + 32 }}>
          <Pressable
            onPress={handleLogout}
            className="bg-lightning-500 py-4 rounded-lg shadow-lg"
          >
            <View className="flex-row items-center justify-center">
              <Ionicons name="log-out" size={20} color="white" />
              <Text className="text-white font-semibold ml-2">Sign Out</Text>
            </View>
          </Pressable>
        </View>
      </ScrollView>

      {/* Edit Profile Modal */}
      <Modal
        visible={showEditModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View className="flex-1 bg-storm-900" style={{ paddingTop: insets.top }}>
          <View className="flex-row items-center justify-between p-4 border-b border-storm-700">
            <Pressable onPress={() => setShowEditModal(false)}>
              <Text className="text-lightning-400 font-medium">Cancel</Text>
            </Pressable>
            <Text className="text-lg font-semibold text-storm-50">Edit Profile</Text>
            <Pressable onPress={handleSaveProfile}>
              <Text className="text-lightning-400 font-medium">Save</Text>
            </Pressable>
          </View>
          
          <ScrollView className="flex-1 p-4">
            <View className="space-y-4">
              <View className="flex-row space-x-4">
                <View className="flex-1">
                  <Text className="text-sm font-medium text-storm-300 mb-2">First Name</Text>
                  <TextInput
                    value={editForm.firstName}
                    onChangeText={(text) => setEditForm(prev => ({ ...prev, firstName: text }))}
                    className="bg-storm-800 border border-storm-600 rounded-lg px-3 py-2 text-storm-50"
                    autoCapitalize="words"
                  />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-medium text-storm-300 mb-2">Last Name</Text>
                  <TextInput
                    value={editForm.lastName}
                    onChangeText={(text) => setEditForm(prev => ({ ...prev, lastName: text }))}
                    className="bg-storm-800 border border-storm-600 rounded-lg px-3 py-2 text-storm-50"
                    autoCapitalize="words"
                  />
                </View>
              </View>

              <View>
                <Text className="text-sm font-medium text-storm-300 mb-2">Location</Text>
                <TextInput
                  value={editForm.location}
                  onChangeText={(text) => setEditForm(prev => ({ ...prev, location: text }))}
                  className="bg-gray-50 border border-gray-300 rounded-lg px-3 py-2"
                  autoCapitalize="words"
                />
              </View>

              <View>
                <Text className="text-sm font-medium text-storm-300 mb-2">Bio</Text>
                <TextInput
                  value={editForm.bio}
                  onChangeText={(text) => setEditForm(prev => ({ ...prev, bio: text }))}
                  className="bg-gray-50 border border-gray-300 rounded-lg px-3 py-2"
                  multiline
                  numberOfLines={4}
                  maxLength={200}
                />
                <Text className="text-storm-500 text-xs mt-1">
                  {editForm.bio.length}/200 characters
                </Text>
              </View>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </>
  );
}