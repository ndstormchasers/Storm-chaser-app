import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Pressable, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { aiStormPredictionService, StormPrediction, ChaseRecommendation } from '../api/ai-predictions';

export default function AIPredictionsScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const [predictions, setPredictions] = useState<StormPrediction[]>([]);
  const [recommendations, setRecommendations] = useState<ChaseRecommendation[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedDay, setSelectedDay] = useState(0);

  const loadPredictions = async () => {
    try {
      const defaultLocation = { latitude: 35.4676, longitude: -97.5164 }; // Oklahoma City
      const [preds, recs] = await Promise.all([
        aiStormPredictionService.generateStormPredictions(defaultLocation),
        aiStormPredictionService.getChaseRecommendations(defaultLocation)
      ]);
      setPredictions(preds);
      setRecommendations(recs);
    } catch (error) {
      console.error('Failed to load predictions:', error);
    }
  };

  useEffect(() => {
    loadPredictions();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadPredictions();
    setRefreshing(false);
  };

  const getProbabilityColor = (probability: number) => {
    if (probability >= 0.8) return '#dc2626';
    if (probability >= 0.6) return '#f59e0b';
    if (probability >= 0.4) return '#eab308';
    return '#22c55e';
  };

  const getConfidenceIcon = (confidence: number) => {
    if (confidence >= 0.9) return '🎯';
    if (confidence >= 0.7) return '🔍';
    if (confidence >= 0.5) return '📊';
    return '❓';
  };

  const getSafetyColor = (level: string) => {
    switch (level) {
      case 'low': return '#22c55e';
      case 'moderate': return '#f59e0b';
      case 'high': return '#ef4444';
      case 'extreme': return '#dc2626';
      default: return '#6b7280';
    }
  };

  const formatTime = (date: Date | undefined) => {
    if (!date || !(date instanceof Date)) {
      return 'Unknown Time';
    }
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  };

  const formatDate = (date: Date | undefined) => {
    if (!date || !(date instanceof Date)) {
      return 'Unknown Date';
    }
    return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  };

  return (
    <ScrollView 
      className="flex-1 bg-storm-900"
      style={{ paddingTop: insets.top }}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={onRefresh}
          tintColor="#38bdf8"
        />
      }
    >
      {/* Header */}
      <View className="px-4 py-6 bg-storm-800 border-b border-storm-700">
        <View className="flex-row items-center justify-between">
          <View>
            <Text className="text-3xl font-bold text-storm-50">AI Predictions</Text>
            <Text className="text-lightning-300 mt-1">Advanced storm forecasting</Text>
          </View>
          <Pressable onPress={() => navigation.goBack()}>
            <Ionicons name="close" size={24} color="#64748b" />
          </Pressable>
        </View>
      </View>

      {/* Today's Recommendations */}
      {recommendations.length > 0 && (
        <View className="px-4 py-4">
          <Text className="text-xl font-semibold text-storm-50 mb-4">Today's Chase Recommendations</Text>
          
          {recommendations.slice(0, 3).map((rec) => (
            <View
              key={rec.date.toISOString()}
              className="bg-storm-800 rounded-lg p-4 mb-3 border border-storm-700"
            >
              <View className="flex-row items-center justify-between mb-3">
                <View className="flex-row items-center">
                  <Text className="text-2xl mr-3">🎯</Text>
                  <View>
                    <Text className="font-semibold text-storm-50">{rec.primary_target.name}</Text>
                    <Text className="text-storm-400 text-sm">
                      {rec.primary_target.latitude.toFixed(3)}, {rec.primary_target.longitude.toFixed(3)}
                    </Text>
                  </View>
                </View>
                <View 
                  className="px-3 py-1 rounded-full"
                  style={{ backgroundColor: getSafetyColor(rec.score > 70 ? 'high' : rec.score > 40 ? 'medium' : 'low') }}
                >
                  <Text className="text-white text-xs font-medium uppercase">
                    {rec.score > 70 ? 'HIGH' : rec.score > 40 ? 'MEDIUM' : 'LOW'}
                  </Text>
                </View>
              </View>

              <View className="space-y-2">
                <View className="flex-row items-center justify-between">
                  <Text className="text-storm-300">Success Probability:</Text>
                  <Text 
                    className="font-bold"
                    style={{ color: getProbabilityColor(rec.score / 100) }}
                  >
                    {rec.score.toFixed(0)}%
                  </Text>
                </View>
                
                <View className="flex-row items-center justify-between">
                  <Text className="text-storm-300">Optimal Time:</Text>
                  <Text className="text-storm-50 font-medium">
                    {rec.date.toLocaleDateString()}
                  </Text>
                </View>

                <View className="flex-row items-center justify-between">
                  <Text className="text-storm-300">Est. Cost:</Text>
                  <Text className="text-storm-50 font-medium">
                    ${rec.estimated_costs.total.toFixed(0)}
                  </Text>
                </View>
              </View>

              {rec.storm_types.length > 0 && (
                <View className="mt-3 pt-3 border-t border-storm-700">
                  <Text className="text-storm-300 text-sm mb-2">Expected Storm Types:</Text>
                  <View className="flex-row flex-wrap gap-2">
                    {rec.storm_types.map((type, index) => (
                      <View key={index} className="bg-lightning-900 px-2 py-1 rounded-full">
                        <Text className="text-lightning-300 text-xs capitalize">{type}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              )}
            </View>
          ))}
        </View>
      )}

      {/* 7-Day Forecast */}
      <View className="px-4 pb-4">
        <Text className="text-xl font-semibold text-storm-50 mb-4">7-Day Storm Forecast</Text>
        
        {/* Day Selector */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} className="mb-4">
          {predictions.map((prediction, index) => (
            <Pressable
              key={index}
              onPress={() => setSelectedDay(index)}
              className={`mr-3 px-4 py-2 rounded-lg ${
                selectedDay === index ? 'bg-lightning-600' : 'bg-storm-800'
              }`}
            >
              <Text className={`text-sm font-medium ${
                selectedDay === index ? 'text-white' : 'text-storm-300'
              }`}>
                {formatDate(prediction.date)}
              </Text>
            </Pressable>
          ))}
        </ScrollView>

        {/* Selected Day Details */}
        {predictions[selectedDay] && (
          <View className="bg-storm-800 rounded-lg p-4 border border-storm-700">
            <View className="flex-row items-center justify-between mb-4">
              <View>
                <Text className="text-lg font-semibold text-storm-50">
                  {formatDate(predictions[selectedDay].date)}
                </Text>
                <Text className="text-storm-400">AI Confidence: {getConfidenceIcon(predictions[selectedDay].confidence)}</Text>
              </View>
              <View className="items-end">
                <Text 
                  className="text-2xl font-bold"
                  style={{ color: getProbabilityColor(predictions[selectedDay].probability) }}
                >
                  {(predictions[selectedDay].probability * 100).toFixed(0)}%
                </Text>
                <Text className="text-storm-400 text-sm">Storm Probability</Text>
              </View>
            </View>

            <View className="space-y-3">
              <View className="flex-row items-center justify-between">
                <Text className="text-storm-300">Peak Time:</Text>
                <Text className="text-storm-50 font-medium">
                  {formatTime(predictions[selectedDay].timeframe.peak)}
                </Text>
              </View>

              <View className="flex-row items-center justify-between">
                <Text className="text-storm-300">Duration:</Text>
                <Text className="text-storm-50 font-medium">
                  {formatTime(predictions[selectedDay].timeframe.start)} - {formatTime(predictions[selectedDay].timeframe.end)}
                </Text>
              </View>

              {predictions[selectedDay].chase_recommendation && (
                <View className="mt-4 p-3 bg-storm-700 rounded-lg">
                  <View className="flex-row items-center mb-2">
                    <Ionicons name="compass" size={16} color="#38bdf8" />
                    <Text className="text-lightning-400 font-medium ml-2">Chase Recommendation</Text>
                  </View>
                  
                  <View className="space-y-2">
                    <View className="flex-row items-center justify-between">
                      <Text className="text-storm-300">Should Chase:</Text>
                      <Text className={`font-medium ${
                        predictions[selectedDay].chase_recommendation!.should_chase ? 'text-green-400' : 'text-red-400'
                      }`}>
                        {predictions[selectedDay].chase_recommendation!.should_chase ? 'YES' : 'NO'}
                      </Text>
                    </View>
                    
                    <View className="flex-row items-center justify-between">
                      <Text className="text-storm-300">Safety Level:</Text>
                      <Text 
                        className="font-medium px-2 py-1 rounded text-white text-xs"
                        style={{ backgroundColor: getSafetyColor(predictions[selectedDay].chase_recommendation!.safety_level) }}
                      >
                        {predictions[selectedDay].chase_recommendation!.safety_level.toUpperCase()}
                      </Text>
                    </View>

                    <View className="mt-2">
                      <Text className="text-storm-300 text-sm">Optimal Position:</Text>
                      <Text className="text-storm-50 font-mono text-sm">
                        {predictions[selectedDay].chase_recommendation!.optimal_position.latitude.toFixed(3)}, {predictions[selectedDay].chase_recommendation!.optimal_position.longitude.toFixed(3)}
                      </Text>
                    </View>
                  </View>
                </View>
              )}
            </View>
          </View>
        )}
      </View>

      {/* AI Insights */}
      <View className="px-4 pb-6">
        <View className="bg-gradient-to-r from-lightning-800 to-storm-800 rounded-xl p-4 border border-lightning-600">
          <View className="flex-row items-center mb-3">
            <Ionicons name="bulb" size={20} color="#8b5cf6" />
            <Text className="text-lg font-semibold text-storm-50 ml-2">AI Insights</Text>
          </View>
          <Text className="text-storm-300 text-sm leading-5">
            Our advanced AI analyzes atmospheric patterns, historical data, and real-time conditions to provide highly accurate storm predictions and chase recommendations.
          </Text>
          <View className="mt-3 pt-3 border-t border-lightning-600">
            <Text className="text-lightning-300 text-xs">
              Powered by machine learning models trained on decades of meteorological data
            </Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}