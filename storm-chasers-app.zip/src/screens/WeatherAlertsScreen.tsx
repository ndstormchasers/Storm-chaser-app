import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, Pressable, RefreshControl, Alert, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useWeatherStore } from '../state/weather';
import { weatherAlertsService } from '../api/weather-alerts';

export default function WeatherAlertsScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const {
    alerts,
    currentWeather,
    userLocation,
    lastUpdate,
    isLoading,
    error,
    alertsEnabled,
    severityFilter,
    fetchAlerts,
    refreshWeatherData,
    toggleAlertsEnabled,
    setSeverityFilter,
    dismissAlert,
    clearError,
  } = useWeatherStore();

  const [showSettings, setShowSettings] = useState(false);
  const [selectedSeverities, setSelectedSeverities] = useState(severityFilter);

  useEffect(() => {
    if (alertsEnabled) {
      fetchAlerts();
    }
  }, [alertsEnabled]);

  const filteredAlerts = alerts.filter(alert => 
    severityFilter.includes(alert.severity)
  );

  const handleRefresh = async () => {
    if (error) {
      clearError();
    }
    await refreshWeatherData();
  };

  const handleEnableLocation = () => {
    Alert.alert(
      'Enable Location',
      'Weather alerts require location access to provide accurate information for your area.',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Enable', 
          onPress: () => fetchAlerts()
        },
      ]
    );
  };

  const handleDismissAlert = (alertId: string, alertTitle: string) => {
    Alert.alert(
      'Dismiss Alert',
      `Are you sure you want to dismiss "${alertTitle}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Dismiss', 
          style: 'destructive',
          onPress: () => dismissAlert(alertId)
        },
      ]
    );
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    });
  };

  const severityOptions = [
    { id: 'extreme', label: 'Extreme', color: '#8B0000' },
    { id: 'severe', label: 'Severe', color: '#FF4500' },
    { id: 'moderate', label: 'Moderate', color: '#FFA500' },
    { id: 'minor', label: 'Minor', color: '#FFFF00' },
  ];

  const handleSaveSettings = () => {
    setSeverityFilter(selectedSeverities);
    setShowSettings(false);
  };

  return (
    <>
      <ScrollView 
        className="flex-1 bg-storm-900"
        style={{ paddingTop: insets.top }}
        refreshControl={
          <RefreshControl 
            refreshing={isLoading} 
            onRefresh={handleRefresh}
            tintColor="#0ea5e9"
          />
        }
      >
        {/* Header */}
        <View className="px-4 py-6 bg-storm-800 border-b border-storm-700">
          <View className="flex-row items-center justify-between">
            <View>
              <Text className="text-3xl font-bold text-storm-50">Weather Alerts</Text>
              <Text className="text-lightning-300 mt-1">
                {lastUpdate ? `Updated ${formatTime(lastUpdate)}` : 'Tap to refresh'}
              </Text>
            </View>
            <Pressable
              onPress={() => setShowSettings(true)}
              className="w-10 h-10 items-center justify-center"
            >
              <Ionicons name="settings" size={24} color="#0ea5e9" />
            </Pressable>
          </View>
        </View>

        {/* Current Weather */}
        {currentWeather && (
          <View className="mx-4 mt-4 bg-storm-800 rounded-lg p-4 border border-storm-700">
            <View className="flex-row items-center justify-between">
              <View>
                <Text className="text-storm-300 text-sm">Current Conditions</Text>
                <Text className="text-storm-50 text-2xl font-bold">
                  {currentWeather.temperature}°F
                </Text>
                <Text className="text-storm-400 capitalize">
                  {currentWeather.description}
                </Text>
              </View>
              <View className="items-end">
                <Text className="text-4xl mb-2">{weatherAlertsService.getSeverityIcon(currentWeather.condition)}</Text>
                <Text className="text-storm-400 text-sm">
                  Wind: {currentWeather.windSpeed} mph
                </Text>
                <Text className="text-storm-400 text-sm">
                  Humidity: {currentWeather.humidity}%
                </Text>
              </View>
            </View>
          </View>
        )}

        {/* Error State */}
        {error && (
          <View className="mx-4 mt-4 bg-red-900 border border-red-700 rounded-lg p-4">
            <View className="flex-row items-center mb-2">
              <Ionicons name="warning" size={20} color="#fca5a5" />
              <Text className="text-red-300 font-semibold ml-2">Error</Text>
            </View>
            <Text className="text-red-200 text-sm mb-3">{error}</Text>
            <Pressable
              onPress={error.includes('location') ? handleEnableLocation : handleRefresh}
              className="bg-red-600 py-2 px-4 rounded"
            >
              <Text className="text-white font-medium text-center">
                {error.includes('location') ? 'Enable Location' : 'Try Again'}
              </Text>
            </Pressable>
          </View>
        )}

        {/* Alerts Section */}
        <View className="p-4">
          {!alertsEnabled ? (
            <View className="bg-storm-800 rounded-lg p-6 items-center border border-storm-700">
              <Ionicons name="notifications-off" size={48} color="#64748b" />
              <Text className="text-storm-50 text-lg font-semibold mt-4 mb-2">
                Weather Alerts Disabled
              </Text>
              <Text className="text-storm-400 text-center mb-4">
                Enable weather alerts to stay informed about severe weather in your area.
              </Text>
              <Pressable
                onPress={toggleAlertsEnabled}
                className="bg-lightning-500 py-3 px-6 rounded-lg"
              >
                <Text className="text-white font-semibold">Enable Alerts</Text>
              </Pressable>
            </View>
          ) : filteredAlerts.length === 0 ? (
            <View className="bg-storm-800 rounded-lg p-6 items-center border border-storm-700">
              <Text className="text-6xl mb-4">🌤️</Text>
              <Text className="text-storm-50 text-lg font-semibold mb-2">
                No Active Alerts
              </Text>
              <Text className="text-storm-400 text-center">
                There are currently no weather alerts for your area. We'll notify you if conditions change.
              </Text>
            </View>
          ) : (
            <View className="space-y-4">
              <Text className="text-storm-50 text-xl font-semibold mb-2">
                Active Alerts ({filteredAlerts.length})
              </Text>
              
              {filteredAlerts.map((alert) => (
                <View 
                  key={alert.id}
                  className="bg-storm-800 rounded-lg border border-storm-700 overflow-hidden"
                >
                  {/* Alert Header */}
                  <View 
                    className="p-4 border-l-4"
                    style={{ borderLeftColor: weatherAlertsService.getSeverityColor(alert.severity) }}
                  >
                    <View className="flex-row items-start justify-between">
                      <View className="flex-1">
                        <View className="flex-row items-center mb-2">
                          <Text className="text-2xl mr-2">
                            {weatherAlertsService.getSeverityIcon(alert.event)}
                          </Text>
                          <View className="flex-1">
                            <Text className="text-storm-50 font-semibold text-lg">
                              {alert.title}
                            </Text>
                            <Text className="text-storm-400 text-sm capitalize">
                              {alert.severity} • {alert.urgency}
                            </Text>
                          </View>
                        </View>
                        
                        <Text className="text-storm-300 mb-3 leading-5">
                          {alert.headline || alert.description}
                        </Text>
                        
                        <View className="flex-row items-center justify-between">
                          <View>
                            <Text className="text-storm-400 text-xs">
                              Effective: {formatDate(alert.effective)}
                            </Text>
                            <Text className="text-storm-400 text-xs">
                              Expires: {formatDate(alert.expires)}
                            </Text>
                          </View>
                          
                          <Pressable
                            onPress={() => handleDismissAlert(alert.id, alert.title)}
                            className="p-2"
                          >
                            <Ionicons name="close-circle" size={20} color="#64748b" />
                          </Pressable>
                        </View>
                      </View>
                    </View>
                  </View>
                  
                  {/* Alert Instructions */}
                  {alert.instruction && (
                    <View className="px-4 pb-4">
                      <Text className="text-storm-400 text-sm font-medium mb-1">
                        Instructions:
                      </Text>
                      <Text className="text-storm-300 text-sm leading-5">
                        {alert.instruction}
                      </Text>
                    </View>
                  )}
                </View>
              ))}
            </View>
          )}
        </View>
      </ScrollView>

      {/* Settings Modal */}
      <Modal
        visible={showSettings}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View className="flex-1 bg-storm-900" style={{ paddingTop: insets.top }}>
          <View className="flex-row items-center justify-between p-4 border-b border-storm-700">
            <Pressable onPress={() => setShowSettings(false)}>
              <Text className="text-lightning-400 font-medium">Cancel</Text>
            </Pressable>
            <Text className="text-lg font-semibold text-storm-50">Alert Settings</Text>
            <Pressable onPress={handleSaveSettings}>
              <Text className="text-lightning-400 font-medium">Save</Text>
            </Pressable>
          </View>
          
          <ScrollView className="flex-1 p-4">
            {/* Enable/Disable Alerts */}
            <View className="bg-storm-800 rounded-lg p-4 mb-4 border border-storm-700">
              <View className="flex-row items-center justify-between">
                <View className="flex-1">
                  <Text className="text-storm-50 font-semibold">Weather Alerts</Text>
                  <Text className="text-storm-400 text-sm">
                    Receive notifications for severe weather
                  </Text>
                </View>
                <Pressable
                  onPress={toggleAlertsEnabled}
                  className={`w-12 h-6 rounded-full ${
                    alertsEnabled ? 'bg-lightning-500' : 'bg-storm-600'
                  }`}
                >
                  <View className={`w-5 h-5 bg-white rounded-full mt-0.5 ${
                    alertsEnabled ? 'ml-6' : 'ml-0.5'
                  }`} />
                </Pressable>
              </View>
            </View>

            {/* Severity Filter */}
            <View className="bg-storm-800 rounded-lg p-4 border border-storm-700">
              <Text className="text-storm-50 font-semibold mb-3">Alert Severity</Text>
              <Text className="text-storm-400 text-sm mb-4">
                Choose which severity levels to receive
              </Text>
              
              <View className="space-y-3">
                {severityOptions.map((option) => (
                  <Pressable
                    key={option.id}
                    onPress={() => {
                      if (selectedSeverities.includes(option.id)) {
                        setSelectedSeverities(prev => prev.filter(s => s !== option.id));
                      } else {
                        setSelectedSeverities(prev => [...prev, option.id]);
                      }
                    }}
                    className="flex-row items-center"
                  >
                    <View className={`w-5 h-5 rounded border-2 mr-3 items-center justify-center ${
                      selectedSeverities.includes(option.id)
                        ? 'bg-lightning-500 border-lightning-500'
                        : 'border-storm-600'
                    }`}>
                      {selectedSeverities.includes(option.id) && (
                        <Ionicons name="checkmark" size={12} color="white" />
                      )}
                    </View>
                    <View 
                      className="w-4 h-4 rounded mr-3"
                      style={{ backgroundColor: option.color }}
                    />
                    <Text className="text-storm-50 font-medium">{option.label}</Text>
                  </Pressable>
                ))}
              </View>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </>
  );
}