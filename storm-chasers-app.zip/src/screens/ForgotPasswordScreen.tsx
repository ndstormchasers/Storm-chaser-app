import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/auth';
import { AuthStackParamList } from '../types';

type ForgotPasswordScreenNavigationProp = NativeStackNavigationProp<AuthStackParamList, 'ForgotPassword'>;

export default function ForgotPasswordScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<ForgotPasswordScreenNavigationProp>();
  const { resetPassword, isLoading } = useAuthStore();

  const [email, setEmail] = useState('');
  const [emailSent, setEmailSent] = useState(false);
  const [error, setError] = useState('');

  const validateEmail = (email: string) => {
    return /\S+@\S+\.\S+/.test(email);
  };

  const handleResetPassword = async () => {
    if (!email.trim()) {
      setError('Email is required');
      return;
    }

    if (!validateEmail(email)) {
      setError('Please enter a valid email address');
      return;
    }

    const success = await resetPassword(email.trim());
    
    if (success) {
      setEmailSent(true);
      setError('');
    } else {
      setError('No account found with this email address');
    }
  };

  if (emailSent) {
    return (
      <View className="flex-1 bg-white" style={{ paddingTop: insets.top }}>
        <View className="px-6 pt-8">
          <Pressable 
            onPress={() => navigation.goBack()}
            className="mb-6"
          >
            <Ionicons name="chevron-back" size={24} color="#374151" />
          </Pressable>
        </View>

        <View className="flex-1 px-6 justify-center items-center">
          <View className="w-20 h-20 bg-green-100 rounded-full items-center justify-center mb-6">
            <Ionicons name="mail" size={40} color="#10b981" />
          </View>
          
          <Text className="text-2xl font-bold text-gray-900 text-center mb-4">
            Check Your Email
          </Text>
          
          <Text className="text-gray-600 text-center mb-8 leading-6">
            We've sent password reset instructions to{'\n'}
            <Text className="font-semibold">{email}</Text>
          </Text>

          <Pressable
            onPress={() => navigation.navigate('Login')}
            className="bg-red-500 py-4 px-8 rounded-lg mb-4"
          >
            <Text className="text-white font-semibold text-center">
              Back to Sign In
            </Text>
          </Pressable>

          <Pressable
            onPress={() => {
              setEmailSent(false);
              setEmail('');
            }}
            className="py-2"
          >
            <Text className="text-red-500 font-medium">
              Didn't receive email? Try again
            </Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView 
      className="flex-1 bg-white"
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ paddingTop: insets.top }}
    >
      {/* Header */}
      <View className="px-6 pt-8 pb-6">
        <Pressable 
          onPress={() => navigation.goBack()}
          className="mb-6"
        >
          <Ionicons name="chevron-back" size={24} color="#374151" />
        </Pressable>
        
        <Text className="text-3xl font-bold text-gray-900 mb-2">Reset Password</Text>
        <Text className="text-gray-600">
          Enter your email address and we'll send you instructions to reset your password
        </Text>
      </View>

      {/* Form */}
      <View className="px-6">
        <View className="mb-6">
          <Text className="text-sm font-medium text-gray-700 mb-2">Email Address</Text>
          <View className="relative">
            <TextInput
              value={email}
              onChangeText={(text) => {
                setEmail(text);
                if (error) setError('');
              }}
              placeholder="Enter your email"
              className={`bg-gray-50 border rounded-lg px-4 py-3 pr-12 ${
                error ? 'border-red-500' : 'border-gray-300'
              }`}
              keyboardType="email-address"
              autoCapitalize="none"
              autoComplete="email"
            />
            <View className="absolute right-3 top-3">
              <Ionicons name="mail" size={20} color="#9CA3AF" />
            </View>
          </View>
          {error && (
            <Text className="text-red-500 text-sm mt-1">{error}</Text>
          )}
        </View>

        <Pressable
          onPress={handleResetPassword}
          disabled={isLoading}
          className={`py-4 rounded-lg ${
            isLoading ? 'bg-gray-400' : 'bg-red-500'
          }`}
        >
          <View className="flex-row items-center justify-center">
            {isLoading && (
              <View className="mr-2">
                <Ionicons name="hourglass" size={20} color="white" />
              </View>
            )}
            <Text className="text-white font-semibold text-lg">
              {isLoading ? 'Sending...' : 'Send Reset Instructions'}
            </Text>
          </View>
        </Pressable>

        {/* Back to Login */}
        <View className="flex-row items-center justify-center pt-8">
          <Text className="text-gray-600">Remember your password? </Text>
          <Pressable onPress={() => navigation.navigate('Login')}>
            <Text className="text-red-500 font-semibold">Sign In</Text>
          </Pressable>
        </View>
      </View>

      {/* Demo Info */}
      <View className="px-6 mt-8">
        <View className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <View className="flex-row items-center mb-2">
            <Ionicons name="information-circle" size={20} color="#2563eb" />
            <Text className="text-blue-800 font-semibold ml-2">Demo Mode</Text>
          </View>
          <Text className="text-blue-700 text-sm">
            In demo mode, any valid email address will receive a "password reset" confirmation.
          </Text>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}