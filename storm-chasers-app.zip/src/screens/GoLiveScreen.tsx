import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, TextInput, Alert, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useStormChaserStore } from '../state/stormChasers';
import { LiveStream } from '../types';
import { STREAMING_PLATFORMS, mockService, StreamPlatform } from '../api/streaming-services';

export default function GoLiveScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const { addLiveStream } = useStormChaserStore();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [weatherCondition, setWeatherCondition] = useState('');
  const [selectedPlatform, setSelectedPlatform] = useState<StreamPlatform | null>(null);
  const [isStarting, setIsStarting] = useState(false);
  const [showPlatformModal, setShowPlatformModal] = useState(false);
  const [streamInstructions, setStreamInstructions] = useState<string | null>(null);
  const [showInstructionsModal, setShowInstructionsModal] = useState(false);

  const weatherOptions = [
    'Severe Thunderstorm',
    'Tornado Warning',
    'Hailstorm',
    'Supercell',
    'Squall Line',
    'Mesocyclone',
    'Wall Cloud',
    'Funnel Cloud',
  ];

  const startLiveStream = async () => {
    if (!title.trim() || !location.trim()) {
      Alert.alert('Missing Information', 'Please fill in the title and location fields.');
      return;
    }

    if (!selectedPlatform) {
      Alert.alert('Select Platform', 'Please choose a streaming platform.');
      return;
    }

    setIsStarting(true);
    
    try {
      // Use mock service for demo (in production, you'd use real APIs based on platform)
      const streamResult = await mockService.createMockStream(
        selectedPlatform.id,
        title.trim(),
        description.trim()
      );

      if (streamResult.success) {
        const newStream: LiveStream = {
          id: Date.now().toString(),
          chaserId: '1', // Using Jake Storm as current user
          title: title.trim(),
          description: description.trim() || 'Live storm chasing',
          viewers: 0,
          startTime: new Date(),
          location: location.trim(),
          weatherCondition: weatherCondition || 'Severe Weather',
          thumbnail: getWeatherEmoji(weatherCondition),
          platform: selectedPlatform.id,
          streamUrl: streamResult.streamUrl,
          streamKey: streamResult.streamKey,
          broadcastId: streamResult.broadcastId,
        };

        addLiveStream(newStream);
        setStreamInstructions(
          `🎯 Stream Setup Complete!\n\n` +
          `Platform: ${selectedPlatform.name}\n` +
          `RTMP URL: ${streamResult.streamUrl}\n` +
          `Stream Key: ${streamResult.streamKey}\n\n` +
          `${streamResult.instructions}\n\n` +
          `⚠️ Keep your stream key private!`
        );
        setShowInstructionsModal(true);
        
        // Clear form
        setTitle('');
        setDescription('');
        setLocation('');
        setWeatherCondition('');
        setSelectedPlatform(null);
      } else {
        Alert.alert('Stream Setup Failed', 'Unable to create stream. Please try again.');
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to set up stream. Please check your connection and try again.');
    } finally {
      setIsStarting(false);
    }
  };

  const getWeatherEmoji = (condition: string) => {
    const emojiMap: { [key: string]: string } = {
      'Severe Thunderstorm': '⛈️',
      'Tornado Warning': '🌪️',
      'Hailstorm': '🧊',
      'Supercell': '🌩️',
      'Squall Line': '⛈️',
      'Mesocyclone': '🌀',
      'Wall Cloud': '☁️',
      'Funnel Cloud': '🌪️',
    };
    return emojiMap[condition] || '⛈️';
  };

  return (
    <>
      <ScrollView 
        className="flex-1 bg-storm-900"
        style={{ paddingTop: insets.top }}
      >
        {/* Header */}
        <View className="px-4 py-6 bg-storm-800 border-b border-storm-700">
          <Text className="text-3xl font-bold text-storm-50">Go Live</Text>
          <Text className="text-lightning-300 mt-1">Start broadcasting your storm chase</Text>
        </View>

        {/* Platform Selection */}
        <View className="px-4 py-6">
          <View className="bg-storm-800 rounded-lg p-6 shadow-lg border border-storm-700 mb-4">
            <Text className="text-lg font-semibold text-storm-50 mb-4">Choose Platform</Text>
            
            {selectedPlatform ? (
              <Pressable
                onPress={() => setShowPlatformModal(true)}
                className="flex-row items-center justify-between p-4 border border-gray-300 rounded-lg"
                style={{ borderColor: selectedPlatform.color }}
              >
                <View className="flex-row items-center">
                  <Text className="text-2xl mr-3">{selectedPlatform.icon}</Text>
                  <View>
                    <Text className="font-medium text-storm-50">{selectedPlatform.name}</Text>
                    <Text className="text-sm text-storm-400">Tap to change</Text>
                  </View>
                </View>
                <Ionicons name="chevron-down" size={20} color="#6b7280" />
              </Pressable>
            ) : (
              <Pressable
                onPress={() => setShowPlatformModal(true)}
                className="flex-row items-center justify-center p-4 border border-gray-300 border-dashed rounded-lg"
              >
                <Ionicons name="add-circle-outline" size={24} color="#6b7280" />
                <Text className="text-storm-400 ml-2 font-medium">Select Streaming Platform</Text>
              </Pressable>
            )}
          </View>
        </View>

        {/* Stream Setup Form */}
        <View className="px-4">
          <View className="bg-storm-800 rounded-lg p-6 shadow-lg border border-storm-700">
            <Text className="text-lg font-semibold text-storm-50 mb-4">Stream Details</Text>
            
            {/* Title */}
            <View className="mb-4">
              <Text className="text-sm font-medium text-storm-300 mb-2">Stream Title *</Text>
              <TextInput
                value={title}
                onChangeText={setTitle}
                placeholder="e.g., Supercell Developing Near Moore, OK"
                className="bg-storm-700 border border-storm-600 rounded-lg px-3 py-2 text-storm-50"
                maxLength={100}
              />
            </View>

            {/* Description */}
            <View className="mb-4">
              <Text className="text-sm font-medium text-gray-700 mb-2">Description</Text>
              <TextInput
                value={description}
                onChangeText={setDescription}
                placeholder="Describe what you're tracking..."
                className="bg-storm-700 border border-storm-600 rounded-lg px-3 py-2 text-storm-50"
                multiline
                numberOfLines={3}
                maxLength={200}
              />
            </View>

            {/* Location */}
            <View className="mb-4">
              <Text className="text-sm font-medium text-storm-300 mb-2">Location *</Text>
              <TextInput
                value={location}
                onChangeText={setLocation}
                placeholder="e.g., Moore, Oklahoma"
                className="bg-storm-700 border border-storm-600 rounded-lg px-3 py-2 text-storm-50"
                maxLength={50}
              />
            </View>

            {/* Weather Condition */}
            <View className="mb-6">
              <Text className="text-sm font-medium text-storm-300 mb-2">Weather Condition</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} className="mb-2">
                {weatherOptions.map((option) => (
                  <Pressable
                    key={option}
                    onPress={() => setWeatherCondition(option)}
                    className={`mr-2 px-3 py-2 rounded-full border ${
                      weatherCondition === option
                        ? 'bg-lightning-500 border-lightning-500'
                        : 'bg-storm-700 border-storm-600'
                    }`}
                  >
                    <Text className={`text-sm ${
                      weatherCondition === option ? 'text-white' : 'text-storm-300'
                    }`}>
                      {option}
                    </Text>
                  </Pressable>
                ))}
              </ScrollView>
              <TextInput
                value={weatherCondition}
                onChangeText={setWeatherCondition}
                placeholder="Or enter custom condition"
                className="bg-storm-700 border border-storm-600 rounded-lg px-3 py-2 text-storm-50"
              />
            </View>

            {/* Start Stream Button */}
            <Pressable
              onPress={startLiveStream}
              disabled={isStarting || !selectedPlatform}
              className={`py-4 rounded-lg ${
                isStarting || !selectedPlatform ? 'bg-storm-600' : 'bg-lightning-500'
              }`}
            >
              <View className="flex-row items-center justify-center">
                {isStarting ? (
                  <>
                    <Ionicons name="hourglass" size={20} color="white" />
                    <Text className="text-white font-semibold ml-2">Setting up stream...</Text>
                  </>
                ) : (
                  <>
                    <Ionicons name="radio" size={20} color="white" />
                    <Text className="text-white font-semibold ml-2">Set Up Live Stream</Text>
                  </>
                )}
              </View>
            </Pressable>
          </View>
        </View>

        {/* Safety Tips */}
        <View className="px-4 py-6">
          <View className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <View className="flex-row items-center mb-2">
              <Ionicons name="warning" size={20} color="#d97706" />
              <Text className="text-yellow-800 font-semibold ml-2">Safety First</Text>
            </View>
            <Text className="text-yellow-700 text-sm leading-5">
              Always prioritize your safety while storm chasing. Never chase alone, maintain safe distances from storms, and have multiple escape routes planned.
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* Platform Selection Modal */}
      <Modal
        visible={showPlatformModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View className="flex-1 bg-white">
          <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
            <Text className="text-lg font-semibold">Choose Platform</Text>
            <Pressable onPress={() => setShowPlatformModal(false)}>
              <Ionicons name="close" size={24} color="#6b7280" />
            </Pressable>
          </View>
          
          <ScrollView className="flex-1 p-4">
            {STREAMING_PLATFORMS.map((platform) => (
              <Pressable
                key={platform.id}
                onPress={() => {
                  setSelectedPlatform(platform);
                  setShowPlatformModal(false);
                }}
                className="flex-row items-center p-4 mb-3 border border-gray-200 rounded-lg"
              >
                <Text className="text-3xl mr-4">{platform.icon}</Text>
                <View className="flex-1">
                  <Text className="font-semibold text-gray-900">{platform.name}</Text>
                  <Text className="text-sm text-gray-600">
                    {platform.requiresAuth ? 'Requires authentication' : 'No auth required'}
                  </Text>
                </View>
                {selectedPlatform?.id === platform.id && (
                  <Ionicons name="checkmark-circle" size={24} color={platform.color} />
                )}
              </Pressable>
            ))}
          </ScrollView>
        </View>
      </Modal>

      {/* Stream Instructions Modal */}
      <Modal
        visible={showInstructionsModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View className="flex-1 bg-white">
          <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
            <Text className="text-lg font-semibold">Stream Ready!</Text>
            <Pressable onPress={() => setShowInstructionsModal(false)}>
              <Ionicons name="close" size={24} color="#6b7280" />
            </Pressable>
          </View>
          
          <ScrollView className="flex-1 p-4">
            <View className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
              <Text className="text-green-800 whitespace-pre-line">{streamInstructions}</Text>
            </View>
            
            <View className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
              <Text className="text-blue-800 font-semibold mb-2">Next Steps:</Text>
              <Text className="text-blue-700">
                1. Copy the RTMP URL and Stream Key{'\n'}
                2. Open OBS Studio or your streaming software{'\n'}
                3. Add the RTMP URL as your streaming server{'\n'}
                4. Enter your stream key{'\n'}
                5. Start streaming!
              </Text>
            </View>

            <Pressable
              onPress={() => {
                setShowInstructionsModal(false);
                navigation.navigate('LiveStreams');
              }}
              className="mt-4 bg-red-500 py-4 rounded-lg"
            >
              <Text className="text-white font-semibold text-center">View Live Streams</Text>
            </Pressable>
          </ScrollView>
        </View>
      </Modal>
    </>
  );
}