import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Pressable, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { gamificationService, Achievement, UserProgress, LeaderboardEntry } from '../api/gamification';

export default function GamificationScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const [userProgress, setUserProgress] = useState<UserProgress | null>(null);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedTab, setSelectedTab] = useState<'overview' | 'achievements' | 'leaderboard'>('overview');

  const loadGamificationData = async () => {
    try {
      const [progress, allAchievements, leaders] = await Promise.all([
        gamificationService.getUserProgress('current-user'),
        gamificationService.getAchievements(),
        gamificationService.getLeaderboard('weekly')
      ]);
      setUserProgress(progress);
      setAchievements(allAchievements);
      setLeaderboard(leaders);
    } catch (error) {
      console.error('Failed to load gamification data:', error);
    }
  };

  useEffect(() => {
    loadGamificationData();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadGamificationData();
    setRefreshing(false);
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return '#6b7280';
      case 'uncommon': return '#22c55e';
      case 'rare': return '#3b82f6';
      case 'epic': return '#8b5cf6';
      case 'legendary': return '#f59e0b';
      default: return '#6b7280';
    }
  };

  const getRarityEmoji = (rarity: string) => {
    switch (rarity) {
      case 'common': return '⚪';
      case 'uncommon': return '🟢';
      case 'rare': return '🔵';
      case 'epic': return '🟣';
      case 'legendary': return '🟡';
      default: return '⚪';
    }
  };

  const getCategoryEmoji = (category: string) => {
    switch (category) {
      case 'chase': return '🌪️';
      case 'safety': return '🛡️';
      case 'community': return '👥';
      case 'education': return '📚';
      case 'streaming': return '📹';
      default: return '⭐';
    }
  };

  const getXPToNextLevel = () => {
    if (!userProgress) return 0;
    const currentLevelXP = userProgress.level * 1000;
    const nextLevelXP = (userProgress.level + 1) * 1000;
    return nextLevelXP - userProgress.total_xp;
  };

  const getXPProgress = () => {
    if (!userProgress) return 0;
    const currentLevelXP = userProgress.level * 1000;
    const nextLevelXP = (userProgress.level + 1) * 1000;
    const progress = (userProgress.total_xp - currentLevelXP) / (nextLevelXP - currentLevelXP);
    return Math.max(0, Math.min(1, progress));
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'home-outline' },
    { id: 'achievements', label: 'Achievements', icon: 'trophy-outline' },
    { id: 'leaderboard', label: 'Leaderboard', icon: 'podium-outline' }
  ];

  return (
    <ScrollView 
      className="flex-1 bg-storm-900"
      style={{ paddingTop: insets.top }}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={onRefresh}
          tintColor="#38bdf8"
        />
      }
    >
      {/* Header */}
      <View className="px-4 py-6 bg-storm-800 border-b border-storm-700">
        <View className="flex-row items-center justify-between">
          <View>
            <Text className="text-3xl font-bold text-storm-50">Chase Achievements</Text>
            <Text className="text-lightning-300 mt-1">Level up your storm chasing</Text>
          </View>
          <Pressable onPress={() => navigation.goBack()}>
            <Ionicons name="close" size={24} color="#64748b" />
          </Pressable>
        </View>
      </View>

      {/* Tab Navigation */}
      <View className="px-4 py-3 bg-storm-800 border-b border-storm-700">
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View className="flex-row space-x-2">
            {tabs.map((tab) => (
              <Pressable
                key={tab.id}
                onPress={() => setSelectedTab(tab.id as any)}
                className={`flex-row items-center px-4 py-2 rounded-lg ${
                  selectedTab === tab.id ? 'bg-lightning-600' : 'bg-storm-700'
                }`}
              >
                <Ionicons 
                  name={tab.icon as any} 
                  size={16} 
                  color={selectedTab === tab.id ? '#ffffff' : '#94a3b8'} 
                />
                <Text className={`ml-2 font-medium ${
                  selectedTab === tab.id ? 'text-white' : 'text-storm-300'
                }`}>
                  {tab.label}
                </Text>
              </Pressable>
            ))}
          </View>
        </ScrollView>
      </View>

      {/* Overview Tab */}
      {selectedTab === 'overview' && userProgress && (
        <View className="p-4">
          {/* Level Card */}
          <View className="bg-gradient-to-r from-lightning-800 to-storm-800 rounded-xl p-4 mb-4 border border-lightning-600">
            <View className="flex-row items-center justify-between mb-3">
              <View>
                <Text className="text-2xl font-bold text-storm-50">Level {userProgress.level}</Text>
                <Text className="text-lightning-300">Storm Chaser</Text>
              </View>
              <View className="w-16 h-16 bg-lightning-600 rounded-full items-center justify-center">
                <Text className="text-2xl">⚡</Text>
              </View>
            </View>
            
            <View className="mb-2">
              <View className="flex-row justify-between mb-1">
                <Text className="text-storm-300 text-sm">Progress to Level {userProgress.level + 1}</Text>
                <Text className="text-storm-300 text-sm">{getXPToNextLevel()} XP needed</Text>
              </View>
              <View className="w-full h-2 bg-storm-700 rounded-full">
                <View 
                  className="h-2 bg-lightning-400 rounded-full"
                  style={{ width: `${getXPProgress() * 100}%` }}
                />
              </View>
            </View>
            
            <Text className="text-lightning-200 text-sm">
              Total XP: {userProgress.total_xp.toLocaleString()}
            </Text>
          </View>

          {/* Stats Grid */}
          <View className="grid grid-cols-2 gap-3 mb-4">
            <View className="bg-storm-800 rounded-lg p-3 border border-storm-700">
              <Text className="text-storm-400 text-xs">Achievements</Text>
              <Text className="text-storm-50 text-xl font-bold">
                {achievements.filter(a => a.unlocked).length}
              </Text>
              <Text className="text-storm-400 text-xs">
                of {achievements.length}
              </Text>
            </View>
            <View className="bg-storm-800 rounded-lg p-3 border border-storm-700">
              <Text className="text-storm-400 text-xs">Current Streak</Text>
              <Text className="text-storm-50 text-xl font-bold">{userProgress.current_streak}</Text>
              <Text className="text-storm-400 text-xs">days</Text>
            </View>
          </View>

          {/* Recent Achievements */}
          <Text className="text-lg font-semibold text-storm-50 mb-3">Recent Achievements</Text>
          {achievements.filter(a => a.unlocked).slice(0, 5).map((achievement) => (
            <View
              key={achievement.id}
              className="bg-storm-800 rounded-lg p-3 mb-2 border border-storm-700"
            >
              <View className="flex-row items-center">
                <Text className="text-2xl mr-3">{getCategoryEmoji(achievement.category)}</Text>
                <View className="flex-1">
                  <Text className="font-semibold text-storm-50">{achievement.title}</Text>
                  <Text className="text-storm-400 text-sm">{achievement.description}</Text>
                </View>
                <View className="items-end">
                  <Text className="text-lightning-400 font-bold">+{achievement.points}</Text>
                  <Text className="text-xs" style={{ color: getRarityColor(achievement.rarity) }}>
                    {achievement.rarity}
                  </Text>
                </View>
              </View>
            </View>
          ))}
        </View>
      )}

      {/* Achievements Tab */}
      {selectedTab === 'achievements' && (
        <View className="p-4">
          <Text className="text-lg font-semibold text-storm-50 mb-4">All Achievements</Text>
          
          {/* Category Filter */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} className="mb-4">
            <View className="flex-row space-x-2">
              {['all', 'chase', 'safety', 'community', 'education', 'streaming'].map((category) => (
                <Pressable
                  key={category}
                  className="px-3 py-1 bg-storm-800 rounded-full border border-storm-700"
                >
                  <Text className="text-storm-300 text-sm capitalize">{category}</Text>
                </Pressable>
              ))}
            </View>
          </ScrollView>

          {achievements.map((achievement) => (
            <View
              key={achievement.id}
              className={`rounded-lg p-4 mb-3 border ${
                achievement.unlocked 
                  ? 'bg-storm-800 border-storm-700' 
                  : 'bg-storm-850 border-storm-750 opacity-60'
              }`}
            >
              <View className="flex-row items-start">
                <View className="mr-3">
                  <Text className="text-2xl">{getCategoryEmoji(achievement.category)}</Text>
                  <Text className="text-lg mt-1">{getRarityEmoji(achievement.rarity)}</Text>
                </View>
                <View className="flex-1">
                  <View className="flex-row items-center justify-between mb-2">
                    <Text className={`font-semibold ${
                      achievement.unlocked ? 'text-storm-50' : 'text-storm-400'
                    }`}>
                      {achievement.title}
                    </Text>
                    {achievement.unlocked && (
                      <View className="bg-lightning-600 px-2 py-1 rounded">
                        <Text className="text-white text-xs font-medium">
                          +{achievement.points} XP
                        </Text>
                      </View>
                    )}
                  </View>
                  <Text className={`text-sm ${
                    achievement.unlocked ? 'text-storm-300' : 'text-storm-500'
                  }`}>
                    {achievement.description}
                  </Text>
                  <View className="flex-row items-center mt-2">
                    <Text 
                      className="text-xs px-2 py-1 rounded-full font-medium"
                      style={{ 
                        color: getRarityColor(achievement.rarity),
                        backgroundColor: `${getRarityColor(achievement.rarity)}20`
                      }}
                    >
                      {achievement.rarity.toUpperCase()}
                    </Text>
                    <Text className="text-storm-400 text-xs ml-2 capitalize">
                      {achievement.category}
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          ))}
        </View>
      )}

      {/* Leaderboard Tab */}
      {selectedTab === 'leaderboard' && (
        <View className="p-4">
          <Text className="text-lg font-semibold text-storm-50 mb-4">Weekly Leaderboard</Text>
          
          {leaderboard.map((entry, index) => (
            <View
              key={entry.user_id}
              className={`rounded-lg p-4 mb-3 border ${
                index < 3 ? 'bg-gradient-to-r from-lightning-800 to-storm-800 border-lightning-600' : 'bg-storm-800 border-storm-700'
              }`}
            >
              <View className="flex-row items-center">
                <View className="w-8 items-center mr-3">
                  <Text className="text-xl font-bold text-storm-50">
                    {index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `#${index + 1}`}
                  </Text>
                </View>
                <View className="w-12 h-12 bg-lightning-900 rounded-full items-center justify-center mr-3">
                  <Text className="text-xl">{entry.avatar}</Text>
                </View>
                <View className="flex-1">
                  <Text className="font-semibold text-storm-50">{entry.username}</Text>
                  <Text className="text-storm-400 text-sm">Level {entry.level}</Text>
                </View>
                <View className="items-end">
                  <Text className="font-bold text-lightning-400">{entry.weekly_xp.toLocaleString()}</Text>
                  <Text className="text-storm-400 text-xs">XP this week</Text>
                </View>
              </View>
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
}