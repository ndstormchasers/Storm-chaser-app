export interface Course {
  id: string;
  title: string;
  description: string;
  category: 'safety' | 'meteorology' | 'photography' | 'streaming' | 'equipment' | 'advanced';
  difficulty: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  duration: number; // minutes
  prerequisites: string[];
  instructor: {
    name: string;
    credentials: string[];
    avatar: string;
    experience: string;
  };
  modules: Module[];
  certification: {
    available: boolean;
    requirements: string[];
    validFor: number; // months
    renewalRequired: boolean;
  };
  rating: number;
  enrollments: number;
  completionRate: number;
  price: number; // 0 for free courses
  featured: boolean;
  tags: string[];
}

export interface Module {
  id: string;
  title: string;
  type: 'video' | 'text' | 'interactive' | 'quiz' | 'simulation' | 'field_exercise';
  duration: number; // minutes
  content: ModuleContent;
  completed: boolean;
  score?: number;
  unlocked: boolean;
  required: boolean;
}

export interface ModuleContent {
  videoUrl?: string;
  textContent?: string;
  interactiveElements?: InteractiveElement[];
  quiz?: Quiz;
  simulation?: Simulation;
  resources?: Resource[];
}

export interface InteractiveElement {
  type: 'radar_analysis' | 'storm_identification' | 'safety_scenario' | 'equipment_check';
  data: any;
  instructions: string;
  feedback: string;
}

export interface Quiz {
  questions: Question[];
  passingScore: number;
  timeLimit?: number; // minutes
  attempts: number;
  currentAttempt: number;
}

export interface Question {
  id: string;
  type: 'multiple_choice' | 'true_false' | 'fill_blank' | 'drag_drop' | 'image_analysis';
  question: string;
  options?: string[];
  correctAnswer: string | string[];
  explanation: string;
  points: number;
  image?: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface Simulation {
  type: 'storm_chase' | 'radar_interpretation' | 'safety_decision' | 'equipment_setup';
  scenario: string;
  objectives: string[];
  timeLimit?: number;
  scoring: {
    maxPoints: number;
    criteria: Array<{ action: string; points: number }>;
  };
}

export interface Resource {
  title: string;
  type: 'pdf' | 'video' | 'website' | 'tool' | 'checklist';
  url: string;
  description: string;
  downloadable: boolean;
}

export interface Certification {
  id: string;
  name: string;
  description: string;
  level: 'basic' | 'intermediate' | 'advanced' | 'professional';
  requiredCourses: string[];
  optionalCourses: string[];
  practicalRequirements: string[];
  examRequired: boolean;
  validFor: number; // months
  renewable: boolean;
  recognizedBy: string[];
  benefits: string[];
  cost: number;
}

export interface UserProgress {
  courseId: string;
  enrolledAt: Date;
  lastAccessed: Date;
  currentModule: string;
  completedModules: string[];
  totalProgress: number; // 0-1
  quizScores: { [moduleId: string]: number };
  timeSpent: number; // minutes
  certificateEarned?: {
    date: Date;
    certificateId: string;
    score: number;
  };
  notes: string;
}

export interface FieldExercise {
  id: string;
  title: string;
  description: string;
  type: 'storm_spotting' | 'radar_verification' | 'safety_drill' | 'equipment_test';
  location: 'any' | 'specific' | 'virtual';
  requirements: string[];
  instructions: string[];
  completionCriteria: string[];
  verification: 'self_report' | 'mentor_verify' | 'photo_evidence' | 'gps_verify';
  points: number;
  seasonDependent: boolean;
}

class EducationSystemService {
  private readonly courses: Course[] = [
    {
      id: 'storm_safety_101',
      title: 'Storm Safety Fundamentals',
      description: 'Essential safety principles for storm chasing and severe weather awareness',
      category: 'safety',
      difficulty: 'beginner',
      duration: 120,
      prerequisites: [],
      instructor: {
        name: 'Dr. Sarah Weather',
        credentials: ['PhD Meteorology', 'Certified Storm Spotter', '15+ years experience'],
        avatar: '⛈️',
        experience: 'Former National Weather Service meteorologist with extensive field experience',
      },
      modules: [
        {
          id: 'safety_basics',
          title: 'Storm Safety Basics',
          type: 'video',
          duration: 30,
          content: {
            videoUrl: 'https://example.com/safety-basics.mp4',
            textContent: 'Understanding the fundamental principles of storm safety...',
            resources: [
              {
                title: 'Storm Safety Checklist',
                type: 'checklist',
                url: 'https://example.com/safety-checklist.pdf',
                description: 'Comprehensive pre-chase safety checklist',
                downloadable: true,
              },
            ],
          },
          completed: false,
          unlocked: true,
          required: true,
        },
        {
          id: 'weather_recognition',
          title: 'Recognizing Dangerous Weather',
          type: 'interactive',
          duration: 45,
          content: {
            interactiveElements: [
              {
                type: 'storm_identification',
                data: { /* storm images and data */ },
                instructions: 'Identify storm types and associated risks',
                feedback: 'Excellent! You correctly identified the supercell structure.',
              },
            ],
          },
          completed: false,
          unlocked: false,
          required: true,
        },
        {
          id: 'safety_quiz',
          title: 'Safety Knowledge Assessment',
          type: 'quiz',
          duration: 20,
          content: {
            quiz: {
              questions: [
                {
                  id: 'q1',
                  type: 'multiple_choice',
                  question: 'What is the minimum safe distance from a tornado?',
                  options: ['0.5 miles', '1 mile', '2 miles', '5 miles'],
                  correctAnswer: '1 mile',
                  explanation: 'Minimum safe distance is 1 mile, though 2+ miles is recommended.',
                  points: 10,
                  difficulty: 'easy',
                },
                {
                  id: 'q2',
                  type: 'true_false',
                  question: 'It is safe to chase storms alone.',
                  correctAnswer: 'false',
                  explanation: 'Never chase alone - always have a spotter or chase partner.',
                  points: 10,
                  difficulty: 'easy',
                },
              ],
              passingScore: 80,
              attempts: 3,
              currentAttempt: 0,
            },
          },
          completed: false,
          unlocked: false,
          required: true,
        },
      ],
      certification: {
        available: true,
        requirements: ['Complete all modules', 'Pass final exam with 85%'],
        validFor: 24,
        renewalRequired: true,
      },
      rating: 4.8,
      enrollments: 15420,
      completionRate: 87,
      price: 0,
      featured: true,
      tags: ['safety', 'beginner', 'required', 'certification'],
    },
    {
      id: 'advanced_meteorology',
      title: 'Advanced Storm Meteorology',
      description: 'Deep dive into storm dynamics, forecasting, and atmospheric science',
      category: 'meteorology',
      difficulty: 'advanced',
      duration: 480,
      prerequisites: ['storm_safety_101', 'basic_meteorology'],
      instructor: {
        name: 'Dr. Mike Thunder',
        credentials: ['PhD Atmospheric Science', 'Research Meteorologist', '20+ years'],
        avatar: '🌩️',
        experience: 'Leading researcher in mesocyclone dynamics and tornado genesis',
      },
      modules: [
        {
          id: 'supercell_dynamics',
          title: 'Supercell Thunderstorm Dynamics',
          type: 'video',
          duration: 90,
          content: {
            videoUrl: 'https://example.com/supercell-dynamics.mp4',
            textContent: 'Understanding the complex dynamics of supercell thunderstorms...',
          },
          completed: false,
          unlocked: true,
          required: true,
        },
        {
          id: 'tornado_formation',
          title: 'Tornadogenesis Processes',
          type: 'simulation',
          duration: 60,
          content: {
            simulation: {
              type: 'storm_chase',
              scenario: 'You are approaching a developing supercell with strong rotation visible',
              objectives: [
                'Identify mesocyclone signature',
                'Determine optimal positioning',
                'Assess tornado probability',
              ],
              timeLimit: 30,
              scoring: {
                maxPoints: 100,
                criteria: [
                  { action: 'Correct storm identification', points: 25 },
                  { action: 'Safe positioning', points: 30 },
                  { action: 'Accurate forecast', points: 45 },
                ],
              },
            },
          },
          completed: false,
          unlocked: false,
          required: true,
        },
      ],
      certification: {
        available: true,
        requirements: ['Complete all modules', 'Pass comprehensive exam', 'Field verification'],
        validFor: 36,
        renewalRequired: true,
      },
      rating: 4.9,
      enrollments: 3240,
      completionRate: 72,
      price: 149,
      featured: true,
      tags: ['meteorology', 'advanced', 'certification', 'professional'],
    },
    {
      id: 'photography_mastery',
      title: 'Storm Photography & Videography',
      description: 'Master the art of capturing stunning storm imagery',
      category: 'photography',
      difficulty: 'intermediate',
      duration: 240,
      prerequisites: ['storm_safety_101'],
      instructor: {
        name: 'Alex Storm-Shot',
        credentials: ['Professional Photographer', 'Storm Chasing Specialist', '10+ years'],
        avatar: '📸',
        experience: 'Award-winning storm photographer with images featured in National Geographic',
      },
      modules: [
        {
          id: 'camera_settings',
          title: 'Optimal Camera Settings for Storms',
          type: 'video',
          duration: 45,
          content: {
            videoUrl: 'https://example.com/camera-settings.mp4',
          },
          completed: false,
          unlocked: true,
          required: true,
        },
        {
          id: 'composition_techniques',
          title: 'Storm Composition Techniques',
          type: 'interactive',
          duration: 60,
          content: {
            interactiveElements: [
              {
                type: 'storm_identification',
                data: { /* photo examples */ },
                instructions: 'Analyze composition elements in these storm photos',
                feedback: 'Great eye for foreground elements!',
              },
            ],
          },
          completed: false,
          unlocked: false,
          required: true,
        },
      ],
      certification: {
        available: false,
        requirements: [],
        validFor: 0,
        renewalRequired: false,
      },
      rating: 4.7,
      enrollments: 8930,
      completionRate: 91,
      price: 79,
      featured: false,
      tags: ['photography', 'creative', 'intermediate'],
    },
    {
      id: 'streaming_production',
      title: 'Professional Storm Streaming',
      description: 'Build your storm chasing streaming career',
      category: 'streaming',
      difficulty: 'intermediate',
      duration: 300,
      prerequisites: ['storm_safety_101'],
      instructor: {
        name: 'StreamKing Pro',
        credentials: ['Top Storm Streamer', '1M+ Followers', 'Content Creator'],
        avatar: '🎥',
        experience: 'Professional storm streamer with multiple viral streams and brand partnerships',
      },
      modules: [
        {
          id: 'streaming_setup',
          title: 'Multi-Camera Streaming Setup',
          type: 'video',
          duration: 75,
          content: {
            videoUrl: 'https://example.com/streaming-setup.mp4',
          },
          completed: false,
          unlocked: true,
          required: true,
        },
        {
          id: 'audience_engagement',
          title: 'Building and Engaging Your Audience',
          type: 'text',
          duration: 45,
          content: {
            textContent: 'Strategies for building a loyal streaming audience...',
          },
          completed: false,
          unlocked: false,
          required: true,
        },
      ],
      certification: {
        available: false,
        requirements: [],
        validFor: 0,
        renewalRequired: false,
      },
      rating: 4.6,
      enrollments: 5670,
      completionRate: 79,
      price: 99,
      featured: false,
      tags: ['streaming', 'business', 'content_creation'],
    },
  ];

  private readonly certifications: Certification[] = [
    {
      id: 'certified_storm_spotter',
      name: 'Certified Storm Spotter',
      description: 'Official certification for storm spotting and safety',
      level: 'basic',
      requiredCourses: ['storm_safety_101'],
      optionalCourses: [],
      practicalRequirements: ['Complete 5 supervised chases', 'Submit storm reports'],
      examRequired: true,
      validFor: 24,
      renewable: true,
      recognizedBy: ['National Weather Service', 'Emergency Management'],
      benefits: ['Official recognition', 'Advanced weather alerts', 'Community status'],
      cost: 0,
    },
    {
      id: 'advanced_storm_chaser',
      name: 'Advanced Storm Chaser',
      description: 'Professional-level storm chasing certification',
      level: 'advanced',
      requiredCourses: ['storm_safety_101', 'advanced_meteorology'],
      optionalCourses: ['photography_mastery', 'streaming_production'],
      practicalRequirements: [
        'Document 25 storms',
        'Mentor 3 new chasers',
        'Contribute to research',
      ],
      examRequired: true,
      validFor: 36,
      renewable: true,
      recognizedBy: ['Storm Chasing Community', 'Weather Research Institutions'],
      benefits: ['Expert status', 'Research opportunities', 'Priority access'],
      cost: 299,
    },
  ];

  async enrollInCourse(userId: string, courseId: string): Promise<boolean> {
    try {
      const course = this.courses.find(c => c.id === courseId);
      if (!course) return false;

      // Check prerequisites
      const userProgress = await this.getUserProgress(userId);
      const hasPrerequisites = course.prerequisites.every(prereq => 
        userProgress.some(p => p.courseId === prereq && p.certificateEarned)
      );

      if (!hasPrerequisites) {
        throw new Error('Prerequisites not met');
      }

      // Enroll user
      const progress: UserProgress = {
        courseId,
        enrolledAt: new Date(),
        lastAccessed: new Date(),
        currentModule: course.modules[0].id,
        completedModules: [],
        totalProgress: 0,
        quizScores: {},
        timeSpent: 0,
        notes: '',
      };

      // Save progress (mock)
      console.log(`User ${userId} enrolled in course ${courseId}`);
      
      return true;
    } catch (error) {
      console.error('Error enrolling in course:', error);
      return false;
    }
  }

  async completeModule(userId: string, courseId: string, moduleId: string, score?: number): Promise<boolean> {
    try {
      // Update user progress
      console.log(`User ${userId} completed module ${moduleId} in course ${courseId}`);
      
      // Unlock next module
      const course = this.courses.find(c => c.id === courseId);
      if (course) {
        const moduleIndex = course.modules.findIndex(m => m.id === moduleId);
        if (moduleIndex < course.modules.length - 1) {
          course.modules[moduleIndex + 1].unlocked = true;
        }
      }

      // Award points for completion
      await this.awardPoints(userId, 50, 'module_completion');
      
      return true;
    } catch (error) {
      console.error('Error completing module:', error);
      return false;
    }
  }

  async getUserProgress(userId: string): Promise<UserProgress[]> {
    try {
      // Mock user progress
      return [
        {
          courseId: 'storm_safety_101',
          enrolledAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
          lastAccessed: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
          currentModule: 'weather_recognition',
          completedModules: ['safety_basics'],
          totalProgress: 0.33,
          quizScores: {},
          timeSpent: 45,
          notes: 'Great course, very informative!',
        },
      ];
    } catch (error) {
      console.error('Error getting user progress:', error);
      return [];
    }
  }

  async getRecommendedCourses(userId: string): Promise<Course[]> {
    try {
      const userProgress = await this.getUserProgress(userId);
      const completedCourses = userProgress.filter(p => p.certificateEarned).map(p => p.courseId);
      
      // Recommend based on completed courses and difficulty progression
      return this.courses.filter(course => {
        // Don't recommend completed courses
        if (completedCourses.includes(course.id)) return false;
        
        // Check if prerequisites are met
        const hasPrerequisites = course.prerequisites.every(prereq => 
          completedCourses.includes(prereq)
        );
        
        return hasPrerequisites;
      }).slice(0, 3);
    } catch (error) {
      console.error('Error getting recommended courses:', error);
      return [];
    }
  }

  async searchCourses(query: string, filters?: {
    category?: string;
    difficulty?: string;
    free?: boolean;
  }): Promise<Course[]> {
    try {
      let results = this.courses;

      // Apply text search
      if (query) {
        const searchTerm = query.toLowerCase();
        results = results.filter(course => 
          course.title.toLowerCase().includes(searchTerm) ||
          course.description.toLowerCase().includes(searchTerm) ||
          course.tags.some(tag => tag.toLowerCase().includes(searchTerm))
        );
      }

      // Apply filters
      if (filters) {
        if (filters.category) {
          results = results.filter(course => course.category === filters.category);
        }
        if (filters.difficulty) {
          results = results.filter(course => course.difficulty === filters.difficulty);
        }
        if (filters.free) {
          results = results.filter(course => course.price === 0);
        }
      }

      return results;
    } catch (error) {
      console.error('Error searching courses:', error);
      return [];
    }
  }

  getCourseCategories(): Array<{ id: string; name: string; icon: string; count: number }> {
    const categories = [
      { id: 'safety', name: 'Safety', icon: '🛡️' },
      { id: 'meteorology', name: 'Meteorology', icon: '🌪️' },
      { id: 'photography', name: 'Photography', icon: '📸' },
      { id: 'streaming', name: 'Streaming', icon: '🎥' },
      { id: 'equipment', name: 'Equipment', icon: '⚙️' },
      { id: 'advanced', name: 'Advanced', icon: '🎓' },
    ];

    return categories.map(cat => ({
      ...cat,
      count: this.courses.filter(course => course.category === cat.id).length,
    }));
  }

  getAllCourses(): Course[] {
    return this.courses;
  }

  getCourse(courseId: string): Course | null {
    return this.courses.find(c => c.id === courseId) || null;
  }

  getAvailableCertifications(): Certification[] {
    return this.certifications;
  }

  private async awardPoints(userId: string, points: number, source: string): Promise<void> {
    // Award points for educational activities
    console.log(`Awarding ${points} points to user ${userId} for ${source}`);
  }
}

export const educationSystemService = new EducationSystemService();