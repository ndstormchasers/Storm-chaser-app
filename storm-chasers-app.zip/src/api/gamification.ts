export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'chase' | 'safety' | 'community' | 'education' | 'streaming' | 'special';
  rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
  points: number;
  requirements: {
    type: string;
    target: number;
    current?: number;
  };
  unlocked: boolean;
  unlockedAt?: Date;
  progress: number; // 0-1
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  requirements: string[];
  seasonExclusive?: boolean;
  earnedAt?: Date;
}

export interface LeaderboardEntry {
  userId: string;
  username: string;
  avatar: string;
  score: number;
  rank: number;
  achievements: number;
  streamsCompleted: number;
  stormsChased: number;
  seasonPoints: number;
  trend: 'up' | 'down' | 'same';
  location: string;
}

export interface UserStats {
  totalPoints: number;
  currentLevel: number;
  nextLevelPoints: number;
  pointsToNextLevel: number;
  achievements: Achievement[];
  badges: Badge[];
  streaks: {
    currentChaseStreak: number;
    longestChaseStreak: number;
    currentStreamStreak: number;
    longestStreamStreak: number;
  };
  milestones: {
    totalChases: number;
    totalStreams: number;
    totalViewers: number;
    communitiesHelped: number;
    accuratePredictions: number;
  };
  seasonStats: {
    rank: number;
    points: number;
    achievements: number;
    specialEvents: number;
  };
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  type: 'daily' | 'weekly' | 'monthly' | 'seasonal' | 'special';
  category: 'chase' | 'stream' | 'social' | 'safety' | 'education';
  difficulty: 'easy' | 'medium' | 'hard' | 'extreme';
  rewards: {
    points: number;
    badges?: string[];
    achievements?: string[];
    exclusiveContent?: string[];
  };
  requirements: Array<{
    description: string;
    target: number;
    current: number;
    completed: boolean;
  }>;
  startDate: Date;
  endDate: Date;
  progress: number; // 0-1
  completed: boolean;
  participants: number;
}

export interface SeasonalEvent {
  id: string;
  name: string;
  description: string;
  theme: string;
  startDate: Date;
  endDate: Date;
  specialChallenges: Challenge[];
  exclusiveRewards: Achievement[];
  leaderboard: LeaderboardEntry[];
  active: boolean;
}

class GamificationService {
  private readonly LEVEL_POINT_MULTIPLIER = 1000;
  
  // Pre-defined achievements
  private readonly ACHIEVEMENTS: Omit<Achievement, 'unlocked' | 'progress' | 'requirements.current'>[] = [
    // Chase Achievements
    {
      id: 'first_chase',
      title: 'First Storm',
      description: 'Complete your first storm chase',
      icon: '🌪️',
      category: 'chase',
      rarity: 'common',
      points: 100,
      requirements: { type: 'storms_chased', target: 1 },
    },
    {
      id: 'tornado_witness',
      title: 'Tornado Witness',
      description: 'Successfully document a tornado',
      icon: '🌪️',
      category: 'chase',
      rarity: 'rare',
      points: 1000,
      requirements: { type: 'tornadoes_documented', target: 1 },
    },
    {
      id: 'storm_veteran',
      title: 'Storm Veteran',
      description: 'Chase 100 storms',
      icon: '⛈️',
      category: 'chase',
      rarity: 'epic',
      points: 5000,
      requirements: { type: 'storms_chased', target: 100 },
    },
    {
      id: 'supercell_master',
      title: 'Supercell Master',
      description: 'Document 25 supercell thunderstorms',
      icon: '🌩️',
      category: 'chase',
      rarity: 'rare',
      points: 2500,
      requirements: { type: 'supercells_documented', target: 25 },
    },
    
    // Streaming Achievements
    {
      id: 'first_stream',
      title: 'Going Live',
      description: 'Complete your first live stream',
      icon: '📹',
      category: 'streaming',
      rarity: 'common',
      points: 50,
      requirements: { type: 'streams_completed', target: 1 },
    },
    {
      id: 'viral_stream',
      title: 'Viral Storm',
      description: 'Reach 1000+ concurrent viewers',
      icon: '🔥',
      category: 'streaming',
      rarity: 'epic',
      points: 3000,
      requirements: { type: 'max_concurrent_viewers', target: 1000 },
    },
    {
      id: 'stream_marathon',
      title: 'Stream Marathon',
      description: 'Stream for 8+ hours continuously',
      icon: '⏰',
      category: 'streaming',
      rarity: 'rare',
      points: 1500,
      requirements: { type: 'longest_stream_hours', target: 8 },
    },
    
    // Safety Achievements
    {
      id: 'safety_first',
      title: 'Safety First',
      description: 'Complete storm safety course',
      icon: '🛡️',
      category: 'safety',
      rarity: 'common',
      points: 200,
      requirements: { type: 'safety_courses_completed', target: 1 },
    },
    {
      id: 'emergency_hero',
      title: 'Emergency Hero',
      description: 'Help someone during severe weather emergency',
      icon: '🚑',
      category: 'safety',
      rarity: 'legendary',
      points: 10000,
      requirements: { type: 'emergency_assists', target: 1 },
    },
    
    // Community Achievements
    {
      id: 'mentor',
      title: 'Storm Mentor',
      description: 'Help 10 new chasers learn the ropes',
      icon: '👨‍🏫',
      category: 'community',
      rarity: 'rare',
      points: 2000,
      requirements: { type: 'chasers_mentored', target: 10 },
    },
    {
      id: 'social_storm',
      title: 'Social Storm',
      description: 'Share storm content that gets 1000+ likes',
      icon: '❤️',
      category: 'community',
      rarity: 'uncommon',
      points: 500,
      requirements: { type: 'social_likes_received', target: 1000 },
    },
    
    // Special/Legendary Achievements
    {
      id: 'storm_god',
      title: 'Storm God',
      description: 'Achieve legendary status in all categories',
      icon: '⚡',
      category: 'special',
      rarity: 'legendary',
      points: 50000,
      requirements: { type: 'legendary_achievements', target: 5 },
    },
  ];

  private readonly BADGES: Badge[] = [
    {
      id: 'accuracy_expert',
      name: 'Prediction Expert',
      description: 'Make 10 accurate storm predictions',
      icon: '🎯',
      color: '#FFD700',
      requirements: ['10 accurate predictions'],
    },
    {
      id: 'night_chaser',
      name: 'Night Chaser',
      description: 'Successfully chase storms after dark',
      icon: '🌙',
      color: '#4B0082',
      requirements: ['5 night chases'],
    },
    {
      id: 'hail_hunter',
      name: 'Hail Hunter',
      description: 'Document giant hail (2+ inches)',
      icon: '🧊',
      color: '#87CEEB',
      requirements: ['Document giant hail'],
    },
  ];

  async getUserStats(userId: string): Promise<UserStats> {
    try {
      // Mock user stats - in production would fetch from database
      const totalPoints = 15750;
      const currentLevel = Math.floor(totalPoints / this.LEVEL_POINT_MULTIPLIER) + 1;
      const nextLevelPoints = currentLevel * this.LEVEL_POINT_MULTIPLIER;
      
      return {
        totalPoints,
        currentLevel,
        nextLevelPoints,
        pointsToNextLevel: nextLevelPoints - totalPoints,
        achievements: await this.getUserAchievements(userId),
        badges: this.getUserBadges(userId),
        streaks: {
          currentChaseStreak: 7,
          longestChaseStreak: 23,
          currentStreamStreak: 3,
          longestStreamStreak: 12,
        },
        milestones: {
          totalChases: 45,
          totalStreams: 28,
          totalViewers: 125000,
          communitiesHelped: 8,
          accuratePredictions: 89,
        },
        seasonStats: {
          rank: 156,
          points: 3420,
          achievements: 12,
          specialEvents: 2,
        },
      };
    } catch (error) {
      console.error('Error fetching user stats:', error);
      throw error;
    }
  }

  async getLeaderboard(type: 'global' | 'seasonal' | 'weekly', limit: number = 100): Promise<LeaderboardEntry[]> {
    try {
      // Mock leaderboard data
      const mockEntries: LeaderboardEntry[] = [
        {
          userId: '1',
          username: 'StormKing2024',
          avatar: '🌪️',
          score: 87500,
          rank: 1,
          achievements: 45,
          streamsCompleted: 156,
          stormsChased: 234,
          seasonPoints: 12500,
          trend: 'up',
          location: 'Oklahoma, USA',
        },
        {
          userId: '2',
          username: 'TornadoHunter',
          avatar: '⛈️',
          score: 76200,
          rank: 2,
          achievements: 38,
          streamsCompleted: 142,
          stormsChased: 198,
          seasonPoints: 11200,
          trend: 'same',
          location: 'Kansas, USA',
        },
        {
          userId: '3',
          username: 'StormChaser_Pro',
          avatar: '🌩️',
          score: 65800,
          rank: 3,
          achievements: 32,
          streamsCompleted: 98,
          stormsChased: 156,
          seasonPoints: 9800,
          trend: 'down',
          location: 'Texas, USA',
        },
      ];

      return mockEntries.slice(0, limit);
    } catch (error) {
      console.error('Error fetching leaderboard:', error);
      return [];
    }
  }

  async getActiveChallenges(userId: string): Promise<Challenge[]> {
    try {
      const now = new Date();
      
      return [
        {
          id: 'weekly_streamer',
          title: 'Weekly Streamer',
          description: 'Stream 3 storm chases this week',
          type: 'weekly',
          category: 'stream',
          difficulty: 'medium',
          rewards: {
            points: 500,
            badges: ['weekly_warrior'],
          },
          requirements: [
            {
              description: 'Complete 3 live streams',
              target: 3,
              current: 1,
              completed: false,
            },
          ],
          startDate: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000),
          endDate: new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000),
          progress: 0.33,
          completed: false,
          participants: 1247,
        },
        {
          id: 'tornado_season_2024',
          title: 'Tornado Season 2024',
          description: 'Document tornadoes during peak season',
          type: 'seasonal',
          category: 'chase',
          difficulty: 'hard',
          rewards: {
            points: 2500,
            achievements: ['tornado_season_champion'],
            exclusiveContent: ['2024_tornado_compilation'],
          },
          requirements: [
            {
              description: 'Document 5 tornadoes',
              target: 5,
              current: 2,
              completed: false,
            },
            {
              description: 'Share findings with community',
              target: 1,
              current: 1,
              completed: true,
            },
          ],
          startDate: new Date('2024-03-01'),
          endDate: new Date('2024-07-31'),
          progress: 0.5,
          completed: false,
          participants: 892,
        },
      ];
    } catch (error) {
      console.error('Error fetching challenges:', error);
      return [];
    }
  }

  async checkAchievements(userId: string, activity: string, value: number): Promise<Achievement[]> {
    try {
      const userAchievements = await this.getUserAchievements(userId);
      const newAchievements: Achievement[] = [];

      // Check for new achievements based on activity
      for (const template of this.ACHIEVEMENTS) {
        const existing = userAchievements.find(a => a.id === template.id);
        
        if (!existing?.unlocked && template.requirements.type === activity) {
          if (value >= template.requirements.target) {
            const achievement: Achievement = {
              ...template,
              unlocked: true,
              unlockedAt: new Date(),
              progress: 1,
              requirements: {
                ...template.requirements,
                current: value,
              },
            };
            newAchievements.push(achievement);
          }
        }
      }

      return newAchievements;
    } catch (error) {
      console.error('Error checking achievements:', error);
      return [];
    }
  }

  async awardPoints(userId: string, points: number, source: string): Promise<boolean> {
    try {
      // Award points and check for level ups
      console.log(`Awarding ${points} points to user ${userId} for ${source}`);
      
      // Check for achievements that might be unlocked
      const newAchievements = await this.checkAchievements(userId, source, points);
      
      if (newAchievements.length > 0) {
        console.log(`User ${userId} unlocked ${newAchievements.length} new achievements!`);
      }
      
      return true;
    } catch (error) {
      console.error('Error awarding points:', error);
      return false;
    }
  }

  private async getUserAchievements(userId: string): Promise<Achievement[]> {
    // Mock user achievements with progress
    return this.ACHIEVEMENTS.map(template => ({
      ...template,
      unlocked: Math.random() > 0.7, // 30% unlocked for demo
      unlockedAt: Math.random() > 0.7 ? new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000) : undefined,
      progress: Math.random(),
      requirements: {
        ...template.requirements,
        current: Math.floor(Math.random() * template.requirements.target * 1.2),
      },
    }));
  }

  private getUserBadges(userId: string): Badge[] {
    // Mock user badges
    return this.BADGES.filter(() => Math.random() > 0.5).map(badge => ({
      ...badge,
      earnedAt: new Date(Date.now() - Math.random() * 90 * 24 * 60 * 60 * 1000),
    }));
  }

  getRarityColor(rarity: string): string {
    switch (rarity) {
      case 'common': return '#9CA3AF';
      case 'uncommon': return '#10B981';
      case 'rare': return '#3B82F6';
      case 'epic': return '#8B5CF6';
      case 'legendary': return '#F59E0B';
      default: return '#6B7280';
    }
  }

  getRarityIcon(rarity: string): string {
    switch (rarity) {
      case 'common': return '⚪';
      case 'uncommon': return '🟢';
      case 'rare': return '🔵';
      case 'epic': return '🟣';
      case 'legendary': return '🟡';
      default: return '⚫';
    }
  }
}

export const gamificationService = new GamificationService();