import { Camera } from 'expo-camera';

export interface CameraSource {
  id: string;
  name: string;
  type: 'device' | 'external' | 'drone' | 'dashcam' | 'network';
  position: 'front' | 'back' | 'external';
  status: 'connected' | 'disconnected' | 'recording' | 'streaming';
  resolution: { width: number; height: number };
  quality: 'low' | 'medium' | 'high' | '4k';
  features: {
    zoom: boolean;
    autofocus: boolean;
    stabilization: boolean;
    nightVision: boolean;
    weatherProof: boolean;
  };
  location?: {
    mounted: string; // e.g., "dashboard", "exterior_left", "roof"
    angle: number; // degrees
    description: string;
  };
  streamUrl?: string;
  lastFrame?: string; // base64 image
}

export interface StreamLayout {
  id: string;
  name: string;
  type: 'single' | 'pip' | 'split_2' | 'split_4' | 'grid_6' | 'grid_9' | 'panoramic';
  primaryCamera: string;
  cameras: Array<{
    cameraId: string;
    position: { x: number; y: number; width: number; height: number }; // percentages
    priority: number;
    visible: boolean;
  }>;
  overlays: Array<{
    id: string;
    type: 'weather_data' | 'speed' | 'location' | 'radar' | 'time' | 'logo';
    position: { x: number; y: number };
    size: { width: number; height: number };
    visible: boolean;
    data?: any;
  }>;
}

export interface StreamingSettings {
  platform: 'youtube' | 'twitch' | 'facebook' | 'multiple';
  quality: '720p' | '1080p' | '4k';
  bitrate: number; // kbps
  framerate: 30 | 60;
  encoding: 'h264' | 'h265' | 'av1';
  lowLatency: boolean;
  backup_stream: boolean;
  recording: {
    enabled: boolean;
    quality: string;
    storage: 'local' | 'cloud';
  };
}

export interface DroneIntegration {
  id: string;
  model: string;
  connected: boolean;
  battery: number;
  gps: { latitude: number; longitude: number; altitude: number };
  homePoint: { latitude: number; longitude: number };
  flightMode: 'manual' | 'follow' | 'orbit' | 'return_home' | 'waypoint';
  maxAltitude: number;
  maxDistance: number;
  cameraControls: {
    tilt: number; // -90 to 90 degrees
    pan: number; // 0 to 360 degrees
    zoom: number; // 1x to max zoom
  };
  restrictions: string[];
}

export interface WeatherOverlay {
  temperature: number;
  windSpeed: number;
  windDirection: number;
  pressure: number;
  humidity: number;
  visibility: number;
  conditions: string;
  alerts: string[];
  radarData?: any;
  location: string;
  timestamp: Date;
}

class MultiCameraStreamingService {
  private connectedCameras: Map<string, CameraSource> = new Map();
  private currentLayout: StreamLayout | null = null;
  private streamingSettings: StreamingSettings | null = null;
  private droneConnection: DroneIntegration | null = null;

  async detectAvailableCameras(): Promise<CameraSource[]> {
    try {
      const cameras: CameraSource[] = [];

      // Device cameras
      const hasBackCamera = await Camera.isAvailableAsync();
      if (hasBackCamera) {
        cameras.push({
          id: 'device_back',
          name: 'Phone Back Camera',
          type: 'device',
          position: 'back',
          status: 'connected',
          resolution: { width: 1920, height: 1080 },
          quality: 'high',
          features: {
            zoom: true,
            autofocus: true,
            stabilization: true,
            nightVision: false,
            weatherProof: false,
          },
        });
      }

      cameras.push({
        id: 'device_front',
        name: 'Phone Front Camera',
        type: 'device',
        position: 'front',
        status: 'connected',
        resolution: { width: 1280, height: 720 },
        quality: 'medium',
        features: {
          zoom: false,
          autofocus: true,
          stabilization: false,
          nightVision: false,
          weatherProof: false,
        },
      });

      // Mock external cameras for demo
      cameras.push({
        id: 'dashcam_001',
        name: 'Dashboard Camera',
        type: 'dashcam',
        position: 'external',
        status: 'connected',
        resolution: { width: 2560, height: 1440 },
        quality: '4k',
        features: {
          zoom: false,
          autofocus: true,
          stabilization: true,
          nightVision: true,
          weatherProof: true,
        },
        location: {
          mounted: 'dashboard',
          angle: 0,
          description: 'Front-facing dashboard camera',
        },
      });

      cameras.push({
        id: 'exterior_left',
        name: 'Left Side Camera',
        type: 'external',
        position: 'external',
        status: 'connected',
        resolution: { width: 1920, height: 1080 },
        quality: 'high',
        features: {
          zoom: false,
          autofocus: true,
          stabilization: true,
          nightVision: false,
          weatherProof: true,
        },
        location: {
          mounted: 'exterior_left',
          angle: 270,
          description: 'Left side exterior camera for storm structure',
        },
      });

      return cameras;
    } catch (error) {
      console.error('Error detecting cameras:', error);
      return [];
    }
  }

  async setupMultiCameraStream(cameras: CameraSource[], layout: StreamLayout): Promise<boolean> {
    try {
      // Initialize cameras
      for (const camera of cameras) {
        await this.initializeCamera(camera);
        this.connectedCameras.set(camera.id, camera);
      }

      this.currentLayout = layout;
      
      // Setup streaming pipeline
      await this.setupStreamingPipeline();
      
      return true;
    } catch (error) {
      console.error('Error setting up multi-camera stream:', error);
      return false;
    }
  }

  async switchLayout(newLayout: StreamLayout): Promise<boolean> {
    try {
      this.currentLayout = newLayout;
      
      // Reconfigure streaming pipeline with new layout
      await this.reconfigureStreamLayout();
      
      return true;
    } catch (error) {
      console.error('Error switching layout:', error);
      return false;
    }
  }

  async addWeatherOverlay(weatherData: WeatherOverlay): Promise<boolean> {
    try {
      if (!this.currentLayout) return false;

      // Add weather overlay to current layout
      const weatherOverlayConfig = {
        id: 'weather_overlay',
        type: 'weather_data' as const,
        position: { x: 10, y: 10 }, // top-left corner
        size: { width: 300, height: 200 },
        visible: true,
        data: weatherData,
      };

      this.currentLayout.overlays.push(weatherOverlayConfig);
      await this.updateStreamOverlays();
      
      return true;
    } catch (error) {
      console.error('Error adding weather overlay:', error);
      return false;
    }
  }

  async connectDrone(droneModel: string): Promise<DroneIntegration | null> {
    try {
      // Mock drone connection
      const drone: DroneIntegration = {
        id: 'drone_001',
        model: droneModel,
        connected: true,
        battery: 85,
        gps: { latitude: 35.0, longitude: -97.0, altitude: 120 },
        homePoint: { latitude: 35.0, longitude: -97.0 },
        flightMode: 'manual',
        maxAltitude: 400, // FAA limit
        maxDistance: 1000,
        cameraControls: {
          tilt: 0,
          pan: 0,
          zoom: 1,
        },
        restrictions: ['No-fly zone nearby', 'Weather conditions marginal'],
      };

      this.droneConnection = drone;

      // Add drone camera to available cameras
      const droneCamera: CameraSource = {
        id: 'drone_camera',
        name: `${droneModel} Camera`,
        type: 'drone',
        position: 'external',
        status: 'connected',
        resolution: { width: 3840, height: 2160 },
        quality: '4k',
        features: {
          zoom: true,
          autofocus: true,
          stabilization: true,
          nightVision: false,
          weatherProof: true,
        },
        location: {
          mounted: 'aerial',
          angle: 0,
          description: 'Aerial perspective camera',
        },
      };

      this.connectedCameras.set(droneCamera.id, droneCamera);
      
      return drone;
    } catch (error) {
      console.error('Error connecting drone:', error);
      return null;
    }
  }

  async controlDroneCamera(controls: { tilt?: number; pan?: number; zoom?: number }): Promise<boolean> {
    try {
      if (!this.droneConnection) return false;

      if (controls.tilt !== undefined) {
        this.droneConnection.cameraControls.tilt = Math.max(-90, Math.min(90, controls.tilt));
      }
      if (controls.pan !== undefined) {
        this.droneConnection.cameraControls.pan = controls.pan % 360;
      }
      if (controls.zoom !== undefined) {
        this.droneConnection.cameraControls.zoom = Math.max(1, Math.min(8, controls.zoom));
      }

      return true;
    } catch (error) {
      console.error('Error controlling drone camera:', error);
      return false;
    }
  }

  async startRecording(settings: { quality: string; storage: 'local' | 'cloud' }): Promise<boolean> {
    try {
      // Start recording all active cameras
      for (const [id, camera] of this.connectedCameras) {
        if (camera.status === 'streaming') {
          camera.status = 'recording';
          console.log(`Started recording on camera ${id}`);
        }
      }
      
      return true;
    } catch (error) {
      console.error('Error starting recording:', error);
      return false;
    }
  }

  async stopRecording(): Promise<string[]> {
    try {
      const recordingFiles: string[] = [];
      
      for (const [id, camera] of this.connectedCameras) {
        if (camera.status === 'recording') {
          camera.status = 'streaming';
          // Mock recording file
          recordingFiles.push(`recording_${id}_${Date.now()}.mp4`);
        }
      }
      
      return recordingFiles;
    } catch (error) {
      console.error('Error stopping recording:', error);
      return [];
    }
  }

  getAvailableLayouts(): StreamLayout[] {
    return [
      {
        id: 'single_main',
        name: 'Single Camera',
        type: 'single',
        primaryCamera: 'device_back',
        cameras: [
          {
            cameraId: 'device_back',
            position: { x: 0, y: 0, width: 100, height: 100 },
            priority: 1,
            visible: true,
          },
        ],
        overlays: [],
      },
      {
        id: 'pip_drone',
        name: 'Picture-in-Picture',
        type: 'pip',
        primaryCamera: 'device_back',
        cameras: [
          {
            cameraId: 'device_back',
            position: { x: 0, y: 0, width: 100, height: 100 },
            priority: 1,
            visible: true,
          },
          {
            cameraId: 'drone_camera',
            position: { x: 70, y: 70, width: 25, height: 25 },
            priority: 2,
            visible: true,
          },
        ],
        overlays: [],
      },
      {
        id: 'split_screen',
        name: 'Split Screen',
        type: 'split_2',
        primaryCamera: 'device_back',
        cameras: [
          {
            cameraId: 'device_back',
            position: { x: 0, y: 0, width: 50, height: 100 },
            priority: 1,
            visible: true,
          },
          {
            cameraId: 'dashcam_001',
            position: { x: 50, y: 0, width: 50, height: 100 },
            priority: 2,
            visible: true,
          },
        ],
        overlays: [],
      },
      {
        id: 'quad_view',
        name: 'Quad View',
        type: 'split_4',
        primaryCamera: 'device_back',
        cameras: [
          {
            cameraId: 'device_back',
            position: { x: 0, y: 0, width: 50, height: 50 },
            priority: 1,
            visible: true,
          },
          {
            cameraId: 'dashcam_001',
            position: { x: 50, y: 0, width: 50, height: 50 },
            priority: 2,
            visible: true,
          },
          {
            cameraId: 'exterior_left',
            position: { x: 0, y: 50, width: 50, height: 50 },
            priority: 3,
            visible: true,
          },
          {
            cameraId: 'drone_camera',
            position: { x: 50, y: 50, width: 50, height: 50 },
            priority: 4,
            visible: true,
          },
        ],
        overlays: [],
      },
    ];
  }

  private async initializeCamera(camera: CameraSource): Promise<boolean> {
    try {
      // Camera initialization logic would go here
      console.log(`Initializing camera: ${camera.name}`);
      
      // Update camera status
      camera.status = 'connected';
      
      return true;
    } catch (error) {
      console.error(`Error initializing camera ${camera.id}:`, error);
      camera.status = 'disconnected';
      return false;
    }
  }

  private async setupStreamingPipeline(): Promise<void> {
    // Setup the streaming pipeline for multiple cameras
    console.log('Setting up multi-camera streaming pipeline');
  }

  private async reconfigureStreamLayout(): Promise<void> {
    // Reconfigure the stream layout
    console.log('Reconfiguring stream layout');
  }

  private async updateStreamOverlays(): Promise<void> {
    // Update stream overlays
    console.log('Updating stream overlays');
  }
}

export const multiCameraService = new MultiCameraStreamingService();