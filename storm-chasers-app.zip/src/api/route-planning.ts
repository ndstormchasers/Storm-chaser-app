import * as Location from 'expo-location';
import { weatherRadarService, StormCell } from './weather-radar';
import { aiStormPredictionService } from './ai-predictions';

export interface RouteWaypoint {
  id: string;
  name: string;
  coordinates: { latitude: number; longitude: number };
  type: 'start' | 'destination' | 'intercept' | 'viewing' | 'safety' | 'fuel' | 'food' | 'shelter';
  estimatedArrival: Date;
  duration: number; // minutes from previous waypoint
  distance: number; // km from previous waypoint
  notes?: string;
  weather?: {
    conditions: string;
    visibility: number;
    windSpeed: number;
    precipitation: number;
    temperature: number;
  };
  safety?: {
    riskLevel: 'low' | 'medium' | 'high' | 'extreme';
    risks: string[];
    recommendations: string[];
  };
}

export interface ChaseRoute {
  id: string;
  name: string;
  description: string;
  createdBy: string;
  createdAt: Date;
  lastUpdated: Date;
  status: 'planning' | 'active' | 'completed' | 'abandoned';
  waypoints: RouteWaypoint[];
  totalDistance: number; // km
  totalDuration: number; // minutes
  estimatedFuel: number; // liters
  estimatedCost: number; // USD
  difficulty: 'easy' | 'moderate' | 'challenging' | 'extreme';
  safetyRating: number; // 1-10
  successProbability: number; // 0-1
  alternatives: AlternativeRoute[];
  realTimeUpdates: RouteUpdate[];
  sharing: {
    public: boolean;
    collaborators: string[];
    liveTracking: boolean;
  };
  tags: string[];
}

export interface AlternativeRoute {
  id: string;
  reason: string;
  waypoints: RouteWaypoint[];
  advantages: string[];
  disadvantages: string[];
  probabilityDifference: number;
  safetyDifference: number;
  costDifference: number;
}

export interface RouteUpdate {
  id: string;
  timestamp: Date;
  type: 'weather_change' | 'traffic' | 'road_closure' | 'storm_movement' | 'safety_alert';
  severity: 'info' | 'warning' | 'critical';
  message: string;
  affectedWaypoints: string[];
  suggestedAction: 'continue' | 'reroute' | 'delay' | 'abort';
  alternativeRoute?: AlternativeRoute;
}

export interface TrafficCondition {
  roadId: string;
  roadName: string;
  coordinates: { latitude: number; longitude: number };
  condition: 'clear' | 'light' | 'moderate' | 'heavy' | 'stopped' | 'closed';
  speed: number; // km/h
  delay: number; // minutes
  reason?: string;
  alternativeAvailable: boolean;
  estimatedClearTime?: Date;
}

export interface RoadClosure {
  id: string;
  roadName: string;
  section: string;
  coordinates: { start: { latitude: number; longitude: number }; end: { latitude: number; longitude: number } };
  reason: 'construction' | 'accident' | 'weather' | 'flooding' | 'bridge_out' | 'emergency';
  severity: 'lane_closure' | 'partial_closure' | 'full_closure';
  startTime: Date;
  estimatedEndTime?: Date;
  detourAvailable: boolean;
  detourRoute?: RouteWaypoint[];
  impact: 'low' | 'medium' | 'high' | 'severe';
}

export interface FuelStop {
  id: string;
  name: string;
  brand: string;
  coordinates: { latitude: number; longitude: number };
  address: string;
  fuelTypes: string[];
  amenities: string[];
  pricePerLiter: number;
  rating: number;
  reviews: number;
  openHours: string;
  distance: number; // from route
  detourTime: number; // minutes
  weatherSafe: boolean;
}

export interface SafetyPoint {
  id: string;
  type: 'hospital' | 'police' | 'fire_station' | 'weather_office' | 'shelter' | 'safe_zone';
  name: string;
  coordinates: { latitude: number; longitude: number };
  address: string;
  contact: string;
  services: string[];
  capacity?: number;
  availability: 'available' | 'busy' | 'full' | 'closed';
  distance: number; // from current position
  estimatedTime: number; // minutes to reach
  weatherProof: boolean;
  emergency247: boolean;
}

export interface NavigationInstruction {
  id: string;
  sequence: number;
  type: 'turn' | 'merge' | 'continue' | 'exit' | 'arrive' | 'warning' | 'weather_alert';
  instruction: string;
  distance: number; // meters to instruction
  duration: number; // seconds to instruction
  coordinates: { latitude: number; longitude: number };
  roadName: string;
  direction?: 'left' | 'right' | 'straight' | 'slight_left' | 'slight_right' | 'sharp_left' | 'sharp_right';
  iconType: string;
  voiceInstruction: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  weather?: {
    visibility: number;
    conditions: string;
    risks: string[];
  };
}

export interface LiveTracking {
  userId: string;
  routeId: string;
  currentPosition: { latitude: number; longitude: number };
  heading: number; // degrees
  speed: number; // km/h
  altitude: number; // meters
  accuracy: number; // meters
  timestamp: Date;
  currentWaypoint: string;
  nextWaypoint: string;
  distanceToNext: number; // km
  estimatedArrival: Date;
  offRoute: boolean;
  emergencyMode: boolean;
  batteryLevel: number;
  signalStrength: number;
}

export interface ChaseTeam {
  id: string;
  name: string;
  leader: string;
  members: TeamMember[];
  vehicles: TeamVehicle[];
  currentRoute?: string;
  communication: {
    frequency: string; // radio frequency
    channel: string;
    backupMethods: string[];
  };
  roles: {
    [memberId: string]: 'leader' | 'navigator' | 'spotter' | 'photographer' | 'safety';
  };
  equipment: {
    shared: string[];
    individual: { [memberId: string]: string[] };
  };
}

export interface TeamMember {
  userId: string;
  username: string;
  avatar: string;
  role: string;
  experience: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  specialties: string[];
  currentPosition?: { latitude: number; longitude: number };
  status: 'online' | 'in_transit' | 'at_location' | 'offline' | 'emergency';
  lastUpdate: Date;
}

export interface TeamVehicle {
  id: string;
  driverId: string;
  make: string;
  model: string;
  year: number;
  passengers: string[];
  equipment: string[];
  fuelRange: number; // km
  currentFuel: number; // percentage
  position?: { latitude: number; longitude: number };
  status: 'ready' | 'in_transit' | 'refueling' | 'maintenance' | 'emergency';
}

class RoutePlanningService {
  private activeRoutes: Map<string, ChaseRoute> = new Map();
  private liveTracking: Map<string, LiveTracking> = new Map();
  private teams: Map<string, ChaseTeam> = new Map();

  // Route Planning
  async createOptimalRoute(
    startLocation: { latitude: number; longitude: number },
    targets: Array<{ coordinates: { latitude: number; longitude: number }; priority: number; type: string }>,
    preferences: {
      maxDistance?: number;
      maxDuration?: number;
      avoidTolls?: boolean;
      avoidHighways?: boolean;
      fuelEfficiency?: boolean;
      safetyFirst?: boolean;
    }
  ): Promise<ChaseRoute> {
    try {
      // Get storm predictions for target areas
      const stormPredictions = await Promise.all(
        targets.map(target => aiStormPredictionService.generateStormPredictions(target.coordinates))
      );

      // Calculate optimal waypoints considering weather, traffic, and safety
      const waypoints = await this.calculateOptimalWaypoints(
        startLocation,
        targets,
        stormPredictions.flat(),
        preferences
      );

      // Create route
      const route: ChaseRoute = {
        id: `route_${Date.now()}`,
        name: `Storm Chase ${new Date().toLocaleDateString()}`,
        description: 'Automatically optimized storm chase route',
        createdBy: 'system',
        createdAt: new Date(),
        lastUpdated: new Date(),
        status: 'planning',
        waypoints,
        totalDistance: this.calculateTotalDistance(waypoints),
        totalDuration: this.calculateTotalDuration(waypoints),
        estimatedFuel: this.calculateFuelConsumption(waypoints),
        estimatedCost: this.calculateTotalCost(waypoints),
        difficulty: this.assessRouteDifficulty(waypoints),
        safetyRating: this.calculateSafetyRating(waypoints),
        successProbability: this.calculateSuccessProbability(waypoints, stormPredictions.flat()),
        alternatives: await this.generateAlternativeRoutes(waypoints, targets, preferences),
        realTimeUpdates: [],
        sharing: {
          public: false,
          collaborators: [],
          liveTracking: false,
        },
        tags: ['auto-generated', 'optimized'],
      };

      this.activeRoutes.set(route.id, route);
      return route;
    } catch (error) {
      console.error('Error creating optimal route:', error);
      throw error;
    }
  }

  async updateRouteForConditions(routeId: string): Promise<RouteUpdate[]> {
    try {
      const route = this.activeRoutes.get(routeId);
      if (!route) throw new Error('Route not found');

      const updates: RouteUpdate[] = [];

      // Check weather changes
      for (const waypoint of route.waypoints) {
        const weatherUpdate = await this.checkWeatherChanges(waypoint);
        if (weatherUpdate) {
          updates.push(weatherUpdate);
        }
      }

      // Check traffic conditions
      const trafficUpdates = await this.checkTrafficConditions(route);
      updates.push(...trafficUpdates);

      // Check road closures
      const closureUpdates = await this.checkRoadClosures(route);
      updates.push(...closureUpdates);

      // Update route with new information
      route.realTimeUpdates.push(...updates);
      route.lastUpdated = new Date();

      return updates;
    } catch (error) {
      console.error('Error updating route conditions:', error);
      return [];
    }
  }

  // Navigation
  async startNavigation(routeId: string, userId: string): Promise<NavigationInstruction[]> {
    try {
      const route = this.activeRoutes.get(routeId);
      if (!route) throw new Error('Route not found');

      // Start live tracking
      const currentPosition = await Location.getCurrentPositionAsync();
      const tracking: LiveTracking = {
        userId,
        routeId,
        currentPosition: {
          latitude: currentPosition.coords.latitude,
          longitude: currentPosition.coords.longitude,
        },
        heading: currentPosition.coords.heading || 0,
        speed: currentPosition.coords.speed || 0,
        altitude: currentPosition.coords.altitude || 0,
        accuracy: currentPosition.coords.accuracy || 0,
        timestamp: new Date(),
        currentWaypoint: route.waypoints[0].id,
        nextWaypoint: route.waypoints[1]?.id || route.waypoints[0].id,
        distanceToNext: this.calculateDistance(
          { latitude: currentPosition.coords.latitude, longitude: currentPosition.coords.longitude },
          route.waypoints[1]?.coordinates || route.waypoints[0].coordinates
        ),
        estimatedArrival: route.waypoints[1]?.estimatedArrival || new Date(),
        offRoute: false,
        emergencyMode: false,
        batteryLevel: 100, // Would get from device
        signalStrength: 100, // Would get from device
      };

      this.liveTracking.set(userId, tracking);

      // Generate initial navigation instructions
      return this.generateNavigationInstructions(route, tracking);
    } catch (error) {
      console.error('Error starting navigation:', error);
      throw error;
    }
  }

  async updateNavigation(userId: string): Promise<{ instructions: NavigationInstruction[]; alerts: RouteUpdate[] }> {
    try {
      const tracking = this.liveTracking.get(userId);
      if (!tracking) throw new Error('Navigation not active');

      const route = this.activeRoutes.get(tracking.routeId);
      if (!route) throw new Error('Route not found');

      // Update current position
      const currentPosition = await Location.getCurrentPositionAsync();
      tracking.currentPosition = {
        latitude: currentPosition.coords.latitude,
        longitude: currentPosition.coords.longitude,
      };
      tracking.speed = currentPosition.coords.speed || 0;
      tracking.heading = currentPosition.coords.heading || 0;
      tracking.timestamp = new Date();

      // Check if off route
      tracking.offRoute = this.isOffRoute(tracking, route);

      // Generate updated instructions
      const instructions = this.generateNavigationInstructions(route, tracking);

      // Check for real-time alerts
      const alerts = await this.updateRouteForConditions(tracking.routeId);

      return { instructions, alerts };
    } catch (error) {
      console.error('Error updating navigation:', error);
      return { instructions: [], alerts: [] };
    }
  }

  // Team Coordination
  async createChaseTeam(teamData: Omit<ChaseTeam, 'id'>): Promise<string> {
    try {
      const team: ChaseTeam = {
        ...teamData,
        id: `team_${Date.now()}`,
      };

      this.teams.set(team.id, team);
      console.log(`Created chase team: ${team.name}`);
      return team.id;
    } catch (error) {
      console.error('Error creating chase team:', error);
      throw error;
    }
  }

  async shareRouteWithTeam(routeId: string, teamId: string): Promise<boolean> {
    try {
      const route = this.activeRoutes.get(routeId);
      const team = this.teams.get(teamId);
      
      if (!route || !team) return false;

      team.currentRoute = routeId;
      route.sharing.collaborators = team.members.map(m => m.userId);
      route.sharing.liveTracking = true;

      console.log(`Shared route ${routeId} with team ${teamId}`);
      return true;
    } catch (error) {
      console.error('Error sharing route with team:', error);
      return false;
    }
  }

  async getTeamPositions(teamId: string): Promise<{ [memberId: string]: { latitude: number; longitude: number; timestamp: Date } }> {
    try {
      const team = this.teams.get(teamId);
      if (!team) return {};

      const positions: { [memberId: string]: { latitude: number; longitude: number; timestamp: Date } } = {};

      for (const member of team.members) {
        const tracking = this.liveTracking.get(member.userId);
        if (tracking) {
          positions[member.userId] = {
            latitude: tracking.currentPosition.latitude,
            longitude: tracking.currentPosition.longitude,
            timestamp: tracking.timestamp,
          };
        }
      }

      return positions;
    } catch (error) {
      console.error('Error getting team positions:', error);
      return {};
    }
  }

  // Utility Methods
  private async calculateOptimalWaypoints(
    start: { latitude: number; longitude: number },
    targets: Array<{ coordinates: { latitude: number; longitude: number }; priority: number; type: string }>,
    predictions: any[],
    preferences: any
  ): Promise<RouteWaypoint[]> {
    const waypoints: RouteWaypoint[] = [];

    // Add start point
    waypoints.push({
      id: 'start',
      name: 'Starting Location',
      coordinates: start,
      type: 'start',
      estimatedArrival: new Date(),
      duration: 0,
      distance: 0,
    });

    // Sort targets by priority and optimize order
    const sortedTargets = targets.sort((a, b) => b.priority - a.priority);

    let currentTime = new Date();
    let currentLocation = start;

    for (let i = 0; i < sortedTargets.length; i++) {
      const target = sortedTargets[i];
      const distance = this.calculateDistance(currentLocation, target.coordinates);
      const duration = this.calculateTravelTime(distance, 'highway');

      currentTime = new Date(currentTime.getTime() + duration * 60000);

      waypoints.push({
        id: `target_${i}`,
        name: `Target ${i + 1}`,
        coordinates: target.coordinates,
        type: 'intercept',
        estimatedArrival: currentTime,
        duration,
        distance,
        notes: `Priority ${target.priority} ${target.type}`,
      });

      currentLocation = target.coordinates;
    }

    // Add safety stops and fuel stops as needed
    await this.addSafetyWaypoints(waypoints, preferences);

    return waypoints;
  }

  private async addSafetyWaypoints(waypoints: RouteWaypoint[], preferences: any): Promise<void> {
    // Add fuel stops every 400km or when needed
    let totalDistance = 0;
    for (let i = 1; i < waypoints.length; i++) {
      totalDistance += waypoints[i].distance;
      
      if (totalDistance > 400) {
        const fuelStop = await this.findNearestFuelStop(waypoints[i].coordinates);
        if (fuelStop) {
          waypoints.splice(i, 0, {
            id: `fuel_${i}`,
            name: fuelStop.name,
            coordinates: fuelStop.coordinates,
            type: 'fuel',
            estimatedArrival: new Date(waypoints[i].estimatedArrival.getTime() - 15 * 60000),
            duration: 15,
            distance: fuelStop.distance,
            notes: `Fuel stop - $${fuelStop.pricePerLiter}/L`,
          });
          totalDistance = 0;
        }
      }
    }
  }

  private calculateDistance(point1: { latitude: number; longitude: number }, point2: { latitude: number; longitude: number }): number {
    const R = 6371; // Earth's radius in km
    const dLat = (point2.latitude - point1.latitude) * Math.PI / 180;
    const dLon = (point2.longitude - point1.longitude) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(point1.latitude * Math.PI / 180) * Math.cos(point2.latitude * Math.PI / 180) * 
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }

  private calculateTravelTime(distance: number, roadType: 'city' | 'highway' | 'rural'): number {
    const speeds = { city: 50, highway: 100, rural: 80 }; // km/h
    return (distance / speeds[roadType]) * 60; // minutes
  }

  private calculateTotalDistance(waypoints: RouteWaypoint[]): number {
    return waypoints.reduce((total, waypoint) => total + waypoint.distance, 0);
  }

  private calculateTotalDuration(waypoints: RouteWaypoint[]): number {
    return waypoints.reduce((total, waypoint) => total + waypoint.duration, 0);
  }

  private calculateFuelConsumption(waypoints: RouteWaypoint[]): number {
    const totalDistance = this.calculateTotalDistance(waypoints);
    const fuelEfficiency = 10; // L/100km average
    return (totalDistance / 100) * fuelEfficiency;
  }

  private calculateTotalCost(waypoints: RouteWaypoint[]): number {
    const fuel = this.calculateFuelConsumption(waypoints);
    const fuelCost = fuel * 1.50; // $1.50/L average
    const accommodation = waypoints.length > 5 ? 150 : 0; // Hotel if long trip
    const food = waypoints.length * 25; // $25 per stop
    return fuelCost + accommodation + food;
  }

  private assessRouteDifficulty(waypoints: RouteWaypoint[]): 'easy' | 'moderate' | 'challenging' | 'extreme' {
    const totalDistance = this.calculateTotalDistance(waypoints);
    const totalDuration = this.calculateTotalDuration(waypoints);
    
    if (totalDistance > 1000 || totalDuration > 12 * 60) return 'extreme';
    if (totalDistance > 600 || totalDuration > 8 * 60) return 'challenging';
    if (totalDistance > 300 || totalDuration > 4 * 60) return 'moderate';
    return 'easy';
  }

  private calculateSafetyRating(waypoints: RouteWaypoint[]): number {
    // Mock safety calculation based on route characteristics
    let score = 10;
    
    const totalDistance = this.calculateTotalDistance(waypoints);
    if (totalDistance > 800) score -= 2;
    if (totalDistance > 1200) score -= 2;
    
    // Check for high-risk areas
    const riskWaypoints = waypoints.filter(w => w.safety?.riskLevel === 'high' || w.safety?.riskLevel === 'extreme');
    score -= riskWaypoints.length;
    
    return Math.max(1, Math.min(10, score));
  }

  private calculateSuccessProbability(waypoints: RouteWaypoint[], predictions: any[]): number {
    // Mock success probability based on weather predictions and route quality
    let probability = 0.8; // Base 80%
    
    // Adjust based on weather confidence
    const avgConfidence = predictions.reduce((sum, p) => sum + (p.confidence || 0.5), 0) / predictions.length;
    probability *= avgConfidence;
    
    // Adjust based on route complexity
    const complexity = waypoints.length / 10; // More waypoints = more complex
    probability *= Math.max(0.5, 1 - complexity * 0.1);
    
    return Math.max(0.1, Math.min(1, probability));
  }

  private async generateAlternativeRoutes(waypoints: RouteWaypoint[], targets: any[], preferences: any): Promise<AlternativeRoute[]> {
    // Generate 1-2 alternative routes with different priorities
    return [
      {
        id: 'alt_safety',
        reason: 'Safety-optimized route',
        waypoints: waypoints, // Would be different in real implementation
        advantages: ['Lower risk areas', 'More safety stops'],
        disadvantages: ['Longer travel time', 'Higher fuel cost'],
        probabilityDifference: -0.05,
        safetyDifference: 2,
        costDifference: 50,
      },
    ];
  }

  private async checkWeatherChanges(waypoint: RouteWaypoint): Promise<RouteUpdate | null> {
    // Mock weather change detection
    if (Math.random() < 0.1) { // 10% chance of weather change
      return {
        id: `weather_${Date.now()}`,
        timestamp: new Date(),
        type: 'weather_change',
        severity: 'warning',
        message: 'Storm intensity increasing at target location',
        affectedWaypoints: [waypoint.id],
        suggestedAction: 'continue',
      };
    }
    return null;
  }

  private async checkTrafficConditions(route: ChaseRoute): Promise<RouteUpdate[]> {
    // Mock traffic condition checking
    return [];
  }

  private async checkRoadClosures(route: ChaseRoute): Promise<RouteUpdate[]> {
    // Mock road closure checking
    return [];
  }

  private generateNavigationInstructions(route: ChaseRoute, tracking: LiveTracking): NavigationInstruction[] {
    // Mock navigation instruction generation
    return [
      {
        id: 'nav_1',
        sequence: 1,
        type: 'continue',
        instruction: 'Continue straight on Highway 35 North',
        distance: 5000,
        duration: 180,
        coordinates: tracking.currentPosition,
        roadName: 'Highway 35 North',
        direction: 'straight',
        iconType: 'straight',
        voiceInstruction: 'Continue straight for 5 kilometers',
        priority: 'medium',
      },
    ];
  }

  private isOffRoute(tracking: LiveTracking, route: ChaseRoute): boolean {
    // Check if current position is significantly off the planned route
    const currentWaypoint = route.waypoints.find(w => w.id === tracking.currentWaypoint);
    if (!currentWaypoint) return false;
    
    const distance = this.calculateDistance(tracking.currentPosition, currentWaypoint.coordinates);
    return distance > 5; // More than 5km off route
  }

  private async findNearestFuelStop(coordinates: { latitude: number; longitude: number }): Promise<FuelStop | null> {
    // Mock fuel stop finder
    return {
      id: 'fuel_1',
      name: 'Travel Center',
      brand: 'Shell',
      coordinates,
      address: '123 Highway Rd',
      fuelTypes: ['Regular', 'Premium', 'Diesel'],
      amenities: ['Restrooms', 'Food', 'Wi-Fi'],
      pricePerLiter: 1.45,
      rating: 4.2,
      reviews: 245,
      openHours: '24/7',
      distance: 2.5,
      detourTime: 8,
      weatherSafe: true,
    };
  }
}

export const routePlanningService = new RoutePlanningService();