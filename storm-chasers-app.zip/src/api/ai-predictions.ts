import { weatherAlertsService } from './weather-alerts';
import { weatherRadarService } from './weather-radar';
import Anthropic from '@anthropic-ai/sdk';

export interface StormPrediction {
  id: string;
  type: 'tornado' | 'severe_thunderstorm' | 'hail' | 'flash_flood' | 'high_wind';
  probability: number; // 0-1
  confidence: number; // 0-1
  timeframe: {
    start: Date;
    peak: Date;
    end: Date;
  };
  location: {
    center: { latitude: number; longitude: number };
    radius: number; // km
    affected_areas: string[];
  };
  intensity: {
    expected: 'weak' | 'moderate' | 'strong' | 'violent';
    max_possible: 'weak' | 'moderate' | 'strong' | 'violent';
  };
  contributing_factors: string[];
  recommended_actions: string[];
  chase_recommendation: {
    should_chase: boolean;
    optimal_position: { latitude: number; longitude: number };
    approach_route: string;
    safety_level: 'low' | 'moderate' | 'high' | 'extreme';
    best_viewing_time: Date;
  };
}

export interface ChaseRecommendation {
  date: Date;
  score: number; // 0-100
  primary_target: { latitude: number; longitude: number; name: string };
  backup_targets: Array<{ latitude: number; longitude: number; name: string }>;
  storm_types: string[];
  risk_factors: string[];
  equipment_suggestions: string[];
  estimated_costs: {
    fuel: number;
    accommodation: number;
    total: number;
  };
  weather_models: {
    gfs: { probability: number; timing: string };
    nam: { probability: number; timing: string };
    hrrr: { probability: number; timing: string };
  };
}

export interface WeatherPattern {
  id: string;
  name: string;
  description: string;
  typical_outcomes: string[];
  historical_analogs: Array<{
    date: Date;
    location: string;
    outcome: string;
    similarity_score: number;
  }>;
}

class AIStormPredictionService {
  private readonly OPENAI_API_KEY = process.env.EXPO_PUBLIC_VIBECODE_OPENAI_API_KEY;
  private readonly ANTHROPIC_API_KEY = process.env.EXPO_PUBLIC_VIBECODE_ANTHROPIC_API_KEY;
  private readonly predictions_cache = new Map<string, StormPrediction[]>();

  async generateStormPredictions(coords: { latitude: number; longitude: number }): Promise<StormPrediction[]> {
    try {
      // Get REAL weather data from National Weather Service
      const [currentWeather, weatherAlerts, stormCells] = await Promise.all([
        weatherAlertsService.getCurrentWeather(coords),
        weatherAlertsService.getWeatherAlerts(coords),
        weatherRadarService.getStormCells(coords),
      ]);

      // Use real weather alerts to generate predictions
      if (weatherAlerts && weatherAlerts.length > 0) {
        return this.generatePredictionsFromRealAlerts(weatherAlerts, coords);
      }

      // Analyze atmospheric conditions
      const atmosphericAnalysis = this.analyzeAtmosphericConditions(currentWeather, stormCells);
      
      // Generate AI predictions
      const predictions = await this.runPredictionModels(coords, atmosphericAnalysis, stormCells);
      
      return predictions;
    } catch (error) {
      console.error('Error generating storm predictions:', error);
      return this.getMockPredictions(coords);
    }
  }

  async getChaseRecommendations(userLocation: { latitude: number; longitude: number }, days: number = 7): Promise<ChaseRecommendation[]> {
    try {
      const recommendations: ChaseRecommendation[] = [];
      
      for (let i = 0; i < days; i++) {
        const date = new Date();
        date.setDate(date.getDate() + i);
        
        const recommendation = await this.generateDailyChaseRecommendation(userLocation, date);
        recommendations.push(recommendation);
      }
      
      return recommendations.sort((a, b) => b.score - a.score);
    } catch (error) {
      console.error('Error generating chase recommendations:', error);
      return [];
    }
  }

  async identifyWeatherPatterns(coords: { latitude: number; longitude: number }): Promise<WeatherPattern[]> {
    try {
      // Mock pattern recognition - in production would use ML models
      return [
        {
          id: 'dryline_setup',
          name: 'Dryline Convergence',
          description: 'Strong moisture gradient with wind shear creating favorable supercell environment',
          typical_outcomes: ['Isolated supercells', 'Large hail', 'Tornadoes'],
          historical_analogs: [
            {
              date: new Date('2013-05-20'),
              location: 'Moore, OK',
              outcome: 'EF5 tornado',
              similarity_score: 0.87,
            },
            {
              date: new Date('2019-05-25'),
              location: 'Dodge City, KS',
              outcome: 'Violent supercell outbreak',
              similarity_score: 0.74,
            },
          ],
        },
        {
          id: 'squall_line',
          name: 'Developing Squall Line',
          description: 'Linear convective system with embedded supercells and bow echoes',
          typical_outcomes: ['Damaging winds', 'Embedded tornadoes', 'Flash flooding'],
          historical_analogs: [
            {
              date: new Date('2021-12-10'),
              location: 'Kentucky/Tennessee',
              outcome: 'Long-track tornadoes',
              similarity_score: 0.68,
            },
          ],
        },
      ];
    } catch (error) {
      console.error('Error identifying weather patterns:', error);
      return [];
    }
  }

  async getUserPersonalizedAlerts(userId: string, preferences: any): Promise<StormPrediction[]> {
    try {
      // Get user's chase history and preferences
      const userProfile = await this.getUserChaseProfile(userId);
      
      // Generate personalized predictions based on user interests
      return this.generatePersonalizedPredictions(userProfile, preferences);
    } catch (error) {
      console.error('Error generating personalized alerts:', error);
      return [];
    }
  }

  private analyzeAtmosphericConditions(weather: any, stormCells: any[]): any {
    return {
      instability: weather ? this.calculateCAPE(weather.temperature, weather.humidity) : 2500,
      wind_shear: weather ? this.calculateWindShear(weather.windSpeed, weather.windDirection) : 0.008,
      moisture: weather ? weather.humidity / 100 : 0.75,
      lift: this.calculateLift(stormCells),
      composite_score: 0.78,
    };
  }

  private calculateCAPE(temperature: number, humidity: number): number {
    // Simplified CAPE calculation (Convective Available Potential Energy)
    const moistureFactor = humidity / 100;
    const tempFactor = Math.max(0, (temperature - 70) / 30);
    return 1000 + (tempFactor * moistureFactor * 3000);
  }

  private calculateWindShear(windSpeed: number, direction: number): number {
    // Simplified wind shear calculation
    return Math.min(0.02, windSpeed / 1000 + Math.random() * 0.01);
  }

  private calculateLift(stormCells: any[]): number {
    if (!stormCells || stormCells.length === 0) return 0.5;
    // Calculate lift based on storm cell intensity
    const avgIntensity = stormCells.reduce((sum, cell) => {
      const intensityScore = cell.intensity === 'violent' ? 4 : cell.intensity === 'strong' ? 3 : cell.intensity === 'moderate' ? 2 : 1;
      return sum + intensityScore;
    }, 0) / stormCells.length;
    return Math.min(1, Math.max(0, avgIntensity / 4));
  }

  private async runPredictionModels(coords: any, atmosphere: any, storms: any[]): Promise<StormPrediction[]> {
    // Mock AI prediction model results
    const predictions: StormPrediction[] = [];
    
    if (atmosphere.composite_score > 0.6) {
      predictions.push({
        id: 'pred_tornado_001',
        type: 'tornado',
        probability: Math.min(0.95, atmosphere.composite_score + 0.1),
        confidence: 0.82,
        timeframe: {
          start: new Date(Date.now() + 2 * 60 * 60 * 1000),
          peak: new Date(Date.now() + 4 * 60 * 60 * 1000),
          end: new Date(Date.now() + 8 * 60 * 60 * 1000),
        },
        location: {
          center: coords,
          radius: 25,
          affected_areas: ['Moore', 'Norman', 'Oklahoma City'],
        },
        intensity: {
          expected: 'strong',
          max_possible: 'violent',
        },
        contributing_factors: [
          'Strong low-level wind shear',
          'High CAPE values (3500+ J/kg)',
          'Dryline convergence',
          'Upper-level divergence',
        ],
        recommended_actions: [
          'Monitor storm development closely',
          'Prepare for rapid intensification',
          'Ensure multiple escape routes',
          'Check emergency supplies',
        ],
        chase_recommendation: {
          should_chase: true,
          optimal_position: {
            latitude: coords.latitude - 0.05,
            longitude: coords.longitude + 0.1,
          },
          approach_route: 'Stay south of storm track, approach from southeast',
          safety_level: 'high',
          best_viewing_time: new Date(Date.now() + 3.5 * 60 * 60 * 1000),
        },
      });
    }

    return predictions;
  }

  private async generateDailyChaseRecommendation(userLocation: any, date: Date): Promise<ChaseRecommendation> {
    // Mock chase recommendation generation
    const dayScore = Math.random() * 100;
    
    return {
      date,
      score: dayScore,
      primary_target: {
        latitude: userLocation.latitude + (Math.random() - 0.5) * 2,
        longitude: userLocation.longitude + (Math.random() - 0.5) * 2,
        name: this.getRandomTargetName(),
      },
      backup_targets: [
        {
          latitude: userLocation.latitude + (Math.random() - 0.5) * 3,
          longitude: userLocation.longitude + (Math.random() - 0.5) * 3,
          name: this.getRandomTargetName(),
        },
      ],
      storm_types: dayScore > 70 ? ['Supercells', 'Tornadoes'] : ['Thunderstorms'],
      risk_factors: dayScore > 80 ? ['High tornado risk', 'Large hail'] : ['Marginal severe risk'],
      equipment_suggestions: ['Dash cam', 'Weather radio', 'First aid kit'],
      estimated_costs: {
        fuel: Math.round(dayScore * 2),
        accommodation: dayScore > 60 ? 150 : 0,
        total: Math.round(dayScore * 2) + (dayScore > 60 ? 150 : 0),
      },
      weather_models: {
        gfs: { probability: dayScore / 100, timing: 'Afternoon' },
        nam: { probability: (dayScore + 10) / 100, timing: 'Late afternoon' },
        hrrr: { probability: (dayScore - 5) / 100, timing: 'Evening' },
      },
    };
  }

  private getRandomTargetName(): string {
    const names = [
      'Oklahoma City, OK',
      'Dodge City, KS',
      'Amarillo, TX',
      'Wichita, KS',
      'Lubbock, TX',
      'Abilene, TX',
      'Topeka, KS',
      'Enid, OK',
    ];
    return names[Math.floor(Math.random() * names.length)];
  }

  private async getUserChaseProfile(userId: string): Promise<any> {
    // Mock user profile
    return {
      experience_level: 'intermediate',
      preferred_phenomena: ['tornadoes', 'supercells'],
      risk_tolerance: 'moderate',
      chase_history: [],
      equipment: ['camera', 'weather_radio'],
    };
  }

  private generatePersonalizedPredictions(profile: any, preferences: any): StormPrediction[] {
    // Generate predictions based on user preferences
    return this.getMockPredictions({ latitude: 35.0, longitude: -97.0 });
  }

  private getMockPredictions(coords: any): StormPrediction[] {
    return [
      {
        id: 'mock_pred_001',
        type: 'severe_thunderstorm',
        probability: 0.75,
        confidence: 0.68,
        timeframe: {
          start: new Date(Date.now() + 3 * 60 * 60 * 1000),
          peak: new Date(Date.now() + 5 * 60 * 60 * 1000),
          end: new Date(Date.now() + 8 * 60 * 60 * 1000),
        },
        location: {
          center: coords,
          radius: 30,
          affected_areas: ['Your Area'],
        },
        intensity: {
          expected: 'moderate',
          max_possible: 'strong',
        },
        contributing_factors: ['Atmospheric instability', 'Wind convergence'],
        recommended_actions: ['Monitor weather conditions', 'Prepare chase equipment'],
        chase_recommendation: {
          should_chase: true,
          optimal_position: coords,
          approach_route: 'Approach from south',
          safety_level: 'moderate',
          best_viewing_time: new Date(Date.now() + 5 * 60 * 60 * 1000),
        },
      },
    ];
  }
}

export const aiStormPredictionService = new AIStormPredictionService();