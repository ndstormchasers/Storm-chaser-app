export interface CreatorProfile {
  userId: string;
  username: string;
  displayName: string;
  avatar: string;
  verified: boolean;
  tier: 'hobbyist' | 'enthusiast' | 'professional' | 'expert';
  specialties: string[];
  bio: string;
  metrics: {
    totalFollowers: number;
    totalViews: number;
    totalStreams: number;
    averageViewers: number;
    totalRevenue: number;
    monthlyRevenue: number;
    growthRate: number;
  };
  monetization: {
    enabled: boolean;
    methods: MonetizationMethod[];
    payoutMethod: 'paypal' | 'bank' | 'crypto';
    taxInfo: boolean;
  };
  equipment: EquipmentListing[];
  partnerships: Partnership[];
}

export interface MonetizationMethod {
  type: 'subscriptions' | 'donations' | 'merchandise' | 'courses' | 'consultation' | 'sponsorship' | 'affiliate';
  enabled: boolean;
  settings: any;
  revenue: {
    monthly: number;
    total: number;
    growth: number;
  };
}

export interface Subscription {
  id: string;
  creatorId: string;
  subscriberId: string;
  tier: SubscriptionTier;
  startDate: Date;
  endDate?: Date;
  status: 'active' | 'cancelled' | 'expired' | 'paused';
  autoRenew: boolean;
  totalPaid: number;
}

export interface SubscriptionTier {
  id: string;
  name: string;
  description: string;
  price: number; // monthly
  benefits: string[];
  perks: {
    exclusiveContent: boolean;
    earlyAccess: boolean;
    privateCommunity: boolean;
    directMessaging: boolean;
    customEmotes: boolean;
    prioritySupport: boolean;
    merchandise: boolean;
    meetAndGreet: boolean;
  };
  subscriberCount: number;
  color: string;
  icon: string;
}

export interface Donation {
  id: string;
  fromUserId: string;
  toUserId: string;
  amount: number;
  currency: 'USD' | 'EUR' | 'GBP';
  message?: string;
  anonymous: boolean;
  timestamp: Date;
  streamId?: string;
  recurring: boolean;
  recurringPeriod?: 'weekly' | 'monthly';
  status: 'pending' | 'completed' | 'failed';
}

export interface Merchandise {
  id: string;
  creatorId: string;
  name: string;
  description: string;
  category: 'clothing' | 'accessories' | 'equipment' | 'prints' | 'digital';
  price: number;
  images: string[];
  variants: ProductVariant[];
  inventory: number;
  sales: number;
  rating: number;
  featured: boolean;
  tags: string[];
}

export interface ProductVariant {
  id: string;
  name: string;
  type: 'size' | 'color' | 'style';
  options: string[];
  priceModifier: number;
  inventory: { [option: string]: number };
}

export interface EquipmentListing {
  id: string;
  name: string;
  category: 'camera' | 'weather_instrument' | 'vehicle' | 'communication' | 'safety' | 'other';
  brand: string;
  model: string;
  description: string;
  images: string[];
  purchaseDate: Date;
  purchasePrice: number;
  currentValue: number;
  affiliateLink?: string;
  commission?: number;
  rating: number;
  review: string;
  pros: string[];
  cons: string[];
  wouldRecommend: boolean;
}

export interface Partnership {
  id: string;
  partnerId: string;
  partnerName: string;
  partnerType: 'brand' | 'sponsor' | 'affiliate' | 'media' | 'research';
  type: 'sponsored_content' | 'affiliate_marketing' | 'brand_ambassador' | 'research_collaboration';
  status: 'active' | 'pending' | 'completed' | 'cancelled';
  startDate: Date;
  endDate?: Date;
  terms: {
    payment: number;
    deliverables: string[];
    exclusivity: boolean;
    duration: number; // months
    content_requirements: string[];
  };
  performance: {
    views: number;
    clicks: number;
    conversions: number;
    revenue: number;
  };
}

export interface ConsultationService {
  id: string;
  creatorId: string;
  title: string;
  description: string;
  category: 'storm_planning' | 'equipment_advice' | 'safety_training' | 'photography_tips' | 'streaming_setup';
  duration: number; // minutes
  price: number;
  availability: {
    days: string[];
    times: string[];
    timezone: string;
  };
  bookings: ConsultationBooking[];
  rating: number;
  reviews: ConsultationReview[];
}

export interface ConsultationBooking {
  id: string;
  serviceId: string;
  clientId: string;
  scheduledDate: Date;
  duration: number;
  status: 'scheduled' | 'completed' | 'cancelled' | 'no_show';
  meetingLink?: string;
  notes?: string;
  payment: {
    amount: number;
    status: 'pending' | 'paid' | 'refunded';
    transactionId: string;
  };
}

export interface ConsultationReview {
  id: string;
  bookingId: string;
  rating: number;
  comment: string;
  createdAt: Date;
  helpful: number;
}

export interface ContentMarketplace {
  id: string;
  type: 'photo' | 'video' | 'time_lapse' | 'data' | 'forecast' | 'tutorial';
  title: string;
  description: string;
  creatorId: string;
  price: number;
  licenseType: 'personal' | 'commercial' | 'editorial' | 'exclusive';
  tags: string[];
  metadata: {
    location: string;
    date: Date;
    weather_conditions: string;
    equipment_used: string[];
    technical_details: any;
  };
  sales: number;
  rating: number;
  featured: boolean;
  exclusive: boolean;
  downloadUrl?: string;
  previewUrl: string;
}

export interface Revenue {
  userId: string;
  period: 'daily' | 'weekly' | 'monthly' | 'yearly';
  date: Date;
  breakdown: {
    subscriptions: number;
    donations: number;
    merchandise: number;
    consultations: number;
    content_sales: number;
    sponsorships: number;
    affiliates: number;
    total: number;
  };
  fees: {
    platform: number;
    payment_processing: number;
    taxes: number;
    total: number;
  };
  net: number;
}

export interface CreatorAnalytics {
  userId: string;
  period: { start: Date; end: Date };
  metrics: {
    followers: { current: number; change: number; growth_rate: number };
    views: { total: number; unique: number; average_duration: number };
    engagement: { likes: number; comments: number; shares: number; rate: number };
    revenue: { total: number; change: number; per_follower: number };
    content: { uploads: number; streams: number; total_hours: number };
  };
  topContent: Array<{
    id: string;
    title: string;
    type: string;
    views: number;
    revenue: number;
    engagement: number;
  }>;
  audienceInsights: {
    demographics: { age_groups: any; locations: any; devices: any };
    behavior: { peak_hours: any; engagement_patterns: any };
    interests: string[];
  };
}

class CreatorEconomyService {
  private readonly PLATFORM_FEE_RATE = 0.05; // 5%
  private readonly PAYMENT_PROCESSING_FEE = 0.029; // 2.9%

  // Creator Profile Management
  async getCreatorProfile(userId: string): Promise<CreatorProfile | null> {
    try {
      // Mock creator profile
      return {
        userId,
        username: 'ndstormchasers2025',
        displayName: 'ND Storm Chasers',
        avatar: '⛈️',
        verified: true,
        tier: 'professional',
        specialties: ['Tornado Documentation', 'Storm Photography', 'Live Streaming'],
        bio: 'Professional storm chaser documenting severe weather across the Great Plains',
        metrics: {
          totalFollowers: 25420,
          totalViews: 1250000,
          totalStreams: 156,
          averageViewers: 847,
          totalRevenue: 15750,
          monthlyRevenue: 2340,
          growthRate: 0.15,
        },
        monetization: {
          enabled: true,
          methods: [
            {
              type: 'subscriptions',
              enabled: true,
              settings: { tiers: 3 },
              revenue: { monthly: 1240, total: 8900, growth: 0.12 },
            },
            {
              type: 'donations',
              enabled: true,
              settings: { min_amount: 5 },
              revenue: { monthly: 680, total: 4200, growth: 0.08 },
            },
            {
              type: 'merchandise',
              enabled: true,
              settings: { categories: ['clothing', 'prints'] },
              revenue: { monthly: 420, total: 2650, growth: 0.05 },
            },
          ],
          payoutMethod: 'paypal',
          taxInfo: true,
        },
        equipment: [],
        partnerships: [],
      };
    } catch (error) {
      console.error('Error getting creator profile:', error);
      return null;
    }
  }

  async setupMonetization(userId: string, methods: string[]): Promise<boolean> {
    try {
      console.log(`Setting up monetization for user ${userId}:`, methods);
      return true;
    } catch (error) {
      console.error('Error setting up monetization:', error);
      return false;
    }
  }

  // Subscription Management
  async createSubscriptionTier(creatorId: string, tier: Omit<SubscriptionTier, 'id' | 'subscriberCount'>): Promise<boolean> {
    try {
      const newTier: SubscriptionTier = {
        ...tier,
        id: `tier_${Date.now()}`,
        subscriberCount: 0,
      };
      
      console.log(`Created subscription tier for creator ${creatorId}:`, newTier);
      return true;
    } catch (error) {
      console.error('Error creating subscription tier:', error);
      return false;
    }
  }

  async subscribe(subscriberId: string, creatorId: string, tierId: string): Promise<boolean> {
    try {
      const subscription: Subscription = {
        id: `sub_${Date.now()}`,
        creatorId,
        subscriberId,
        tier: await this.getSubscriptionTier(tierId) as SubscriptionTier,
        startDate: new Date(),
        status: 'active',
        autoRenew: true,
        totalPaid: 0,
      };

      console.log(`User ${subscriberId} subscribed to ${creatorId}`);
      return true;
    } catch (error) {
      console.error('Error creating subscription:', error);
      return false;
    }
  }

  // Donation System
  async processDonation(fromUserId: string, toUserId: string, amount: number, message?: string, streamId?: string): Promise<boolean> {
    try {
      const donation: Donation = {
        id: `donation_${Date.now()}`,
        fromUserId,
        toUserId,
        amount,
        currency: 'USD',
        message,
        anonymous: false,
        timestamp: new Date(),
        streamId,
        recurring: false,
        status: 'completed',
      };

      // Calculate fees
      const platformFee = amount * this.PLATFORM_FEE_RATE;
      const processingFee = amount * this.PAYMENT_PROCESSING_FEE;
      const netAmount = amount - platformFee - processingFee;

      console.log(`Donation processed: $${amount} -> $${netAmount} to creator`);
      
      // Trigger notification to creator
      await this.notifyCreator(toUserId, 'donation', donation);

      return true;
    } catch (error) {
      console.error('Error processing donation:', error);
      return false;
    }
  }

  // Merchandise System
  async createMerchandise(creatorId: string, product: Omit<Merchandise, 'id' | 'sales' | 'rating'>): Promise<boolean> {
    try {
      const merchandise: Merchandise = {
        ...product,
        id: `merch_${Date.now()}`,
        sales: 0,
        rating: 0,
      };

      console.log(`Created merchandise for creator ${creatorId}:`, merchandise.name);
      return true;
    } catch (error) {
      console.error('Error creating merchandise:', error);
      return false;
    }
  }

  async purchaseMerchandise(buyerId: string, merchandiseId: string, variant?: any): Promise<boolean> {
    try {
      console.log(`User ${buyerId} purchased merchandise ${merchandiseId}`);
      return true;
    } catch (error) {
      console.error('Error purchasing merchandise:', error);
      return false;
    }
  }

  // Consultation Services
  async createConsultationService(creatorId: string, service: Omit<ConsultationService, 'id' | 'bookings' | 'rating' | 'reviews'>): Promise<boolean> {
    try {
      const consultationService: ConsultationService = {
        ...service,
        id: `consult_${Date.now()}`,
        bookings: [],
        rating: 0,
        reviews: [],
      };

      console.log(`Created consultation service for creator ${creatorId}:`, consultationService.title);
      return true;
    } catch (error) {
      console.error('Error creating consultation service:', error);
      return false;
    }
  }

  async bookConsultation(clientId: string, serviceId: string, scheduledDate: Date): Promise<boolean> {
    try {
      const booking: ConsultationBooking = {
        id: `booking_${Date.now()}`,
        serviceId,
        clientId,
        scheduledDate,
        duration: 60, // Default 1 hour
        status: 'scheduled',
        payment: {
          amount: 150, // Mock price
          status: 'pending',
          transactionId: `txn_${Date.now()}`,
        },
      };

      console.log(`Consultation booked for client ${clientId}`);
      return true;
    } catch (error) {
      console.error('Error booking consultation:', error);
      return false;
    }
  }

  // Content Marketplace
  async listContent(creatorId: string, content: Omit<ContentMarketplace, 'id' | 'sales' | 'rating'>): Promise<boolean> {
    try {
      const listing: ContentMarketplace = {
        ...content,
        id: `content_${Date.now()}`,
        sales: 0,
        rating: 0,
      };

      console.log(`Listed content for creator ${creatorId}:`, listing.title);
      return true;
    } catch (error) {
      console.error('Error listing content:', error);
      return false;
    }
  }

  async purchaseContent(buyerId: string, contentId: string): Promise<{ success: boolean; downloadUrl?: string }> {
    try {
      console.log(`User ${buyerId} purchased content ${contentId}`);
      return {
        success: true,
        downloadUrl: `https://downloads.stormchasers.com/${contentId}`,
      };
    } catch (error) {
      console.error('Error purchasing content:', error);
      return { success: false };
    }
  }

  // Analytics & Revenue
  async getCreatorAnalytics(userId: string, period: { start: Date; end: Date }): Promise<CreatorAnalytics> {
    try {
      // Mock analytics data
      return {
        userId,
        period,
        metrics: {
          followers: { current: 25420, change: 1240, growth_rate: 0.051 },
          views: { total: 145000, unique: 98000, average_duration: 8.5 },
          engagement: { likes: 12400, comments: 3200, shares: 890, rate: 0.067 },
          revenue: { total: 2340, change: 340, per_follower: 0.092 },
          content: { uploads: 12, streams: 8, total_hours: 45.5 },
        },
        topContent: [
          {
            id: 'content_1',
            title: 'Epic Tornado Intercept',
            type: 'stream',
            views: 28000,
            revenue: 450,
            engagement: 0.12,
          },
          {
            id: 'content_2',
            title: 'Storm Photography Tutorial',
            type: 'video',
            views: 15000,
            revenue: 180,
            engagement: 0.095,
          },
        ],
        audienceInsights: {
          demographics: {
            age_groups: { '18-24': 0.15, '25-34': 0.35, '35-44': 0.28, '45+': 0.22 },
            locations: { 'USA': 0.78, 'Canada': 0.12, 'Europe': 0.08, 'Other': 0.02 },
            devices: { 'Mobile': 0.62, 'Desktop': 0.28, 'Tablet': 0.10 },
          },
          behavior: {
            peak_hours: { '18:00': 0.25, '19:00': 0.30, '20:00': 0.28, '21:00': 0.17 },
            engagement_patterns: { 'weekdays': 0.4, 'weekends': 0.6 },
          },
          interests: ['Weather', 'Photography', 'Science', 'Adventure', 'Nature'],
        },
      };
    } catch (error) {
      console.error('Error getting creator analytics:', error);
      throw error;
    }
  }

  async getRevenueSummary(userId: string, period: 'monthly' | 'yearly' = 'monthly'): Promise<Revenue[]> {
    try {
      // Mock revenue data
      const baseRevenue: Revenue = {
        userId,
        period,
        date: new Date(),
        breakdown: {
          subscriptions: 1240,
          donations: 680,
          merchandise: 420,
          consultations: 300,
          content_sales: 150,
          sponsorships: 800,
          affiliates: 120,
          total: 3710,
        },
        fees: {
          platform: 185.5,
          payment_processing: 107.6,
          taxes: 556.5,
          total: 849.6,
        },
        net: 2860.4,
      };

      return [baseRevenue];
    } catch (error) {
      console.error('Error getting revenue summary:', error);
      return [];
    }
  }

  // Helper methods
  private async getSubscriptionTier(tierId: string): Promise<SubscriptionTier | null> {
    // Mock subscription tier lookup
    return {
      id: tierId,
      name: 'Storm Supporter',
      description: 'Support storm chasing content',
      price: 9.99,
      benefits: ['Ad-free viewing', 'Exclusive content', 'Discord access'],
      perks: {
        exclusiveContent: true,
        earlyAccess: true,
        privateCommunity: true,
        directMessaging: false,
        customEmotes: true,
        prioritySupport: false,
        merchandise: false,
        meetAndGreet: false,
      },
      subscriberCount: 124,
      color: '#FF6B6B',
      icon: '⭐',
    };
  }

  private async notifyCreator(creatorId: string, type: string, data: any): Promise<void> {
    console.log(`Notifying creator ${creatorId} about ${type}:`, data);
  }

  // Payment processing
  async processPayment(amount: number, method: 'card' | 'paypal' | 'crypto'): Promise<{ success: boolean; transactionId?: string }> {
    try {
      // Mock payment processing
      const transactionId = `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      // Simulate payment delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      return {
        success: Math.random() > 0.05, // 95% success rate
        transactionId,
      };
    } catch (error) {
      console.error('Error processing payment:', error);
      return { success: false };
    }
  }

  // Payout management
  async requestPayout(creatorId: string, amount: number): Promise<boolean> {
    try {
      console.log(`Payout requested by creator ${creatorId}: $${amount}`);
      return true;
    } catch (error) {
      console.error('Error requesting payout:', error);
      return false;
    }
  }
}

export const creatorEconomyService = new CreatorEconomyService();