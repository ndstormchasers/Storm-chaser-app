import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { RootStackParamList } from '../types';
import HomeScreen from '../screens/HomeScreen';
import LiveStreamsScreen from '../screens/LiveStreamsScreen';
import ProfileScreen from '../screens/ProfileScreen';
import StreamDetailScreen from '../screens/StreamDetailScreen';
import GoLiveScreen from '../screens/GoLiveScreen';
import MyProfileScreen from '../screens/MyProfileScreen';
import WeatherAlertsScreen from '../screens/WeatherAlertsScreen';
import FeaturesScreen from '../screens/FeaturesScreen';
import WeatherRadarScreen from '../screens/WeatherRadarScreen';
import AIPredictionsScreen from '../screens/AIPredictionsScreen';
import GamificationScreen from '../screens/GamificationScreen';
import AdminDashboardScreen from '../screens/AdminDashboardScreen';
import AdminUsersScreen from '../screens/AdminUsersScreen';
import AdminReportsScreen from '../screens/AdminReportsScreen';
import AdminStreamsScreen from '../screens/AdminStreamsScreen';
import AdminAnalyticsScreen from '../screens/AdminAnalyticsScreen';

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator();

function TabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap;

          if (route.name === 'Home') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === 'LiveStreams') {
            iconName = focused ? 'radio' : 'radio-outline';
          } else if (route.name === 'Features') {
            iconName = focused ? 'apps' : 'apps-outline';
          } else if (route.name === 'Alerts') {
            iconName = focused ? 'warning' : 'warning-outline';
          } else {
            iconName = focused ? 'person' : 'person-outline';
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#0ea5e9',
        tabBarInactiveTintColor: '#64748b',
        tabBarStyle: {
          backgroundColor: '#1e293b',
          borderTopColor: '#334155',
        },
        headerShown: false,
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="LiveStreams" component={LiveStreamsScreen} />
      <Tab.Screen name="Features" component={FeaturesScreen} />
      <Tab.Screen name="Alerts" component={WeatherAlertsScreen} options={{ title: 'Alerts' }} />
      <Tab.Screen name="MyProfile" component={MyProfileScreen} options={{ title: 'Profile' }} />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  return (
    <Stack.Navigator>
      <Stack.Screen 
        name="Home" 
        component={TabNavigator} 
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="Profile" 
        component={ProfileScreen}
        options={{ 
          title: 'Storm Chaser Profile',
          headerTintColor: '#0ea5e9',
          headerStyle: {
            backgroundColor: '#1e293b',
          },
          headerTitleStyle: {
            color: '#f8fafc',
          },
        }}
      />
      <Stack.Screen 
        name="StreamDetail" 
        component={StreamDetailScreen}
        options={{ 
          presentation: 'modal',
          title: 'Live Stream',
          headerTintColor: '#0ea5e9',
          headerStyle: {
            backgroundColor: '#1e293b',
          },
          headerTitleStyle: {
            color: '#f8fafc',
          },
        }}
      />
      <Stack.Screen 
        name="AdminDashboard" 
        component={AdminDashboardScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="AdminUsers" 
        component={AdminUsersScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="AdminReports" 
        component={AdminReportsScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="AdminStreams" 
        component={AdminStreamsScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="AdminAnalytics" 
        component={AdminAnalyticsScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="WeatherRadar" 
        component={WeatherRadarScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="AIPredictions" 
        component={AIPredictionsScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="Gamification" 
        component={GamificationScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="GoLive" 
        component={GoLiveScreen}
        options={{ 
          presentation: 'modal',
          title: 'Go Live',
          headerTintColor: '#0ea5e9',
          headerStyle: {
            backgroundColor: '#1e293b',
          },
          headerTitleStyle: {
            color: '#f8fafc',
          },
        }}
      />
    </Stack.Navigator>
  );
}