import React from 'react';
import { View, Text } from 'react-native';
import AuthNavigator from './AuthNavigator';
import AppNavigator from './AppNavigator';
import { useAuthStore } from '../state/auth';

export default function RootNavigator() {
  try {
    const { isLoggedIn } = useAuthStore();
    return isLoggedIn ? <AppNavigator /> : <AuthNavigator />;
  } catch (error) {
    // Fallback UI if store fails
    console.error('RootNavigator error:', error);
    return <AuthNavigator />;
  }
}