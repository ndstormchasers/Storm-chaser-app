import { useEffect } from 'react';
import { AppState, AppStateStatus } from 'react-native';
import { useWeatherStore } from '../state/weather';

export const useWeatherAlerts = () => {
  const { fetchAlerts, alertsEnabled } = useWeatherStore();

  useEffect(() => {
    // Fetch alerts when component mounts
    if (alertsEnabled) {
      fetchAlerts();
    }

    // Set up app state listener to fetch alerts when app becomes active
    const handleAppStateChange = (nextAppState: AppStateStatus) => {
      if (nextAppState === 'active' && alertsEnabled) {
        fetchAlerts();
      }
    };

    const subscription = AppState.addEventListener('change', handleAppStateChange);

    // Set up periodic refresh (every 5 minutes)
    const intervalId = setInterval(() => {
      if (alertsEnabled) {
        fetchAlerts();
      }
    }, 5 * 60 * 1000); // 5 minutes

    return () => {
      subscription?.remove();
      clearInterval(intervalId);
    };
  }, [alertsEnabled, fetchAlerts]);

  return useWeatherStore();
};