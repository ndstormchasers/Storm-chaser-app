import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { WeatherAlert, LocationCoords, WeatherCondition, weatherAlertsService } from '../api/weather-alerts';

interface WeatherState {
  alerts: WeatherAlert[];
  currentWeather: WeatherCondition | null;
  userLocation: LocationCoords | null;
  lastUpdate: Date | null;
  isLoading: boolean;
  error: string | null;
  alertsEnabled: boolean;
  severityFilter: string[];
  fetchAlerts: () => Promise<void>;
  refreshWeatherData: () => Promise<void>;
  setLocation: (location: LocationCoords) => void;
  toggleAlertsEnabled: () => void;
  setSeverityFilter: (severities: string[]) => void;
  dismissAlert: (alertId: string) => void;
  clearError: () => void;
}

export const useWeatherStore = create<WeatherState>()(
  persist(
    (set, get) => ({
      alerts: [],
      currentWeather: null,
      userLocation: null,
      lastUpdate: null,
      isLoading: false,
      error: null,
      alertsEnabled: true,
      severityFilter: ['extreme', 'severe', 'moderate'],

      fetchAlerts: async () => {
        const { alertsEnabled, userLocation } = get();
        
        if (!alertsEnabled) return;
        
        set({ isLoading: true, error: null });
        
        try {
          // Get location - allow fallback for app stability
          let location = userLocation;
          
          if (!location) {
            try {
              location = await weatherAlertsService.getCurrentLocation();
              set({ userLocation: location });
              console.log('📍 REAL GPS SUCCESS:', location);
            } catch (locationError) {
              // Use fallback location to prevent app crash
              location = { latitude: 35.4676, longitude: -97.5164 };
              set({ userLocation: location });
              console.log('📍 Using fallback location due to GPS error');
            }
          }
          
          // Fetch alerts and current weather
          const [alerts, currentWeather] = await Promise.all([
            weatherAlertsService.getWeatherAlerts(location),
            weatherAlertsService.getCurrentWeather(location)
          ]);
          
          set({
            alerts,
            currentWeather,
            lastUpdate: new Date(),
            isLoading: false,
            error: null,
          });
        } catch (error) {
          console.error('Error fetching weather data:', error);
          set({
            isLoading: false,
            error: error instanceof Error ? error.message : 'Failed to fetch weather data',
          });
        }
      },

      refreshWeatherData: async () => {
        const { fetchAlerts } = get();
        await fetchAlerts();
      },

      setLocation: (location: LocationCoords) => {
        set({ userLocation: location });
      },

      toggleAlertsEnabled: () => {
        set((state) => ({ alertsEnabled: !state.alertsEnabled }));
      },

      setSeverityFilter: (severities: string[]) => {
        set({ severityFilter: severities });
      },

      dismissAlert: (alertId: string) => {
        set((state) => ({
          alerts: state.alerts.filter(alert => alert.id !== alertId)
        }));
      },

      clearError: () => {
        set({ error: null });
      },
    }),
    {
      name: 'weather-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        userLocation: state.userLocation,
        alertsEnabled: state.alertsEnabled,
        severityFilter: state.severityFilter,
      }),
    }
  )
);