import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StormChaser, LiveStream, Chat } from '../types';

interface StormChaserState {
  chasers: StormChaser[];
  liveStreams: LiveStream[];
  chats: Chat[];
  currentUser: StormChaser | null;
  addChaser: (chaser: StormChaser) => void;
  addLiveStream: (stream: LiveStream) => void;
  endLiveStream: (streamId: string) => void;
  addChat: (chat: Chat) => void;
  updateViewerCount: (streamId: string, viewers: number) => void;
  setCurrentUser: (user: StormChaser) => void;
}

export const useStormChaserStore = create<StormChaserState>()(
  persist(
    (set, get) => ({
      chasers: [], // Production: Real storm chasers will be added when they join
      liveStreams: [], // Production: Real live streams from authenticated users only
      chats: [],
      currentUser: null,
      addChaser: (chaser) =>
        set((state) => ({
          chasers: [...state.chasers, chaser],
        })),
      addLiveStream: (stream) =>
        set((state) => ({
          liveStreams: [...state.liveStreams, stream],
        })),
      endLiveStream: (streamId) =>
        set((state) => ({
          liveStreams: state.liveStreams.filter((s) => s.id !== streamId),
        })),
      addChat: (chat) =>
        set((state) => ({
          chats: [...state.chats, chat],
        })),
      updateViewerCount: (streamId, viewers) =>
        set((state) => ({
          liveStreams: state.liveStreams.map((s) =>
            s.id === streamId ? { ...s, viewers } : s
          ),
        })),
      setCurrentUser: (user) =>
        set({ currentUser: user }),
    }),
    {
      name: 'storm-chaser-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        chasers: state.chasers,
        currentUser: state.currentUser,
      }),
    }
  )
);