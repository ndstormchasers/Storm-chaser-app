export interface StormChaser {
  id: string;
  name: string;
  avatar: string;
  location: string;
  isLive: boolean;
  followers: number;
  bio: string;
  stormsCaught: number;
  yearsExperience: number;
}

export interface LiveStream {
  id: string;
  chaserId: string;
  title: string;
  description: string;
  viewers: number;
  startTime: Date;
  location: string;
  weatherCondition: string;
  thumbnail: string;
  platform?: 'youtube' | 'twitch' | 'mock';
  streamUrl?: string;
  streamKey?: string;
  broadcastId?: string;
  externalStreamId?: string;
}

export interface Chat {
  id: string;
  streamId: string;
  userId: string;
  username: string;
  message: string;
  timestamp: Date;
}

export interface User {
  id: string;
  email: string;
  username: string;
  firstName: string;
  lastName: string;
  avatar: string;
  location: string;
  bio: string;
  isVerified: boolean;
  joinedDate: Date;
  role?: 'user' | 'moderator' | 'admin';
  status?: 'active' | 'suspended' | 'banned';
  lastActive?: Date;
}

export interface AdminStats {
  totalUsers: number;
  activeUsers: number;
  totalStreams: number;
  activeStreams: number;
  totalAlerts: number;
  reportsToday: number;
}

export interface Report {
  id: string;
  reporterId: string;
  reportedUserId?: string;
  reportedStreamId?: string;
  type: 'inappropriate_content' | 'harassment' | 'spam' | 'fake_alert' | 'other';
  reason: string;
  description: string;
  status: 'pending' | 'investigating' | 'resolved' | 'dismissed';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  createdAt: Date;
  resolvedAt?: Date;
  resolvedBy?: string;
  resolution?: string;
}

export type AuthStackParamList = {
  Welcome: undefined;
  Login: undefined;
  SignUp: undefined;
  ForgotPassword: undefined;
};

export type RootStackParamList = {
  Home: undefined;
  LiveStreams: undefined;
  Profile: { chaserId: string };
  StreamDetail: { streamId: string };
  GoLive: undefined;
  Features: undefined;
  WeatherRadar: undefined;
  AIPredictions: undefined;
  Gamification: undefined;
  MultiCamera: undefined;
  SafetyCenter: undefined;
  Education: undefined;
  CreatorEconomy: undefined;
  SocialIntegration: undefined;
  RoutePlanning: undefined;
  ImageRecognition: undefined;
  AdminDashboard: undefined;
  AdminUsers: undefined;
  AdminReports: undefined;
  AdminStreams: undefined;
  AdminAnalytics: undefined;
};