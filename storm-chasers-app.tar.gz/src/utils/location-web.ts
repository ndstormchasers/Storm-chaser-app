import { Platform } from 'react-native';

export interface LocationCoords {
  latitude: number;
  longitude: number;
}

export interface LocationResponse {
  coords: LocationCoords;
}

export const LocationAccuracy = {
  Lowest: 1,
  Low: 2,
  Balanced: 3,
  High: 4,
  Highest: 5,
  BestForNavigation: 6,
};

export const LocationPermissionResponse = {
  GRANTED: 'granted',
  DENIED: 'denied',
  UNDETERMINED: 'undetermined',
};

export const requestForegroundPermissionsAsync = async () => {
  if (Platform.OS === 'web') {
    try {
      // Request web geolocation permission
      const permission = await navigator.permissions.query({ name: 'geolocation' });
      return {
        status: permission.state === 'granted' ? 'granted' : 'denied',
        granted: permission.state === 'granted',
      };
    } catch (error) {
      console.log('Web geolocation permission check failed:', error);
      return { status: 'undetermined', granted: false };
    }
  }
  
  // For native platforms, this would use expo-location
  return { status: 'granted', granted: true };
};

export const getCurrentPositionAsync = async (options?: {
  accuracy?: number;
  maximumAge?: number;
}): Promise<LocationResponse> => {
  if (Platform.OS === 'web') {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation is not supported by this browser'));
        return;
      }

      const webOptions = {
        enableHighAccuracy: (options?.accuracy || 0) > 3,
        timeout: 10000,
        maximumAge: options?.maximumAge || 60000,
      };

      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            coords: {
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
            },
          });
        },
        (error) => {
          console.error('Web geolocation error:', error);
          reject(error);
        },
        webOptions
      );
    });
  }

  // For native platforms, this would use expo-location
  throw new Error('Native location not available in web context');
};

export const Accuracy = LocationAccuracy;