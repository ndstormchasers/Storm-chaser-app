import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User, AdminStats, Report } from '../types';

interface AdminState {
  isAdmin: boolean;
  stats: AdminStats;
  allUsers: User[];
  reports: Report[];
  isLoading: boolean;
  error: string | null;
  
  // Admin actions
  checkAdminAccess: (user: User | null) => boolean;
  fetchAdminData: () => Promise<void>;
  updateUserStatus: (userId: string, status: 'active' | 'suspended' | 'banned') => Promise<boolean>;
  updateUserRole: (userId: string, role: 'user' | 'moderator' | 'admin') => Promise<boolean>;
  verifyUser: (userId: string, verified: boolean) => Promise<boolean>;
  deleteUser: (userId: string) => Promise<boolean>;
  resolveReport: (reportId: string, resolution: string) => Promise<boolean>;
  createReport: (report: Omit<Report, 'id' | 'createdAt'>) => Promise<boolean>;
  
  // Analytics
  getUserStats: () => { active: number; suspended: number; banned: number; };
  getReportStats: () => { pending: number; urgent: number; resolved: number; };
}

export const useAdminStore = create<AdminState>()(
  persist(
    (set, get) => ({
      isAdmin: false,
      stats: {
        totalUsers: 0,
        activeUsers: 0,
        totalStreams: 0,
        activeStreams: 0,
        totalAlerts: 0,
        reportsToday: 0,
      },
      allUsers: [],
      reports: [],
      isLoading: false,
      error: null,

      checkAdminAccess: (user: User | null) => {
        if (!user) return false;
        
        // Demo admin access - allow specific emails or admin role
        const adminEmails = ['admin@stormchasers.com', 'jake@stormchaser.com'];
        const adminUsernames = ['ndstormchasers2025', 'jakestorm', 'admin'];
        const hasAdminRole = user.role === 'admin' || user.role === 'moderator';
        const hasAdminEmail = adminEmails.includes(user.email.toLowerCase());
        const hasAdminUsername = adminUsernames.includes(user.username.toLowerCase());
        
        const isAdmin = hasAdminRole || hasAdminEmail || hasAdminUsername;
        set({ isAdmin });
        return isAdmin;
      },

      fetchAdminData: async () => {
        set({ isLoading: true, error: null });
        
        try {
          // Simulate API delay
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          // Mock admin data
          const mockUsers: User[] = [
            {
              id: '1',
              email: 'jake@stormchaser.com',
              username: 'jakestorm',
              firstName: 'Jake',
              lastName: 'Storm',
              avatar: '🌪️',
              location: 'Oklahoma, USA',
              bio: 'Professional storm chaser',
              isVerified: true,
              joinedDate: new Date('2020-01-15'),
              role: 'admin',
              status: 'active',
              lastActive: new Date(),
            },
            {
              id: '2',
              email: 'sarah@weather.com',
              username: 'sarahweather',
              firstName: 'Sarah',
              lastName: 'Weather',
              avatar: '⛈️',
              location: 'Kansas, USA',
              bio: 'Meteorologist turned storm chaser',
              isVerified: true,
              joinedDate: new Date('2021-03-20'),
              role: 'moderator',
              status: 'active',
              lastActive: new Date(Date.now() - 2 * 60 * 60 * 1000),
            },
            {
              id: '3',
              email: 'mike@thunder.com',
              username: 'mikethunder',
              firstName: 'Mike',
              lastName: 'Thunder',
              avatar: '🌩️',
              location: 'Texas, USA',
              bio: 'Tornado Alley native',
              isVerified: false,
              joinedDate: new Date('2022-07-10'),
              role: 'user',
              status: 'active',
              lastActive: new Date(Date.now() - 24 * 60 * 60 * 1000),
            },
            {
              id: '4',
              email: 'spammer@fake.com',
              username: 'spammer123',
              firstName: 'Spam',
              lastName: 'Bot',
              avatar: '🤖',
              location: 'Unknown',
              bio: 'Suspicious account',
              isVerified: false,
              joinedDate: new Date('2024-01-01'),
              role: 'user',
              status: 'suspended',
              lastActive: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
            },
          ];

          const mockReports: Report[] = [
            {
              id: 'report_1',
              reporterId: '2',
              reportedUserId: '4',
              type: 'spam',
              reason: 'Posting spam content in streams',
              description: 'User is flooding chat with promotional links and inappropriate content.',
              status: 'pending',
              priority: 'high',
              createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
            },
            {
              id: 'report_2',
              reporterId: '3',
              reportedStreamId: 'stream_123',
              type: 'inappropriate_content',
              reason: 'False storm information',
              description: 'Stream is broadcasting fake tornado warnings causing panic.',
              status: 'investigating',
              priority: 'urgent',
              createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
            },
            {
              id: 'report_3',
              reporterId: '1',
              reportedUserId: '5',
              type: 'harassment',
              reason: 'Harassing other users',
              description: 'Multiple complaints about hostile behavior in chat.',
              status: 'resolved',
              priority: 'medium',
              createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
              resolvedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
              resolvedBy: '1',
              resolution: 'User warned and content removed. Monitoring for further violations.',
            },
          ];

          const stats: AdminStats = {
            totalUsers: mockUsers.length,
            activeUsers: mockUsers.filter(u => u.status === 'active').length,
            totalStreams: 12,
            activeStreams: 3,
            totalAlerts: 8,
            reportsToday: mockReports.filter(r => 
              r.createdAt.toDateString() === new Date().toDateString()
            ).length,
          };

          set({
            allUsers: mockUsers,
            reports: mockReports,
            stats,
            isLoading: false,
          });
        } catch (error) {
          set({
            error: 'Failed to fetch admin data',
            isLoading: false,
          });
        }
      },

      updateUserStatus: async (userId: string, status: 'active' | 'suspended' | 'banned') => {
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 500));
          
          set(state => ({
            allUsers: state.allUsers.map(user =>
              user.id === userId ? { ...user, status } : user
            ),
          }));
          return true;
        } catch (error) {
          return false;
        }
      },

      updateUserRole: async (userId: string, role: 'user' | 'moderator' | 'admin') => {
        try {
          await new Promise(resolve => setTimeout(resolve, 500));
          
          set(state => ({
            allUsers: state.allUsers.map(user =>
              user.id === userId ? { ...user, role } : user
            ),
          }));
          return true;
        } catch (error) {
          return false;
        }
      },

      verifyUser: async (userId: string, verified: boolean) => {
        try {
          await new Promise(resolve => setTimeout(resolve, 500));
          
          set(state => ({
            allUsers: state.allUsers.map(user =>
              user.id === userId ? { ...user, isVerified: verified } : user
            ),
          }));
          return true;
        } catch (error) {
          return false;
        }
      },

      deleteUser: async (userId: string) => {
        try {
          await new Promise(resolve => setTimeout(resolve, 500));
          
          set(state => ({
            allUsers: state.allUsers.filter(user => user.id !== userId),
          }));
          return true;
        } catch (error) {
          return false;
        }
      },

      resolveReport: async (reportId: string, resolution: string) => {
        try {
          await new Promise(resolve => setTimeout(resolve, 500));
          
          set(state => ({
            reports: state.reports.map(report =>
              report.id === reportId
                ? {
                    ...report,
                    status: 'resolved' as const,
                    resolution,
                    resolvedAt: new Date(),
                    resolvedBy: '1', // Current admin user
                  }
                : report
            ),
          }));
          return true;
        } catch (error) {
          return false;
        }
      },

      createReport: async (reportData: Omit<Report, 'id' | 'createdAt'>) => {
        try {
          await new Promise(resolve => setTimeout(resolve, 500));
          
          const newReport: Report = {
            ...reportData,
            id: `report_${Date.now()}`,
            createdAt: new Date(),
          };
          
          set(state => ({
            reports: [newReport, ...state.reports],
          }));
          return true;
        } catch (error) {
          return false;
        }
      },

      getUserStats: () => {
        const { allUsers } = get();
        return {
          active: allUsers.filter(u => u.status === 'active').length,
          suspended: allUsers.filter(u => u.status === 'suspended').length,
          banned: allUsers.filter(u => u.status === 'banned').length,
        };
      },

      getReportStats: () => {
        const { reports } = get();
        return {
          pending: reports.filter(r => r.status === 'pending').length,
          urgent: reports.filter(r => r.priority === 'urgent').length,
          resolved: reports.filter(r => r.status === 'resolved').length,
        };
      },
    }),
    {
      name: 'admin-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        isAdmin: state.isAdmin,
      }),
    }
  )
);