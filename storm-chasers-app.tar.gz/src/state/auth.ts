import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User } from '../types';

// Real User Database Service
class UserDatabaseService {
  private readonly USERS_STORAGE_KEY = 'storm_chasers_users';
  private readonly SESSIONS_STORAGE_KEY = 'storm_chasers_sessions';

  async getAllUsers(): Promise<User[]> {
    try {
      const usersData = await AsyncStorage.getItem(this.USERS_STORAGE_KEY);
      return usersData ? JSON.parse(usersData) : [];
    } catch (error) {
      console.error('Error loading users:', error);
      return [];
    }
  }

  async saveUser(user: User): Promise<void> {
    try {
      const users = await this.getAllUsers();
      const existingIndex = users.findIndex(u => u.id === user.id);
      
      if (existingIndex >= 0) {
        users[existingIndex] = user;
      } else {
        users.push(user);
      }
      
      await AsyncStorage.setItem(this.USERS_STORAGE_KEY, JSON.stringify(users));
    } catch (error) {
      console.error('Error saving user:', error);
      throw error;
    }
  }

  async findUserByEmail(email: string): Promise<User | null> {
    const users = await this.getAllUsers();
    return users.find(u => u.email.toLowerCase() === email.toLowerCase()) || null;
  }

  async findUserByUsername(username: string): Promise<User | null> {
    const users = await this.getAllUsers();
    return users.find(u => u.username.toLowerCase() === username.toLowerCase()) || null;
  }

  async createUser(userData: Omit<User, 'id' | 'joinedDate' | 'isVerified' | 'lastActive'>): Promise<User> {
    const newUser: User = {
      ...userData,
      id: this.generateUserId(),
      joinedDate: new Date(),
      isVerified: false,
      role: userData.username === 'ndstormchasers2025' ? 'admin' : 'user',
      status: 'active',
      lastActive: new Date(),
    };

    await this.saveUser(newUser);
    console.log('🆕 NEW USER CREATED:', newUser.username);
    return newUser;
  }

  async updateUser(userId: string, updates: Partial<User>): Promise<User | null> {
    const users = await this.getAllUsers();
    const userIndex = users.findIndex(u => u.id === userId);
    
    if (userIndex >= 0) {
      users[userIndex] = { ...users[userIndex], ...updates, lastActive: new Date() };
      await AsyncStorage.setItem(this.USERS_STORAGE_KEY, JSON.stringify(users));
      return users[userIndex];
    }
    
    return null;
  }

  private generateUserId(): string {
    return 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  // Initialize with admin accounts if no users exist
  async initializeDefaultUsers(): Promise<void> {
    const users = await this.getAllUsers();
    if (users.length === 0) {
      const adminUser: User = {
        id: 'admin_ndstormchasers2025',
        email: 'ndstormchasers2025@email.com',
        username: 'ndstormchasers2025',
        firstName: 'ND',
        lastName: 'StormChasers',
        avatar: '⛈️',
        location: 'North Dakota, USA',
        bio: 'Admin account for ND Storm Chasers community.',
        isVerified: true,
        joinedDate: new Date('2023-01-01'),
        role: 'admin',
        status: 'active',
        lastActive: new Date(),
      };
      
      await this.saveUser(adminUser);
      console.log('🔧 INITIALIZED DEFAULT ADMIN USER');
    }
  }
}

const userDatabase = new UserDatabaseService();

interface AuthState {
  user: User | null;
  isLoggedIn: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<boolean>;
  signUp: (userData: Omit<User, 'id' | 'joinedDate' | 'isVerified' | 'lastActive'>) => Promise<boolean>;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => Promise<boolean>;
  resetPassword: (email: string) => Promise<boolean>;
  validateUser: (email: string) => Promise<boolean>;
  clearError: () => void;
}

// Mock users for demo
const mockUsers: User[] = [
  {
    id: '1',
    email: 'jake@stormchaser.com',
    username: 'jakestorm',
    firstName: 'Jake',
    lastName: 'Storm',
    avatar: '🌪️',
    location: 'Oklahoma, USA',
    bio: 'Professional storm chaser with 15 years experience.',
    isVerified: true,
    joinedDate: new Date('2020-01-15'),
    role: 'admin',
    status: 'active',
    lastActive: new Date(),
  },
  {
    id: '2',
    email: 'ndstormchasers2025@email.com',
    username: 'ndstormchasers2025',
    firstName: 'ND',
    lastName: 'StormChasers',
    avatar: '⛈️',
    location: 'North Dakota, USA',
    bio: 'Admin account for ND Storm Chasers community.',
    isVerified: true,
    joinedDate: new Date('2023-01-01'),
    role: 'admin',
    status: 'active',
    lastActive: new Date(),
  },
];

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isLoggedIn: false,
      isLoading: false,
      error: null,

      login: async (email: string, password: string) => {
        set({ isLoading: true, error: null });
        
        try {
          await userDatabase.initializeDefaultUsers();
          const user = await userDatabase.findUserByEmail(email);
          
          if (user) {
            await userDatabase.updateUser(user.id, { lastActive: new Date() });
            set({ user, isLoggedIn: true, isLoading: false });
            console.log('✅ REAL USER LOGIN:', user.username);
            return true;
          } else if (email.includes('@')) {
            const newUser = await userDatabase.createUser({
              email: email.toLowerCase(),
              username: email.split('@')[0],
              firstName: 'Storm', lastName: 'Chaser', avatar: '⛈️',
              location: 'Storm Alley, USA', bio: 'New storm chaser!',
              role: 'user', status: 'active'
            });
            set({ user: newUser, isLoggedIn: true, isLoading: false });
            return true;
          }
          return false;
        } catch (error) {
          set({ isLoading: false, error: 'Login failed' });
          return false;
        }
      },

      signUp: async (userData) => {
        set({ isLoading: true, error: null });
        try {
          const existingUser = await userDatabase.findUserByEmail(userData.email);
          if (existingUser) {
            set({ isLoading: false, error: 'Email already registered' });
            return false;
          }
          const newUser = await userDatabase.createUser(userData);
          set({ user: newUser, isLoggedIn: true, isLoading: false });
          console.log('✅ REAL USER REGISTRATION:', newUser.username);
          return true;
        } catch (error) {
          set({ isLoading: false, error: 'Registration failed' });
          return false;
        }
      },

      logout: () => {
        console.log('👋 USER LOGOUT');
        set({ user: null, isLoggedIn: false, error: null });
      },

      updateProfile: async (updates) => {
        const { user } = get();
        if (!user) return false;
        try {
          const updatedUser = await userDatabase.updateUser(user.id, updates);
          if (updatedUser) {
            set({ user: updatedUser });
            console.log('✅ PROFILE UPDATED:', updatedUser.username);
            return true;
          }
          return false;
        } catch { return false; }
      },

      resetPassword: async (email: string) => {
        set({ isLoading: true });
        const user = await userDatabase.findUserByEmail(email);
        set({ isLoading: false });
        return !!user;
      },

      validateUser: async (email: string) => !!(await userDatabase.findUserByEmail(email)),
      clearError: () => set({ error: null }),
    }),
    {
      name: 'storm-chasers-auth',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({ user: state.user, isLoggedIn: state.isLoggedIn }),
    }
  )
);