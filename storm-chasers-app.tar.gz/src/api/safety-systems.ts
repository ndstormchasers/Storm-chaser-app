import * as Location from 'expo-location';
import * as Contacts from 'expo-contacts';

export interface EmergencyContact {
  id: string;
  name: string;
  relationship: string;
  phone: string;
  email?: string;
  priority: 'primary' | 'secondary' | 'backup';
  autoNotify: boolean;
  location?: string;
}

export interface MedicalInfo {
  bloodType?: string;
  allergies: string[];
  medications: string[];
  medicalConditions: string[];
  emergencyMedications: Array<{
    name: string;
    dosage: string;
    location: string; // where it's stored in vehicle
  }>;
  insuranceInfo: {
    provider?: string;
    policyNumber?: string;
    groupNumber?: string;
  };
  emergencyInstructions: string;
}

export interface SafetyEquipment {
  id: string;
  name: string;
  type: 'communication' | 'medical' | 'survival' | 'navigation' | 'weather';
  status: 'available' | 'in_use' | 'missing' | 'expired';
  lastChecked: Date;
  expirationDate?: Date;
  location: string; // where it's stored
  critical: boolean;
  checklistItem: boolean;
}

export interface SafetyZone {
  id: string;
  type: 'shelter' | 'hospital' | 'fire_station' | 'police' | 'gas_station' | 'safe_zone';
  name: string;
  address: string;
  coordinates: { latitude: number; longitude: number };
  distance?: number; // from current location
  capacity?: number;
  services: string[];
  contact?: string;
  hours?: string;
  rating?: number;
}

export interface EmergencyAlert {
  id: string;
  type: 'sos' | 'medical' | 'mechanical' | 'weather' | 'security';
  severity: 'low' | 'medium' | 'high' | 'critical';
  location: { latitude: number; longitude: number };
  timestamp: Date;
  message: string;
  status: 'active' | 'acknowledged' | 'resolved';
  respondents: string[];
  estimatedResponse?: Date;
  resolution?: string;
}

export interface RouteMonitoring {
  id: string;
  startLocation: { latitude: number; longitude: number };
  destination: { latitude: number; longitude: number };
  plannedRoute: Array<{ latitude: number; longitude: number }>;
  currentLocation: { latitude: number; longitude: number };
  checkInInterval: number; // minutes
  lastCheckIn: Date;
  nextCheckIn: Date;
  emergencyContacts: string[];
  autoAlertDelay: number; // minutes after missed check-in
  routeDeviationAlert: boolean;
  maxDeviationDistance: number; // km
}

export interface VehicleStatus {
  fuel: number; // percentage
  battery: number; // percentage
  engineStatus: 'good' | 'warning' | 'critical';
  tiresPressure: { fl: number; fr: number; rl: number; rr: number };
  oilLevel: 'good' | 'low' | 'critical';
  coolantLevel: 'good' | 'low' | 'critical';
  lastMaintenance: Date;
  nextMaintenance: Date;
  issues: string[];
}

class SafetySystemsService {
  private emergencyContacts: EmergencyContact[] = [];
  private medicalInfo: MedicalInfo | null = null;
  private safetyEquipment: SafetyEquipment[] = [];
  private activeAlerts: EmergencyAlert[] = [];
  private routeMonitoring: RouteMonitoring | null = null;

  // Emergency Response
  async triggerEmergencyAlert(type: EmergencyAlert['type'], message: string): Promise<boolean> {
    try {
      const location = await Location.getCurrentPositionAsync();
      
      const alert: EmergencyAlert = {
        id: `emergency_${Date.now()}`,
        type,
        severity: type === 'sos' || type === 'medical' ? 'critical' : 'high',
        location: {
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        },
        timestamp: new Date(),
        message,
        status: 'active',
        respondents: [],
      };

      this.activeAlerts.push(alert);

      // Notify emergency contacts
      await this.notifyEmergencyContacts(alert);

      // Send to emergency services if critical
      if (alert.severity === 'critical') {
        await this.contactEmergencyServices(alert);
      }

      return true;
    } catch (error) {
      console.error('Error triggering emergency alert:', error);
      return false;
    }
  }

  async findNearestSafetyZones(type?: SafetyZone['type'], maxDistance: number = 50): Promise<SafetyZone[]> {
    try {
      const location = await Location.getCurrentPositionAsync();
      
      // Mock safety zones - in production would query real databases
      const allZones: SafetyZone[] = [
        {
          id: 'hospital_001',
          type: 'hospital',
          name: 'Oklahoma University Medical Center',
          address: '1200 Everett Dr, Oklahoma City, OK 73104',
          coordinates: { latitude: 35.2081, longitude: -97.4501 },
          services: ['Emergency Room', 'Trauma Center', 'ICU'],
          contact: '(405) 271-4000',
          hours: '24/7',
          rating: 4.5,
        },
        {
          id: 'shelter_001',
          type: 'shelter',
          name: 'Moore Community Center Storm Shelter',
          address: '700 S Broadway Ave, Moore, OK 73160',
          coordinates: { latitude: 35.3395, longitude: -97.4867 },
          capacity: 500,
          services: ['Public Shelter', 'Emergency Supplies'],
          hours: 'During severe weather',
          rating: 4.8,
        },
        {
          id: 'police_001',
          type: 'police',
          name: 'Oklahoma City Police Department',
          address: '700 Colcord Dr, Oklahoma City, OK 73102',
          coordinates: { latitude: 35.4735, longitude: -97.5136 },
          services: ['Emergency Response', 'Traffic Control'],
          contact: '911',
          hours: '24/7',
          rating: 4.2,
        },
        {
          id: 'gas_001',
          type: 'gas_station',
          name: 'Love\'s Travel Stop',
          address: '10901 S I-35 Service Rd, Oklahoma City, OK 73170',
          coordinates: { latitude: 35.3428, longitude: -97.4814 },
          services: ['Fuel', 'Food', 'Restrooms', 'Wi-Fi'],
          hours: '24/7',
          rating: 4.1,
        },
      ];

      // Filter by type if specified
      let filteredZones = type ? allZones.filter(zone => zone.type === type) : allZones;

      // Calculate distances and filter by max distance
      const currentLocation = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };

      filteredZones = filteredZones.map(zone => ({
        ...zone,
        distance: this.calculateDistance(currentLocation, zone.coordinates),
      })).filter(zone => zone.distance! <= maxDistance);

      // Sort by distance
      return filteredZones.sort((a, b) => a.distance! - b.distance!);
    } catch (error) {
      console.error('Error finding safety zones:', error);
      return [];
    }
  }

  async setupRouteMonitoring(
    destination: { latitude: number; longitude: number },
    checkInInterval: number = 30,
    emergencyContacts: string[]
  ): Promise<boolean> {
    try {
      const currentLocation = await Location.getCurrentPositionAsync();
      
      this.routeMonitoring = {
        id: `route_${Date.now()}`,
        startLocation: {
          latitude: currentLocation.coords.latitude,
          longitude: currentLocation.coords.longitude,
        },
        destination,
        plannedRoute: [
          { latitude: currentLocation.coords.latitude, longitude: currentLocation.coords.longitude },
          destination, // Simplified - in production would calculate actual route
        ],
        currentLocation: {
          latitude: currentLocation.coords.latitude,
          longitude: currentLocation.coords.longitude,
        },
        checkInInterval,
        lastCheckIn: new Date(),
        nextCheckIn: new Date(Date.now() + checkInInterval * 60000),
        emergencyContacts,
        autoAlertDelay: 15, // 15 minutes after missed check-in
        routeDeviationAlert: true,
        maxDeviationDistance: 10, // 10 km
      };

      // Start monitoring background task
      this.startRouteMonitoring();

      return true;
    } catch (error) {
      console.error('Error setting up route monitoring:', error);
      return false;
    }
  }

  async performSafetyCheck(): Promise<{ passed: boolean; issues: string[] }> {
    try {
      const issues: string[] = [];

      // Check emergency contacts
      if (this.emergencyContacts.length === 0) {
        issues.push('No emergency contacts configured');
      }

      // Check medical info
      if (!this.medicalInfo) {
        issues.push('Medical information not provided');
      }

      // Check safety equipment
      const criticalEquipment = this.safetyEquipment.filter(eq => eq.critical);
      const missingCritical = criticalEquipment.filter(eq => eq.status === 'missing');
      const expiredCritical = criticalEquipment.filter(eq => 
        eq.expirationDate && eq.expirationDate < new Date()
      );

      if (missingCritical.length > 0) {
        issues.push(`Missing critical equipment: ${missingCritical.map(eq => eq.name).join(', ')}`);
      }

      if (expiredCritical.length > 0) {
        issues.push(`Expired critical equipment: ${expiredCritical.map(eq => eq.name).join(', ')}`);
      }

      // Check vehicle status (mock)
      const vehicleStatus = await this.getVehicleStatus();
      if (vehicleStatus.fuel < 25) {
        issues.push('Low fuel level (less than 25%)');
      }

      if (vehicleStatus.engineStatus !== 'good') {
        issues.push(`Engine status: ${vehicleStatus.engineStatus}`);
      }

      return {
        passed: issues.length === 0,
        issues,
      };
    } catch (error) {
      console.error('Error performing safety check:', error);
      return { passed: false, issues: ['Error performing safety check'] };
    }
  }

  async getWeatherSafetyRisks(coords: { latitude: number; longitude: number }): Promise<string[]> {
    try {
      const risks: string[] = [];

      // Mock weather risk assessment
      // In production, would analyze current weather data, forecasts, and radar
      
      const mockRisks = [
        'Tornado watch in effect',
        'Large hail possible (>2 inches)',
        'Flash flood risk due to heavy rainfall',
        'Damaging winds expected (>70 mph)',
        'Poor visibility due to heavy rain',
        'Lightning activity increasing',
      ];

      // Randomly assign some risks for demo
      const numRisks = Math.floor(Math.random() * 3);
      for (let i = 0; i < numRisks; i++) {
        const risk = mockRisks[Math.floor(Math.random() * mockRisks.length)];
        if (!risks.includes(risk)) {
          risks.push(risk);
        }
      }

      return risks;
    } catch (error) {
      console.error('Error assessing weather safety risks:', error);
      return [];
    }
  }

  // Configuration methods
  async setEmergencyContacts(contacts: EmergencyContact[]): Promise<boolean> {
    try {
      this.emergencyContacts = contacts;
      return true;
    } catch (error) {
      console.error('Error setting emergency contacts:', error);
      return false;
    }
  }

  async setMedicalInfo(info: MedicalInfo): Promise<boolean> {
    try {
      this.medicalInfo = info;
      return true;
    } catch (error) {
      console.error('Error setting medical info:', error);
      return false;
    }
  }

  async updateSafetyEquipment(equipment: SafetyEquipment[]): Promise<boolean> {
    try {
      this.safetyEquipment = equipment;
      return true;
    } catch (error) {
      console.error('Error updating safety equipment:', error);
      return false;
    }
  }

  // Default safety equipment list
  getDefaultSafetyEquipment(): SafetyEquipment[] {
    return [
      {
        id: 'weather_radio',
        name: 'Weather Radio',
        type: 'communication',
        status: 'available',
        lastChecked: new Date(),
        location: 'Center console',
        critical: true,
        checklistItem: true,
      },
      {
        id: 'first_aid_kit',
        name: 'First Aid Kit',
        type: 'medical',
        status: 'available',
        lastChecked: new Date(),
        expirationDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
        location: 'Trunk',
        critical: true,
        checklistItem: true,
      },
      {
        id: 'emergency_water',
        name: 'Emergency Water (1 gallon)',
        type: 'survival',
        status: 'available',
        lastChecked: new Date(),
        expirationDate: new Date(Date.now() + 180 * 24 * 60 * 60 * 1000),
        location: 'Trunk',
        critical: true,
        checklistItem: true,
      },
      {
        id: 'flashlight',
        name: 'LED Flashlight',
        type: 'survival',
        status: 'available',
        lastChecked: new Date(),
        location: 'Glove compartment',
        critical: true,
        checklistItem: true,
      },
      {
        id: 'phone_charger',
        name: 'Car Phone Charger',
        type: 'communication',
        status: 'available',
        lastChecked: new Date(),
        location: 'Center console',
        critical: true,
        checklistItem: true,
      },
      {
        id: 'gps_device',
        name: 'Backup GPS Device',
        type: 'navigation',
        status: 'available',
        lastChecked: new Date(),
        location: 'Dashboard',
        critical: false,
        checklistItem: true,
      },
    ];
  }

  private async notifyEmergencyContacts(alert: EmergencyAlert): Promise<void> {
    try {
      const primaryContacts = this.emergencyContacts.filter(c => c.autoNotify);
      
      for (const contact of primaryContacts) {
        // In production, would send SMS/call/email
        console.log(`Notifying ${contact.name}: ${alert.message}`);
      }
    } catch (error) {
      console.error('Error notifying emergency contacts:', error);
    }
  }

  private async contactEmergencyServices(alert: EmergencyAlert): Promise<void> {
    try {
      // In production, would interface with emergency services APIs
      console.log('Contacting emergency services:', alert);
    } catch (error) {
      console.error('Error contacting emergency services:', error);
    }
  }

  private startRouteMonitoring(): void {
    // Start background monitoring
    console.log('Route monitoring started');
  }

  private async getVehicleStatus(): Promise<VehicleStatus> {
    // Mock vehicle status
    return {
      fuel: Math.floor(Math.random() * 100),
      battery: Math.floor(Math.random() * 100),
      engineStatus: Math.random() > 0.8 ? 'warning' : 'good',
      tiresPressure: { fl: 32, fr: 32, rl: 30, rr: 31 },
      oilLevel: 'good',
      coolantLevel: 'good',
      lastMaintenance: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
      nextMaintenance: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000),
      issues: [],
    };
  }

  private calculateDistance(
    point1: { latitude: number; longitude: number },
    point2: { latitude: number; longitude: number }
  ): number {
    const R = 6371; // Earth's radius in km
    const dLat = (point2.latitude - point1.latitude) * Math.PI / 180;
    const dLon = (point2.longitude - point1.longitude) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(point1.latitude * Math.PI / 180) * Math.cos(point2.latitude * Math.PI / 180) * 
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }
}

export const safetySystemsService = new SafetySystemsService();