import * as Location from 'expo-location';
import { Platform } from 'react-native';
import * as WebLocation from '../utils/location-web';

export interface WeatherAlert {
  id: string;
  title: string;
  description: string;
  severity: 'minor' | 'moderate' | 'severe' | 'extreme';
  urgency: 'immediate' | 'expected' | 'future' | 'past';
  certainty: 'observed' | 'likely' | 'possible' | 'unlikely';
  event: string;
  headline: string;
  areas: string[];
  effective: Date;
  expires: Date;
  sender: string;
  senderName: string;
  instruction?: string;
  web?: string;
  contact?: string;
  parameters?: { [key: string]: string[] };
  geometry?: {
    type: string;
    coordinates: number[][][];
  };
}

export interface LocationCoords {
  latitude: number;
  longitude: number;
}

export interface WeatherCondition {
  temperature: number;
  humidity: number;
  windSpeed: number;
  windDirection: number;
  pressure: number;
  visibility: number;
  condition: string;
  icon: string;
  description: string;
}

class WeatherAlertsService {
  private readonly NWS_API_BASE = 'https://api.weather.gov';
  private readonly OPENWEATHER_API_KEY = process.env.EXPO_PUBLIC_VIBECODE_OPENWEATHER_API_KEY;
  private readonly NWS_USER_AGENT = 'StormChasersApp/1.0 (contact@stormchasers.app)';

  async getCurrentLocation(): Promise<LocationCoords | null> {
    try {
      // Use platform-specific location services
      const LocationService = Platform.OS === 'web' ? WebLocation : Location;
      
      // Request location permissions
      const { status } = await LocationService.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.log('🚫 LOCATION PERMISSION DENIED - Using fallback');
        return null;
      }

      // Get location with platform-appropriate accuracy
      const location = await LocationService.getCurrentPositionAsync({
        accuracy: Platform.OS === 'web' ? 
          WebLocation.LocationAccuracy.High : 
          Location.Accuracy.BestForNavigation,
        maximumAge: 5000,
      });
      
      console.log('📍 LOCATION ACQUIRED:', {
        platform: Platform.OS,
        lat: location.coords.latitude,
        lon: location.coords.longitude,
      });

      return {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };
    } catch (error) {
      console.error('❌ LOCATION ERROR:', error);
      return null;
    }
  }

  async getWeatherAlerts(coords: LocationCoords): Promise<WeatherAlert[]> {
    try {
      // Use National Weather Service API for US locations
      if (this.isUSLocation(coords)) {
        return await this.getNWSAlerts(coords);
      } else {
        // For international locations, use OpenWeatherMap alerts
        return await this.getOpenWeatherAlerts(coords);
      }
    } catch (error) {
      console.error('Error fetching weather alerts:', error);
      // Only use mock data as last resort - prioritize real NWS data
      if (this.isUSLocation(coords)) {
        try {
          // Retry NWS with simplified request
          const response = await fetch(`${this.NWS_API_BASE}/alerts/active`, {
            headers: { 'User-Agent': this.NWS_USER_AGENT }
          });
          if (response.ok) {
            const data = await response.json();
            return data.features.slice(0, 5).map((alert: any) => ({
              id: alert.id,
              title: alert.properties.event,
              description: alert.properties.description || 'Weather alert in effect',
              severity: alert.properties.severity?.toLowerCase() || 'moderate',
              urgency: alert.properties.urgency?.toLowerCase() || 'expected',
              certainty: 'likely',
              event: alert.properties.event,
              headline: alert.properties.headline || alert.properties.event,
              areas: [alert.properties.areaDesc || 'Affected Area'],
              effective: new Date(alert.properties.effective || new Date()),
              expires: new Date(alert.properties.expires || new Date(Date.now() + 3600000)),
              sender: 'National Weather Service',
              senderName: 'National Weather Service'
            }));
          }
        } catch (retryError) {
          console.log('NWS retry failed, using fallback');
        }
      }
      return this.getMockAlerts(coords);
    }
  }

  private async getNWSAlerts(coords: LocationCoords): Promise<WeatherAlert[]> {
    try {
      // First get the grid point for the coordinates
      const pointResponse = await fetch(
        `${this.NWS_API_BASE}/points/${coords.latitude},${coords.longitude}`,
        {
          headers: {
            'User-Agent': this.NWS_USER_AGENT,
            'Accept': 'application/json',
          },
        }
      );
      
      if (!pointResponse.ok) {
        throw new Error('Failed to get grid point');
      }

      const pointData = await pointResponse.json();
      const gridId = pointData.properties.gridId;
      const gridX = pointData.properties.gridX;
      const gridY = pointData.properties.gridY;

      // Get alerts for the area
      const alertsResponse = await fetch(
        `${this.NWS_API_BASE}/alerts/active?point=${coords.latitude},${coords.longitude}`,
        {
          headers: {
            'User-Agent': this.NWS_USER_AGENT,
            'Accept': 'application/json',
          },
        }
      );

      if (!alertsResponse.ok) {
        throw new Error('Failed to get alerts');
      }

      const alertsData = await alertsResponse.json();
      
      console.log(`🌪️ REAL DATA: Loaded ${alertsData.features.length} alerts from NWS`);
      
      return alertsData.features.map((alert: any) => ({
        id: alert.id,
        title: alert.properties.event,
        description: alert.properties.description || '',
        severity: alert.properties.severity?.toLowerCase() || 'moderate',
        urgency: alert.properties.urgency?.toLowerCase() || 'expected',
        certainty: alert.properties.certainty?.toLowerCase() || 'likely',
        event: alert.properties.event,
        headline: alert.properties.headline || '',
        areas: alert.properties.areaDesc ? [alert.properties.areaDesc] : [],
        effective: new Date(alert.properties.effective),
        expires: new Date(alert.properties.expires),
        sender: alert.properties.senderName || 'National Weather Service',
        senderName: alert.properties.senderName || 'National Weather Service',
        instruction: alert.properties.instruction,
        web: alert.properties.web,
        contact: alert.properties.contact,
        parameters: alert.properties.parameters,
        geometry: alert.geometry,
      }));
    } catch (error) {
      console.error('NWS API error:', error);
      return [];
    }
  }

  private async getOpenWeatherAlerts(coords: LocationCoords): Promise<WeatherAlert[]> {
    try {
      if (!this.OPENWEATHER_API_KEY) {
        console.log('OpenWeather API key not available');
        return [];
      }

      const response = await fetch(
        `https://api.openweathermap.org/data/3.0/onecall?lat=${coords.latitude}&lon=${coords.longitude}&appid=${this.OPENWEATHER_API_KEY}&exclude=minutely,hourly,daily`
      );

      if (!response.ok) {
        throw new Error('Failed to get OpenWeather alerts');
      }

      const data = await response.json();
      
      if (!data.alerts) {
        return [];
      }

      return data.alerts.map((alert: any) => ({
        id: `ow_${Date.now()}_${Math.random()}`,
        title: alert.event,
        description: alert.description || '',
        severity: this.mapOpenWeatherSeverity(alert.tags),
        urgency: 'expected',
        certainty: 'likely',
        event: alert.event,
        headline: alert.event,
        areas: alert.tags || [],
        effective: new Date(alert.start * 1000),
        expires: new Date(alert.end * 1000),
        sender: alert.sender_name || 'Weather Service',
        senderName: alert.sender_name || 'Weather Service',
        instruction: alert.description,
      }));
    } catch (error) {
      console.error('OpenWeather API error:', error);
      return [];
    }
  }

  async getCurrentWeather(coords: LocationCoords): Promise<WeatherCondition | null> {
    try {
      if (!this.OPENWEATHER_API_KEY) {
        console.log('🌡️ OpenWeather API key not available - using NWS for current conditions');
        return await this.getNWSCurrentWeather(coords);
      }

      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?lat=${coords.latitude}&lon=${coords.longitude}&appid=${this.OPENWEATHER_API_KEY}&units=imperial`
      );

      if (!response.ok) {
        throw new Error('Failed to get current weather');
      }

      const data = await response.json();
      
      return {
        temperature: Math.round(data.main.temp),
        humidity: data.main.humidity,
        windSpeed: Math.round(data.wind.speed),
        windDirection: data.wind.deg || 0,
        pressure: data.main.pressure,
        visibility: data.visibility ? Math.round(data.visibility / 1609.34) : 10, // Convert to miles
        condition: data.weather[0].main,
        icon: data.weather[0].icon,
        description: data.weather[0].description,
      };
    } catch (error) {
      console.error('Error getting current weather:', error);
      return null;
    }
  }

  private isUSLocation(coords: LocationCoords): boolean {
    // Rough bounding box for US (including Alaska and Hawaii)
    return (
      coords.latitude >= 18.0 && coords.latitude <= 72.0 &&
      coords.longitude >= -180.0 && coords.longitude <= -66.0
    );
  }

  private mapOpenWeatherSeverity(tags: string[]): 'minor' | 'moderate' | 'severe' | 'extreme' {
    if (!tags) return 'moderate';
    
    const tagString = tags.join(' ').toLowerCase();
    
    if (tagString.includes('extreme') || tagString.includes('hurricane') || tagString.includes('tornado')) {
      return 'extreme';
    } else if (tagString.includes('severe') || tagString.includes('warning')) {
      return 'severe';
    } else if (tagString.includes('watch') || tagString.includes('advisory')) {
      return 'moderate';
    } else {
      return 'minor';
    }
  }

  private getMockAlerts(coords: LocationCoords): WeatherAlert[] {
    // Return mock alerts for demo purposes
    console.log('⚠️ FALLING BACK TO MOCK DATA - Real APIs failed');
    const now = new Date();
    const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    
    return [
      {
        id: 'mock_1',
        title: 'Severe Thunderstorm Warning',
        description: 'A severe thunderstorm warning is in effect for your area. Damaging winds up to 70 mph and quarter-size hail are possible. Seek shelter immediately.',
        severity: 'severe',
        urgency: 'immediate',
        certainty: 'observed',
        event: 'Severe Thunderstorm Warning',
        headline: 'Severe Thunderstorm Warning in effect until 9:00 PM',
        areas: ['Your Location Area'],
        effective: new Date(now.getTime() - 30 * 60 * 1000), // 30 minutes ago
        expires: new Date(now.getTime() + 2 * 60 * 60 * 1000), // 2 hours from now
        sender: 'National Weather Service',
        senderName: 'National Weather Service',
        instruction: 'Move to an interior room on the lowest floor of a sturdy building. Avoid windows.',
      },
      {
        id: 'mock_2',
        title: 'Tornado Watch',
        description: 'Conditions are favorable for tornado development. Be prepared to take shelter if a tornado warning is issued.',
        severity: 'severe',
        urgency: 'expected',
        certainty: 'likely',
        event: 'Tornado Watch',
        headline: 'Tornado Watch in effect until midnight',
        areas: ['Your Location Area', 'Surrounding Counties'],
        effective: now,
        expires: tomorrow,
        sender: 'Storm Prediction Center',
        senderName: 'Storm Prediction Center',
        instruction: 'Stay weather aware and be prepared to take action if warnings are issued.',
      }
    ];
  }

  getSeverityColor(severity: string): string {
    switch (severity) {
      case 'extreme':
        return '#8B0000'; // Dark red
      case 'severe':
        return '#FF4500'; // Orange red
      case 'moderate':
        return '#FFA500'; // Orange
      case 'minor':
        return '#FFFF00'; // Yellow
      default:
        return '#87CEEB'; // Sky blue
    }
  }

  private async getNWSCurrentWeather(coords: LocationCoords): Promise<WeatherCondition | null> {
    try {
      // Get grid point for detailed forecast
      const pointResponse = await fetch(
        `${this.NWS_API_BASE}/points/${coords.latitude},${coords.longitude}`,
        { headers: { 'User-Agent': this.NWS_USER_AGENT } }
      );
      
      if (!pointResponse.ok) return null;
      
      const pointData = await pointResponse.json();
      const forecastUrl = pointData.properties.forecast;
      
      // Get current conditions from forecast
      const forecastResponse = await fetch(forecastUrl, {
        headers: { 'User-Agent': this.NWS_USER_AGENT }
      });
      
      if (!forecastResponse.ok) return null;
      
      const forecastData = await forecastResponse.json();
      const currentPeriod = forecastData.properties.periods[0];
      
      return {
        temperature: currentPeriod.temperature || 70,
        humidity: 60, // NWS doesn't provide humidity in basic forecast
        windSpeed: parseInt(currentPeriod.windSpeed) || 0,
        windDirection: this.windDirectionToDegrees(currentPeriod.windDirection) || 0,
        pressure: 1013, // Default atmospheric pressure
        visibility: 10, // Default visibility
        condition: currentPeriod.shortForecast || 'Clear',
        icon: '☀️',
        description: currentPeriod.detailedForecast || 'Current conditions',
      };
    } catch (error) {
      console.error('NWS current weather error:', error);
      return null;
    }
  }

  private windDirectionToDegrees(direction: string): number {
    const directions: { [key: string]: number } = {
      'N': 0, 'NNE': 22.5, 'NE': 45, 'ENE': 67.5,
      'E': 90, 'ESE': 112.5, 'SE': 135, 'SSE': 157.5,
      'S': 180, 'SSW': 202.5, 'SW': 225, 'WSW': 247.5,
      'W': 270, 'WNW': 292.5, 'NW': 315, 'NNW': 337.5
    };
    return directions[direction] || 0;
  }

  getSeverityIcon(event: string): string {
    const eventLower = event.toLowerCase();
    
    if (eventLower.includes('tornado')) return '🌪️';
    if (eventLower.includes('hurricane')) return '🌀';
    if (eventLower.includes('thunderstorm') || eventLower.includes('storm')) return '⛈️';
    if (eventLower.includes('flood')) return '🌊';
    if (eventLower.includes('snow') || eventLower.includes('blizzard')) return '❄️';
    if (eventLower.includes('ice')) return '🧊';
    if (eventLower.includes('wind')) return '💨';
    if (eventLower.includes('heat')) return '🔥';
    if (eventLower.includes('fog')) return '🌫️';
    
    return '⚠️';
  }
}

export const weatherAlertsService = new WeatherAlertsService();