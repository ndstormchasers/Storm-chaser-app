export interface SocialAccount {
  platform: 'instagram' | 'tiktok' | 'twitter' | 'facebook' | 'youtube' | 'snapchat';
  username: string;
  displayName: string;
  profileUrl: string;
  avatar: string;
  followers: number;
  verified: boolean;
  connected: boolean;
  lastSync: Date;
  autoPost: boolean;
  permissions: string[];
}

export interface CrossPostContent {
  id: string;
  originalContent: {
    type: 'photo' | 'video' | 'story' | 'reel' | 'post';
    url: string;
    caption: string;
    hashtags: string[];
    location?: string;
    timestamp: Date;
  };
  platforms: Array<{
    platform: string;
    status: 'pending' | 'posted' | 'failed';
    platformPostId?: string;
    customCaption?: string;
    customHashtags?: string[];
    error?: string;
    postedAt?: Date;
    engagement?: {
      likes: number;
      comments: number;
      shares: number;
      views: number;
    };
  }>;
  totalReach: number;
  totalEngagement: number;
}

export interface StormPhotoContest {
  id: string;
  title: string;
  description: string;
  theme: string;
  startDate: Date;
  endDate: Date;
  submissionDeadline: Date;
  votingPeriod: { start: Date; end: Date };
  categories: ContestCategory[];
  prizes: ContestPrize[];
  rules: string[];
  judges: Judge[];
  submissions: ContestSubmission[];
  status: 'upcoming' | 'active' | 'voting' | 'judging' | 'completed';
  featured: boolean;
  sponsors: string[];
}

export interface ContestCategory {
  id: string;
  name: string;
  description: string;
  criteria: string[];
  maxSubmissions: number;
  submissions: number;
}

export interface ContestPrize {
  rank: number;
  title: string;
  description: string;
  value: number;
  sponsor?: string;
  image?: string;
}

export interface Judge {
  id: string;
  name: string;
  credentials: string[];
  avatar: string;
  specialties: string[];
}

export interface ContestSubmission {
  id: string;
  contestId: string;
  categoryId: string;
  userId: string;
  username: string;
  title: string;
  description: string;
  imageUrl: string;
  metadata: {
    location: string;
    date: Date;
    equipment: string;
    settings: string;
    stormType: string;
  };
  submittedAt: Date;
  votes: number;
  judgeScores: Array<{
    judgeId: string;
    score: number;
    feedback: string;
  }>;
  publicVotes: number;
  finalist: boolean;
  winner: boolean;
  rank?: number;
  tags: string[];
}

export interface CommunityChallenge {
  id: string;
  title: string;
  description: string;
  type: 'photo' | 'video' | 'documentation' | 'education' | 'safety' | 'prediction';
  difficulty: 'easy' | 'medium' | 'hard' | 'expert';
  duration: number; // days
  startDate: Date;
  endDate: Date;
  objectives: string[];
  requirements: string[];
  rewards: {
    points: number;
    badges: string[];
    recognition: string;
    prizes?: string[];
  };
  participants: ChallengeParticipant[];
  leaderboard: ChallengeLeaderboard[];
  hashtags: string[];
  featured: boolean;
  seasonal: boolean;
}

export interface ChallengeParticipant {
  userId: string;
  username: string;
  avatar: string;
  joinedAt: Date;
  progress: number; // 0-1
  submissions: ChallengeSubmission[];
  score: number;
  rank: number;
  completed: boolean;
}

export interface ChallengeSubmission {
  id: string;
  challengeId: string;
  userId: string;
  type: 'photo' | 'video' | 'text' | 'data';
  content: string; // URL or text
  caption: string;
  location?: string;
  timestamp: Date;
  verified: boolean;
  points: number;
  likes: number;
  comments: StormComment[];
}

export interface ChallengeLeaderboard {
  rank: number;
  userId: string;
  username: string;
  avatar: string;
  score: number;
  submissions: number;
  badges: string[];
  trend: 'up' | 'down' | 'same';
}

export interface StormPost {
  id: string;
  userId: string;
  username: string;
  avatar: string;
  type: 'photo' | 'video' | 'text' | 'live_update' | 'forecast' | 'alert';
  content: {
    text?: string;
    mediaUrl?: string;
    location?: {
      name: string;
      coordinates: { latitude: number; longitude: number };
    };
    stormData?: {
      type: string;
      intensity: string;
      movement: string;
      threats: string[];
    };
    equipment?: string[];
    settings?: string;
  };
  timestamp: Date;
  edited: boolean;
  editedAt?: Date;
  visibility: 'public' | 'followers' | 'private';
  hashtags: string[];
  mentions: string[];
  engagement: {
    likes: number;
    comments: number;
    shares: number;
    saves: number;
    views: number;
  };
  comments: StormComment[];
  location: string;
  featured: boolean;
  verified: boolean;
  reportCount: number;
  status: 'active' | 'flagged' | 'removed';
}

export interface StormComment {
  id: string;
  postId: string;
  userId: string;
  username: string;
  avatar: string;
  text: string;
  timestamp: Date;
  edited: boolean;
  likes: number;
  replies: StormComment[];
  parentId?: string;
  verified: boolean;
  reportCount: number;
}

export interface SocialMediaStats {
  platform: string;
  followers: number;
  following: number;
  posts: number;
  engagement: {
    rate: number;
    averageLikes: number;
    averageComments: number;
    averageShares: number;
  };
  reach: {
    impressions: number;
    uniqueUsers: number;
    countries: number;
  };
  growth: {
    followers: { daily: number; weekly: number; monthly: number };
    engagement: { trend: 'up' | 'down' | 'stable'; percentage: number };
  };
  topPosts: Array<{
    id: string;
    type: string;
    engagement: number;
    reach: number;
    timestamp: Date;
  }>;
}

export interface InfluencerMetrics {
  userId: string;
  overallScore: number; // 0-100
  categories: {
    reach: { score: number; rank: string };
    engagement: { score: number; rank: string };
    authenticity: { score: number; rank: string };
    expertise: { score: number; rank: string };
  };
  audience: {
    demographics: any;
    interests: string[];
    location: any;
    authenticity: number; // percentage of real followers
  };
  brandSafety: {
    score: number;
    issues: string[];
    recommendations: string[];
  };
  trending: {
    hashtags: string[];
    topics: string[];
    collaborations: string[];
  };
}

class SocialIntegrationService {
  private connectedAccounts: Map<string, SocialAccount[]> = new Map();
  private crossPostQueue: CrossPostContent[] = [];

  // Account Management
  async connectSocialAccount(userId: string, platform: string, authToken: string): Promise<boolean> {
    try {
      // Mock social account connection
      const account: SocialAccount = {
        platform: platform as any,
        username: `user_${platform}`,
        displayName: `User on ${platform}`,
        profileUrl: `https://${platform}.com/user_${platform}`,
        avatar: '📱',
        followers: Math.floor(Math.random() * 10000),
        verified: Math.random() > 0.8,
        connected: true,
        lastSync: new Date(),
        autoPost: false,
        permissions: ['read', 'write', 'publish'],
      };

      const userAccounts = this.connectedAccounts.get(userId) || [];
      userAccounts.push(account);
      this.connectedAccounts.set(userId, userAccounts);

      console.log(`Connected ${platform} account for user ${userId}`);
      return true;
    } catch (error) {
      console.error('Error connecting social account:', error);
      return false;
    }
  }

  async disconnectSocialAccount(userId: string, platform: string): Promise<boolean> {
    try {
      const userAccounts = this.connectedAccounts.get(userId) || [];
      const updatedAccounts = userAccounts.filter(acc => acc.platform !== platform);
      this.connectedAccounts.set(userId, updatedAccounts);

      console.log(`Disconnected ${platform} account for user ${userId}`);
      return true;
    } catch (error) {
      console.error('Error disconnecting social account:', error);
      return false;
    }
  }

  // Cross-Platform Posting
  async schedulePost(userId: string, content: any, platforms: string[], scheduledTime?: Date): Promise<string> {
    try {
      const crossPost: CrossPostContent = {
        id: `cross_post_${Date.now()}`,
        originalContent: {
          type: content.type,
          url: content.url,
          caption: content.caption,
          hashtags: content.hashtags || [],
          location: content.location,
          timestamp: scheduledTime || new Date(),
        },
        platforms: platforms.map(platform => ({
          platform,
          status: 'pending',
        })),
        totalReach: 0,
        totalEngagement: 0,
      };

      this.crossPostQueue.push(crossPost);
      
      if (!scheduledTime) {
        await this.executeCrossPost(crossPost);
      }

      return crossPost.id;
    } catch (error) {
      console.error('Error scheduling post:', error);
      throw error;
    }
  }

  async autoHashtagSuggestions(content: string, imageAnalysis?: any): Promise<string[]> {
    try {
      // AI-powered hashtag suggestions based on content
      const baseHashtags = ['#StormChasing', '#SevereWeather', '#Photography'];
      
      // Analyze content for specific weather phenomena
      const weatherTerms = {
        tornado: ['#Tornado', '#TornadoAlley', '#Twister'],
        lightning: ['#Lightning', '#Thunderstorm', '#NaturePhotography'],
        hail: ['#Hail', '#Hailstorm', '#SevereWeather'],
        supercell: ['#Supercell', '#Mesocyclone', '#StormStructure'],
        rainbow: ['#Rainbow', '#StormChasing', '#NaturePhotography'],
      };

      let suggestions = [...baseHashtags];
      
      Object.entries(weatherTerms).forEach(([term, hashtags]) => {
        if (content.toLowerCase().includes(term)) {
          suggestions.push(...hashtags);
        }
      });

      // Add location-based hashtags if available
      if (imageAnalysis?.location) {
        suggestions.push(`#${imageAnalysis.location.replace(/\s+/g, '')}`);
      }

      // Remove duplicates and limit to top 10
      return [...new Set(suggestions)].slice(0, 10);
    } catch (error) {
      console.error('Error generating hashtag suggestions:', error);
      return ['#StormChasing', '#SevereWeather'];
    }
  }

  // Community Features
  async createPhotoContest(contest: Omit<StormPhotoContest, 'id' | 'submissions' | 'status'>): Promise<string> {
    try {
      const newContest: StormPhotoContest = {
        ...contest,
        id: `contest_${Date.now()}`,
        submissions: [],
        status: 'upcoming',
      };

      console.log(`Created photo contest: ${newContest.title}`);
      return newContest.id;
    } catch (error) {
      console.error('Error creating photo contest:', error);
      throw error;
    }
  }

  async submitToContest(contestId: string, userId: string, submission: Omit<ContestSubmission, 'id' | 'submittedAt' | 'votes' | 'judgeScores' | 'publicVotes' | 'finalist' | 'winner'>): Promise<boolean> {
    try {
      const newSubmission: ContestSubmission = {
        ...submission,
        id: `submission_${Date.now()}`,
        submittedAt: new Date(),
        votes: 0,
        judgeScores: [],
        publicVotes: 0,
        finalist: false,
        winner: false,
      };

      console.log(`User ${userId} submitted to contest ${contestId}`);
      return true;
    } catch (error) {
      console.error('Error submitting to contest:', error);
      return false;
    }
  }

  async createCommunityChallenge(challenge: Omit<CommunityChallenge, 'id' | 'participants' | 'leaderboard'>): Promise<string> {
    try {
      const newChallenge: CommunityChallenge = {
        ...challenge,
        id: `challenge_${Date.now()}`,
        participants: [],
        leaderboard: [],
      };

      console.log(`Created community challenge: ${newChallenge.title}`);
      return newChallenge.id;
    } catch (error) {
      console.error('Error creating community challenge:', error);
      throw error;
    }
  }

  async joinChallenge(challengeId: string, userId: string): Promise<boolean> {
    try {
      console.log(`User ${userId} joined challenge ${challengeId}`);
      return true;
    } catch (error) {
      console.error('Error joining challenge:', error);
      return false;
    }
  }

  // Social Feed
  async createStormPost(userId: string, post: Omit<StormPost, 'id' | 'timestamp' | 'engagement' | 'comments' | 'featured' | 'verified' | 'reportCount' | 'status'>): Promise<string> {
    try {
      const newPost: StormPost = {
        ...post,
        id: `post_${Date.now()}`,
        timestamp: new Date(),
        engagement: {
          likes: 0,
          comments: 0,
          shares: 0,
          saves: 0,
          views: 0,
        },
        comments: [],
        featured: false,
        verified: false,
        reportCount: 0,
        status: 'active',
      };

      console.log(`Created storm post by user ${userId}`);
      return newPost.id;
    } catch (error) {
      console.error('Error creating storm post:', error);
      throw error;
    }
  }

  async getStormFeed(userId: string, filters?: { type?: string; location?: string; timeframe?: string }): Promise<StormPost[]> {
    try {
      // Mock storm feed with engaging content
      const mockPosts: StormPost[] = [
        {
          id: 'post_1',
          userId: 'user_123',
          username: 'TornadoHunter',
          avatar: '🌪️',
          type: 'photo',
          content: {
            text: 'Incredible supercell structure developing near Moore, OK! Watch for possible tornadogenesis.',
            mediaUrl: 'https://example.com/supercell.jpg',
            location: {
              name: 'Moore, Oklahoma',
              coordinates: { latitude: 35.3395, longitude: -97.4867 },
            },
            stormData: {
              type: 'Supercell',
              intensity: 'Severe',
              movement: 'Northeast at 25 mph',
              threats: ['Large hail', 'Damaging winds', 'Tornado possible'],
            },
            equipment: ['Canon EOS R5', 'RF 24-105mm f/4L'],
            settings: 'f/8, 1/250s, ISO 400',
          },
          timestamp: new Date(Date.now() - 30 * 60 * 1000),
          edited: false,
          visibility: 'public',
          hashtags: ['#Supercell', '#StormChasing', '#Oklahoma', '#Tornado'],
          mentions: ['@NationalWeatherService'],
          engagement: {
            likes: 245,
            comments: 32,
            shares: 18,
            saves: 67,
            views: 1250,
          },
          comments: [],
          location: 'Moore, Oklahoma',
          featured: true,
          verified: true,
          reportCount: 0,
          status: 'active',
        },
        {
          id: 'post_2',
          userId: 'user_456',
          username: 'StormSpotter_Pro',
          avatar: '⛈️',
          type: 'live_update',
          content: {
            text: 'LIVE UPDATE: Tornado on the ground 3 miles SW of Dodge City! Take shelter immediately if in the area!',
            location: {
              name: 'Dodge City, Kansas',
              coordinates: { latitude: 37.7528, longitude: -100.0171 },
            },
            stormData: {
              type: 'Tornado',
              intensity: 'EF2 estimated',
              movement: 'Northeast at 35 mph',
              threats: ['Tornado', 'Life-threatening situation'],
            },
          },
          timestamp: new Date(Date.now() - 5 * 60 * 1000),
          edited: false,
          visibility: 'public',
          hashtags: ['#TornadoWarning', '#DodgeCity', '#KansasWeather', '#TakeAction'],
          mentions: ['@NWSGoodland'],
          engagement: {
            likes: 89,
            comments: 45,
            shares: 156,
            saves: 23,
            views: 2340,
          },
          comments: [],
          location: 'Dodge City, Kansas',
          featured: true,
          verified: true,
          reportCount: 0,
          status: 'active',
        },
      ];

      return mockPosts;
    } catch (error) {
      console.error('Error getting storm feed:', error);
      return [];
    }
  }

  // Analytics
  async getSocialMediaStats(userId: string, platform?: string): Promise<SocialMediaStats[]> {
    try {
      const mockStats: SocialMediaStats[] = [
        {
          platform: 'Instagram',
          followers: 15420,
          following: 892,
          posts: 234,
          engagement: {
            rate: 0.067,
            averageLikes: 892,
            averageComments: 45,
            averageShares: 23,
          },
          reach: {
            impressions: 125000,
            uniqueUsers: 89000,
            countries: 23,
          },
          growth: {
            followers: { daily: 12, weekly: 89, monthly: 340 },
            engagement: { trend: 'up', percentage: 0.15 },
          },
          topPosts: [
            {
              id: 'ig_post_1',
              type: 'photo',
              engagement: 1250,
              reach: 5600,
              timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
            },
          ],
        },
      ];

      return platform ? mockStats.filter(s => s.platform.toLowerCase() === platform.toLowerCase()) : mockStats;
    } catch (error) {
      console.error('Error getting social media stats:', error);
      return [];
    }
  }

  async getInfluencerMetrics(userId: string): Promise<InfluencerMetrics> {
    try {
      return {
        userId,
        overallScore: 87,
        categories: {
          reach: { score: 85, rank: 'Excellent' },
          engagement: { score: 92, rank: 'Outstanding' },
          authenticity: { score: 89, rank: 'Excellent' },
          expertise: { score: 94, rank: 'Expert' },
        },
        audience: {
          demographics: {
            age: { '18-24': 0.15, '25-34': 0.35, '35-44': 0.28, '45+': 0.22 },
            gender: { 'male': 0.68, 'female': 0.32 },
            location: { 'USA': 0.78, 'Canada': 0.12, 'Other': 0.10 },
          },
          interests: ['Weather', 'Photography', 'Science', 'Adventure', 'Nature'],
          location: { 'North America': 0.9, 'Europe': 0.08, 'Other': 0.02 },
          authenticity: 0.94,
        },
        brandSafety: {
          score: 96,
          issues: [],
          recommendations: ['Maintain current content quality', 'Continue educational focus'],
        },
        trending: {
          hashtags: ['#StormChasing', '#SevereWeather', '#TornadoAlley'],
          topics: ['Storm Photography', 'Weather Safety', 'Climate Science'],
          collaborations: ['@NationalWeatherService', '@StormChasers'],
        },
      };
    } catch (error) {
      console.error('Error getting influencer metrics:', error);
      throw error;
    }
  }

  // Helper methods
  private async executeCrossPost(crossPost: CrossPostContent): Promise<void> {
    try {
      for (const platformPost of crossPost.platforms) {
        try {
          // Mock platform posting
          await this.postToPlatform(platformPost.platform, crossPost.originalContent);
          platformPost.status = 'posted';
          platformPost.platformPostId = `${platformPost.platform}_${Date.now()}`;
          platformPost.postedAt = new Date();
        } catch (error) {
          platformPost.status = 'failed';
          platformPost.error = error instanceof Error ? error.message : 'Unknown error';
        }
      }
    } catch (error) {
      console.error('Error executing cross post:', error);
    }
  }

  private async postToPlatform(platform: string, content: any): Promise<void> {
    // Mock platform-specific posting logic
    console.log(`Posting to ${platform}:`, content.caption);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Simulate occasional failures
    if (Math.random() < 0.05) {
      throw new Error(`Failed to post to ${platform}`);
    }
  }

  // Contest management
  async getActiveContests(): Promise<StormPhotoContest[]> {
    try {
      // Mock active contests
      return [
        {
          id: 'contest_2024_spring',
          title: '2024 Spring Storm Season Contest',
          description: 'Capture the beauty and power of spring storms',
          theme: 'Spring Storms',
          startDate: new Date('2024-03-01'),
          endDate: new Date('2024-05-31'),
          submissionDeadline: new Date('2024-05-31'),
          votingPeriod: {
            start: new Date('2024-06-01'),
            end: new Date('2024-06-15'),
          },
          categories: [
            {
              id: 'tornado',
              name: 'Tornado Photography',
              description: 'Best tornado documentation',
              criteria: ['Safety', 'Composition', 'Technical quality'],
              maxSubmissions: 3,
              submissions: 45,
            },
            {
              id: 'lightning',
              name: 'Lightning Photography',
              description: 'Most striking lightning captures',
              criteria: ['Timing', 'Composition', 'Technical quality'],
              maxSubmissions: 5,
              submissions: 78,
            },
          ],
          prizes: [
            {
              rank: 1,
              title: 'Grand Prize',
              description: 'Professional storm chasing equipment package',
              value: 5000,
              sponsor: 'StormGear Pro',
            },
            {
              rank: 2,
              title: 'Second Place',
              description: 'Advanced weather station',
              value: 2500,
              sponsor: 'WeatherTech',
            },
          ],
          rules: [
            'Images must be taken during contest period',
            'Original work only',
            'Safety first - no dangerous positioning',
          ],
          judges: [
            {
              id: 'judge_1',
              name: 'Dr. Storm Expert',
              credentials: ['PhD Meteorology', 'Award-winning photographer'],
              avatar: '🌪️',
              specialties: ['Storm dynamics', 'Photography'],
            },
          ],
          submissions: [],
          status: 'active',
          featured: true,
          sponsors: ['StormGear Pro', 'WeatherTech', 'ChaseMax'],
        },
      ];
    } catch (error) {
      console.error('Error getting active contests:', error);
      return [];
    }
  }
}

export const socialIntegrationService = new SocialIntegrationService();