// YouTube Live Streaming API Integration
interface YouTubeLiveStreamResponse {
  id: string;
  snippet: {
    title: string;
    description: string;
    publishedAt: string;
  };
  status: {
    lifeCycleStatus: string;
    privacyStatus: string;
  };
  cdn: {
    ingestionInfo: {
      streamName: string;
      ingestionAddress: string;
    };
  };
}

interface TwitchStreamResponse {
  data: Array<{
    id: string;
    user_id: string;
    user_login: string;
    user_name: string;
    game_id: string;
    game_name: string;
    type: string;
    title: string;
    viewer_count: number;
    started_at: string;
    language: string;
    thumbnail_url: string;
  }>;
}

export interface StreamPlatform {
  id: 'youtube' | 'twitch';
  name: string;
  color: string;
  icon: string;
  requiresAuth: boolean;
}

export const STREAMING_PLATFORMS: StreamPlatform[] = [
  {
    id: 'youtube',
    name: 'YouTube Live',
    color: '#FF0000',
    icon: '📺',
    requiresAuth: true,
  },
  {
    id: 'twitch',
    name: 'Twitch',
    color: '#9146FF',
    icon: '🎮',
    requiresAuth: true,
  },
];

// YouTube Live API functions
export class YouTubeStreamingService {
  private apiKey: string;
  private accessToken?: string;

  constructor() {
    this.apiKey = process.env.EXPO_PUBLIC_VIBECODE_YOUTUBE_API_KEY || '';
  }

  setAccessToken(token: string) {
    this.accessToken = token;
  }

  async createLiveStream(title: string, description: string): Promise<YouTubeLiveStreamResponse | null> {
    try {
      if (!this.accessToken) {
        throw new Error('YouTube access token required');
      }

      // Create live broadcast
      const broadcastResponse = await fetch(
        'https://www.googleapis.com/youtube/v3/liveBroadcasts?part=snippet,status&key=' + this.apiKey,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.accessToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            snippet: {
              title,
              description,
              scheduledStartTime: new Date().toISOString(),
            },
            status: {
              privacyStatus: 'public',
              selfDeclaredMadeForKids: false,
            },
          }),
        }
      );

      if (!broadcastResponse.ok) {
        console.error('YouTube broadcast creation failed:', await broadcastResponse.text());
        return null;
      }

      const broadcast = await broadcastResponse.json();

      // Create live stream
      const streamResponse = await fetch(
        'https://www.googleapis.com/youtube/v3/liveStreams?part=snippet,cdn&key=' + this.apiKey,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.accessToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            snippet: {
              title: title + ' - Stream',
            },
            cdn: {
              frameRate: '30fps',
              resolution: '720p',
              ingestionType: 'rtmp',
            },
          }),
        }
      );

      if (!streamResponse.ok) {
        console.error('YouTube stream creation failed:', await streamResponse.text());
        return null;
      }

      const stream = await streamResponse.json();

      // Bind broadcast to stream
      await fetch(
        `https://www.googleapis.com/youtube/v3/liveBroadcasts/bind?id=${broadcast.id}&streamId=${stream.id}&part=id&key=${this.apiKey}`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.accessToken}`,
          },
        }
      );

      return {
        ...broadcast,
        cdn: stream.cdn,
      };
    } catch (error) {
      console.error('YouTube streaming error:', error);
      return null;
    }
  }

  async endLiveStream(broadcastId: string): Promise<boolean> {
    try {
      if (!this.accessToken) return false;

      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/liveBroadcasts?id=${broadcastId}&part=status&key=${this.apiKey}`,
        {
          method: 'PUT',
          headers: {
            'Authorization': `Bearer ${this.accessToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            id: broadcastId,
            status: {
              lifeCycleStatus: 'complete',
            },
          }),
        }
      );

      return response.ok;
    } catch (error) {
      console.error('YouTube end stream error:', error);
      return false;
    }
  }
}

// Twitch API functions
export class TwitchStreamingService {
  private clientId: string;
  private clientSecret: string;
  private accessToken?: string;

  constructor() {
    this.clientId = process.env.EXPO_PUBLIC_VIBECODE_TWITCH_CLIENT_ID || '';
    this.clientSecret = process.env.EXPO_PUBLIC_VIBECODE_TWITCH_CLIENT_SECRET || '';
  }

  setAccessToken(token: string) {
    this.accessToken = token;
  }

  async getStreamKey(userId: string): Promise<string | null> {
    try {
      if (!this.accessToken) {
        throw new Error('Twitch access token required');
      }

      const response = await fetch(
        `https://api.twitch.tv/helix/streams/key?broadcaster_id=${userId}`,
        {
          headers: {
            'Authorization': `Bearer ${this.accessToken}`,
            'Client-Id': this.clientId,
          },
        }
      );

      if (!response.ok) {
        console.error('Twitch stream key fetch failed:', await response.text());
        return null;
      }

      const data = await response.json();
      return data.data[0]?.stream_key || null;
    } catch (error) {
      console.error('Twitch stream key error:', error);
      return null;
    }
  }

  async updateStreamInfo(userId: string, title: string, categoryId?: string): Promise<boolean> {
    try {
      if (!this.accessToken) return false;

      const body: any = { title };
      if (categoryId) body.game_id = categoryId;

      const response = await fetch(
        `https://api.twitch.tv/helix/channels?broadcaster_id=${userId}`,
        {
          method: 'PATCH',
          headers: {
            'Authorization': `Bearer ${this.accessToken}`,
            'Client-Id': this.clientId,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(body),
        }
      );

      return response.ok;
    } catch (error) {
      console.error('Twitch update stream info error:', error);
      return false;
    }
  }

  async getStreamInfo(userId: string): Promise<TwitchStreamResponse['data'][0] | null> {
    try {
      if (!this.accessToken) return null;

      const response = await fetch(
        `https://api.twitch.tv/helix/streams?user_id=${userId}`,
        {
          headers: {
            'Authorization': `Bearer ${this.accessToken}`,
            'Client-Id': this.clientId,
          },
        }
      );

      if (!response.ok) return null;

      const data: TwitchStreamResponse = await response.json();
      return data.data[0] || null;
    } catch (error) {
      console.error('Twitch get stream info error:', error);
      return null;
    }
  }
}

// Mock implementations for demo purposes
export class MockStreamingService {
  async createMockStream(platform: 'youtube' | 'twitch', title: string, description: string) {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const streamKey = Math.random().toString(36).substring(7);
    const streamUrl = platform === 'youtube' 
      ? 'rtmp://a.rtmp.youtube.com/live2/'
      : 'rtmp://live.twitch.tv/live/';
      
    return {
      success: true,
      streamKey,
      streamUrl: streamUrl + streamKey,
      broadcastId: 'mock_' + Date.now(),
      platform,
      instructions: platform === 'youtube' 
        ? 'Use OBS or similar software to stream to the provided RTMP URL with your stream key.'
        : 'Configure your streaming software with the Twitch RTMP server and your stream key.',
    };
  }
}

export const youtubeService = new YouTubeStreamingService();
export const twitchService = new TwitchStreamingService();
export const mockService = new MockStreamingService();