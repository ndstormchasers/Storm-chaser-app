export interface ImageAnalysisResult {
  id: string;
  imageUrl: string;
  timestamp: Date;
  confidence: number;
  processing_time: number; // seconds
  weather_classification: WeatherClassification;
  storm_features: StormFeature[];
  safety_assessment: SafetyAssessment;
  technical_analysis: TechnicalAnalysis;
  composition_score: CompositionScore;
  metadata: ImageMetadata;
  tags: string[];
  similar_events: SimilarEvent[];
}

export interface WeatherClassification {
  primary_type: 'clear' | 'partly_cloudy' | 'overcast' | 'rain' | 'thunderstorm' | 'tornado' | 'hail' | 'snow' | 'fog';
  confidence: number;
  secondary_types: Array<{ type: string; confidence: number }>;
  severity: 'none' | 'light' | 'moderate' | 'severe' | 'extreme';
  phenomena: WeatherPhenomena[];
}

export interface WeatherPhenomena {
  type: 'tornado' | 'funnel_cloud' | 'wall_cloud' | 'supercell' | 'mammatus' | 'shelf_cloud' | 'lightning' | 'hail' | 'rainbow' | 'virga';
  confidence: number;
  location: { x: number; y: number; width: number; height: number }; // Bounding box in image
  characteristics: string[];
  severity_indicators: string[];
}

export interface StormFeature {
  feature_type: 'rotation' | 'updraft' | 'downdraft' | 'inflow' | 'precipitation_core' | 'anvil' | 'flanking_line';
  confidence: number;
  location: { x: number; y: number; width: number; height: number };
  strength: 'weak' | 'moderate' | 'strong' | 'violent';
  movement_direction: number; // degrees
  characteristics: {
    [key: string]: any;
  };
}

export interface SafetyAssessment {
  danger_level: 'safe' | 'caution' | 'dangerous' | 'life_threatening';
  immediate_threats: string[];
  recommended_actions: string[];
  safe_distance: number; // meters
  escape_routes: string[];
  time_to_impact: number; // minutes, -1 if not applicable
  warning_signs: string[];
}

export interface TechnicalAnalysis {
  camera_settings: {
    estimated_focal_length: number;
    estimated_aperture: string;
    estimated_iso: number;
    estimated_shutter_speed: string;
  };
  image_quality: {
    sharpness: number; // 0-1
    exposure: number; // -2 to +2
    contrast: number; // 0-1
    saturation: number; // 0-1
    noise_level: number; // 0-1
  };
  atmospheric_conditions: {
    visibility: number; // km
    estimated_wind_speed: number; // km/h
    precipitation_intensity: number; // 0-1
    lighting_conditions: 'dawn' | 'morning' | 'midday' | 'afternoon' | 'dusk' | 'night';
  };
}

export interface CompositionScore {
  overall_score: number; // 0-100
  elements: {
    rule_of_thirds: number;
    leading_lines: number;
    foreground_interest: number;
    depth_of_field: number;
    framing: number;
    symmetry: number;
    color_harmony: number;
  };
  improvements: string[];
  strengths: string[];
}

export interface ImageMetadata {
  original_size: { width: number; height: number };
  file_size: number; // bytes
  format: string;
  location?: {
    latitude: number;
    longitude: number;
    accuracy: number;
    address?: string;
  };
  timestamp: Date;
  device_info?: {
    make: string;
    model: string;
    software: string;
  };
  weather_data?: {
    temperature: number;
    humidity: number;
    pressure: number;
    wind_speed: number;
    wind_direction: number;
  };
}

export interface SimilarEvent {
  event_id: string;
  similarity_score: number;
  event_type: string;
  location: string;
  date: Date;
  image_url: string;
  description: string;
  outcome: string;
  lessons_learned: string[];
}

export interface CloudClassification {
  cloud_types: Array<{
    type: 'cumulus' | 'stratus' | 'cirrus' | 'cumulonimbus' | 'nimbostratus' | 'altocumulus' | 'altostratus' | 'cirrostratus' | 'cirrocumulus' | 'stratocumulus';
    confidence: number;
    coverage: number; // 0-1
    altitude: 'low' | 'middle' | 'high';
    characteristics: string[];
  }>;
  cloud_coverage: number; // 0-1
  precipitation_probability: number; // 0-1
  development_stage: 'building' | 'mature' | 'dissipating';
}

export interface TornadoAnalysis {
  tornado_present: boolean;
  confidence: number;
  ef_scale_estimate: 'EF0' | 'EF1' | 'EF2' | 'EF3' | 'EF4' | 'EF5' | 'Unknown';
  characteristics: {
    funnel_visible: boolean;
    debris_cloud: boolean;
    condensation_funnel: boolean;
    width_estimate: number; // meters
    height_estimate: number; // meters
  };
  damage_indicators: string[];
  path_analysis: {
    direction: number; // degrees
    estimated_speed: number; // km/h
    path_width: number; // meters
  };
  safety_zone: {
    recommended_distance: number; // meters
    safe_directions: number[]; // degrees
  };
}

export interface LightningAnalysis {
  lightning_detected: boolean;
  lightning_types: Array<{
    type: 'cloud_to_ground' | 'cloud_to_cloud' | 'intracloud' | 'positive' | 'negative';
    count: number;
    intensity: 'weak' | 'moderate' | 'strong' | 'extreme';
  }>;
  strike_frequency: number; // strikes per minute
  danger_assessment: {
    immediate_threat: boolean;
    safe_distance: number; // meters
    time_between_strikes: number; // seconds
  };
  photographic_tips: string[];
}

export interface EducationalInsights {
  meteorological_explanation: string;
  formation_process: string[];
  scientific_interest: string[];
  historical_context: string;
  learning_points: string[];
  related_phenomena: string[];
  safety_lessons: string[];
  photography_tips: string[];
}

class ImageRecognitionService {
  private readonly OPENAI_API_KEY = process.env.EXPO_PUBLIC_VIBECODE_OPENAI_API_KEY;
  private readonly ANTHROPIC_API_KEY = process.env.EXPO_PUBLIC_VIBECODE_ANTHROPIC_API_KEY;

  async analyzeWeatherImage(imageUrl: string, options?: {
    detailed_analysis?: boolean;
    safety_focus?: boolean;
    educational?: boolean;
    composition_analysis?: boolean;
  }): Promise<ImageAnalysisResult> {
    try {
      const startTime = Date.now();

      // For demo purposes, we'll create a comprehensive mock analysis
      // In production, this would use actual AI vision models
      const analysis = await this.performComprehensiveAnalysis(imageUrl, options);
      
      const processingTime = (Date.now() - startTime) / 1000;

      return {
        id: `analysis_${Date.now()}`,
        imageUrl,
        timestamp: new Date(),
        confidence: analysis.confidence,
        processing_time: processingTime,
        weather_classification: analysis.weather_classification,
        storm_features: analysis.storm_features,
        safety_assessment: analysis.safety_assessment,
        technical_analysis: analysis.technical_analysis,
        composition_score: analysis.composition_score,
        metadata: analysis.metadata,
        tags: analysis.tags,
        similar_events: analysis.similar_events,
      };
    } catch (error) {
      console.error('Error analyzing weather image:', error);
      throw error;
    }
  }

  async identifyCloudTypes(imageUrl: string): Promise<CloudClassification> {
    try {
      // Mock cloud classification
      return {
        cloud_types: [
          {
            type: 'cumulonimbus',
            confidence: 0.92,
            coverage: 0.6,
            altitude: 'low',
            characteristics: ['towering', 'anvil_top', 'strong_updrafts', 'precipitation'],
          },
          {
            type: 'cumulus',
            confidence: 0.78,
            coverage: 0.3,
            altitude: 'low',
            characteristics: ['puffy', 'fair_weather', 'isolated'],
          },
        ],
        cloud_coverage: 0.75,
        precipitation_probability: 0.85,
        development_stage: 'mature',
      };
    } catch (error) {
      console.error('Error identifying cloud types:', error);
      throw error;
    }
  }

  async analyzeTornado(imageUrl: string): Promise<TornadoAnalysis> {
    try {
      // Mock tornado analysis
      return {
        tornado_present: true,
        confidence: 0.94,
        ef_scale_estimate: 'EF2',
        characteristics: {
          funnel_visible: true,
          debris_cloud: true,
          condensation_funnel: true,
          width_estimate: 200,
          height_estimate: 1500,
        },
        damage_indicators: ['Flying debris', 'Ground circulation', 'Condensation funnel'],
        path_analysis: {
          direction: 45, // northeast
          estimated_speed: 55,
          path_width: 300,
        },
        safety_zone: {
          recommended_distance: 2000,
          safe_directions: [135, 225], // southeast, southwest
        },
      };
    } catch (error) {
      console.error('Error analyzing tornado:', error);
      throw error;
    }
  }

  async analyzeLightning(imageUrl: string): Promise<LightningAnalysis> {
    try {
      // Mock lightning analysis
      return {
        lightning_detected: true,
        lightning_types: [
          {
            type: 'cloud_to_ground',
            count: 3,
            intensity: 'strong',
          },
          {
            type: 'intracloud',
            count: 8,
            intensity: 'moderate',
          },
        ],
        strike_frequency: 12,
        danger_assessment: {
          immediate_threat: true,
          safe_distance: 1500,
          time_between_strikes: 5,
        },
        photographic_tips: [
          'Use long exposure for multiple strikes',
          'Maintain safe distance in vehicle',
          'Use tripod for stability',
          'Set camera to bulb mode',
        ],
      };
    } catch (error) {
      console.error('Error analyzing lightning:', error);
      throw error;
    }
  }

  async generateEducationalInsights(analysis: ImageAnalysisResult): Promise<EducationalInsights> {
    try {
      // Generate educational content based on analysis
      const primaryType = analysis.weather_classification.primary_type;
      
      const insights: EducationalInsights = {
        meteorological_explanation: this.getMeteorologicalExplanation(primaryType),
        formation_process: this.getFormationProcess(primaryType),
        scientific_interest: this.getScientificInterest(primaryType),
        historical_context: this.getHistoricalContext(primaryType),
        learning_points: this.getLearningPoints(analysis),
        related_phenomena: this.getRelatedPhenomena(primaryType),
        safety_lessons: analysis.safety_assessment.recommended_actions,
        photography_tips: this.getPhotographyTips(analysis),
      };

      return insights;
    } catch (error) {
      console.error('Error generating educational insights:', error);
      throw error;
    }
  }

  async compareWithHistoricalEvents(analysis: ImageAnalysisResult): Promise<SimilarEvent[]> {
    try {
      // Mock historical comparison
      if (analysis.weather_classification.primary_type === 'tornado') {
        return [
          {
            event_id: 'moore_2013',
            similarity_score: 0.87,
            event_type: 'EF5 Tornado',
            location: 'Moore, Oklahoma',
            date: new Date('2013-05-20'),
            image_url: 'https://example.com/moore2013.jpg',
            description: 'Devastating EF5 tornado with similar visual characteristics',
            outcome: '24 fatalities, widespread destruction',
            lessons_learned: [
              'Importance of underground shelter',
              'Early warning systems save lives',
              'Mobile radar crucial for tracking',
            ],
          },
          {
            event_id: 'el_reno_2013',
            similarity_score: 0.73,
            event_type: 'EF3 Tornado (Record Width)',
            location: 'El Reno, Oklahoma',
            date: new Date('2013-05-31'),
            image_url: 'https://example.com/elreno2013.jpg',
            description: 'Widest tornado on record with rapid intensification',
            outcome: '8 fatalities including storm chasers',
            lessons_learned: [
              'Tornadoes can rapidly change size and intensity',
              'Even experienced chasers face deadly risks',
              'Escape routes must be planned carefully',
            ],
          },
        ];
      }
      return [];
    } catch (error) {
      console.error('Error comparing with historical events:', error);
      return [];
    }
  }

  async batchAnalyzeImages(imageUrls: string[]): Promise<ImageAnalysisResult[]> {
    try {
      const analyses = await Promise.all(
        imageUrls.map(url => this.analyzeWeatherImage(url))
      );
      return analyses;
    } catch (error) {
      console.error('Error in batch image analysis:', error);
      throw error;
    }
  }

  async validateStormReport(imageUrl: string, reportData: any): Promise<{
    validated: boolean;
    confidence: number;
    discrepancies: string[];
    supporting_evidence: string[];
  }> {
    try {
      const analysis = await this.analyzeWeatherImage(imageUrl);
      
      // Compare analysis with report data
      const validation = {
        validated: analysis.confidence > 0.8,
        confidence: analysis.confidence,
        discrepancies: [],
        supporting_evidence: [],
      };

      // Check for discrepancies
      if (reportData.stormType !== analysis.weather_classification.primary_type) {
        validation.discrepancies.push(`Reported: ${reportData.stormType}, Detected: ${analysis.weather_classification.primary_type}`);
      }

      // Add supporting evidence
      if (analysis.storm_features.length > 0) {
        validation.supporting_evidence.push(`${analysis.storm_features.length} storm features detected`);
      }

      return validation;
    } catch (error) {
      console.error('Error validating storm report:', error);
      throw error;
    }
  }

  // Private helper methods
  private async performComprehensiveAnalysis(imageUrl: string, options: any): Promise<any> {
    // Mock comprehensive analysis
    return {
      confidence: 0.89,
      weather_classification: {
        primary_type: 'thunderstorm',
        confidence: 0.92,
        secondary_types: [
          { type: 'supercell', confidence: 0.78 },
          { type: 'severe', confidence: 0.85 },
        ],
        severity: 'severe',
        phenomena: [
          {
            type: 'wall_cloud',
            confidence: 0.84,
            location: { x: 0.3, y: 0.4, width: 0.4, height: 0.3 },
            characteristics: ['rotation_visible', 'lowered_base', 'inflow_tail'],
            severity_indicators: ['strong_rotation', 'rapid_development'],
          },
        ],
      },
      storm_features: [
        {
          feature_type: 'rotation',
          confidence: 0.87,
          location: { x: 0.35, y: 0.45, width: 0.3, height: 0.25 },
          strength: 'strong',
          movement_direction: 45,
          characteristics: {
            angular_velocity: 'high',
            persistence: 'sustained',
          },
        },
      ],
      safety_assessment: {
        danger_level: 'dangerous',
        immediate_threats: ['Tornado development possible', 'Large hail', 'Damaging winds'],
        recommended_actions: [
          'Maintain safe distance (2+ miles)',
          'Monitor for tornado development',
          'Have escape route planned',
          'Watch for rapidly changing conditions',
        ],
        safe_distance: 3000,
        escape_routes: ['East', 'South'],
        time_to_impact: 15,
        warning_signs: ['Rapid rotation increase', 'Lowering cloud base', 'Debris at surface'],
      },
      technical_analysis: {
        camera_settings: {
          estimated_focal_length: 24,
          estimated_aperture: 'f/8',
          estimated_iso: 400,
          estimated_shutter_speed: '1/250s',
        },
        image_quality: {
          sharpness: 0.85,
          exposure: 0.2,
          contrast: 0.75,
          saturation: 0.8,
          noise_level: 0.15,
        },
        atmospheric_conditions: {
          visibility: 8,
          estimated_wind_speed: 45,
          precipitation_intensity: 0.6,
          lighting_conditions: 'afternoon',
        },
      },
      composition_score: {
        overall_score: 78,
        elements: {
          rule_of_thirds: 0.8,
          leading_lines: 0.6,
          foreground_interest: 0.7,
          depth_of_field: 0.9,
          framing: 0.75,
          symmetry: 0.4,
          color_harmony: 0.85,
        },
        improvements: [
          'Consider lower camera angle for more dramatic effect',
          'Include more foreground elements for scale',
        ],
        strengths: [
          'Excellent storm structure capture',
          'Good use of natural lighting',
          'Sharp focus on key features',
        ],
      },
      metadata: {
        original_size: { width: 4000, height: 3000 },
        file_size: 2500000,
        format: 'JPEG',
        timestamp: new Date(),
        location: {
          latitude: 35.0,
          longitude: -97.0,
          accuracy: 5,
          address: 'Oklahoma, USA',
        },
      },
      tags: [
        'supercell',
        'wall_cloud',
        'rotation',
        'severe_thunderstorm',
        'oklahoma',
        'storm_structure',
      ],
      similar_events: [],
    };
  }

  private getMeteorologicalExplanation(type: string): string {
    const explanations = {
      tornado: 'Tornadoes form when warm, moist air meets cool, dry air creating wind shear and rotation in supercell thunderstorms.',
      thunderstorm: 'Thunderstorms develop when warm, moist air rises rapidly through cooler air, creating instability and convection.',
      supercell: 'Supercells are rotating thunderstorms with a persistent mesocyclone, capable of producing severe weather.',
    };
    return explanations[type as keyof typeof explanations] || 'Weather phenomenon analysis';
  }

  private getFormationProcess(type: string): string[] {
    const processes = {
      tornado: [
        'Wind shear creates horizontal rotation',
        'Updraft tilts rotation vertical',
        'Mesocyclone strengthens',
        'Tornado descends from wall cloud',
      ],
      thunderstorm: [
        'Solar heating warms surface air',
        'Warm air rises and cools',
        'Water vapor condenses',
        'Latent heat fuels further development',
      ],
    };
    return processes[type as keyof typeof processes] || ['Formation process varies'];
  }

  private getScientificInterest(type: string): string[] {
    return [
      'Atmospheric dynamics research',
      'Climate change impacts',
      'Forecasting model improvement',
      'Damage assessment studies',
    ];
  }

  private getHistoricalContext(type: string): string {
    return `Historical analysis of ${type} events shows patterns in frequency, intensity, and geographic distribution.`;
  }

  private getLearningPoints(analysis: ImageAnalysisResult): string[] {
    return [
      `Primary weather type: ${analysis.weather_classification.primary_type}`,
      `Safety level: ${analysis.safety_assessment.danger_level}`,
      `Key features identified: ${analysis.storm_features.length}`,
      `Confidence level: ${Math.round(analysis.confidence * 100)}%`,
    ];
  }

  private getRelatedPhenomena(type: string): string[] {
    const related = {
      tornado: ['Supercells', 'Wall clouds', 'Mesocyclones', 'Hook echoes'],
      thunderstorm: ['Lightning', 'Hail', 'Microbursts', 'Flash flooding'],
      supercell: ['Tornadoes', 'Large hail', 'Damaging winds', 'Flash floods'],
    };
    return related[type as keyof typeof related] || ['Various weather phenomena'];
  }

  private getPhotographyTips(analysis: ImageAnalysisResult): string[] {
    const tips = [
      'Maintain safe distance always',
      'Use wide-angle lens for storm structure',
      'Consider foreground elements for scale',
      'Shoot in RAW for better post-processing',
    ];

    if (analysis.technical_analysis.image_quality.exposure < 0) {
      tips.push('Increase exposure for better storm contrast');
    }

    if (analysis.composition_score.elements.rule_of_thirds < 0.6) {
      tips.push('Apply rule of thirds for better composition');
    }

    return tips;
  }
}

export const imageRecognitionService = new ImageRecognitionService();