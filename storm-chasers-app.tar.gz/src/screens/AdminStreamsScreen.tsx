import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, Alert, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useStormChaserStore } from '../state/stormChasers';

export default function AdminStreamsScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const { liveStreams, chasers, endLiveStream } = useStormChaserStore();
  
  const [filterStatus, setFilterStatus] = useState<'all' | 'live' | 'ended'>('all');
  const [selectedStream, setSelectedStream] = useState<any>(null);
  const [showStreamModal, setShowStreamModal] = useState(false);

  const filteredStreams = liveStreams.filter(stream => {
    if (filterStatus === 'all') return true;
    if (filterStatus === 'live') return true; // All streams in our store are live
    return false;
  });

  const handleStreamAction = (stream: any, action: string) => {
    setSelectedStream(stream);
    
    switch (action) {
      case 'end':
        Alert.alert(
          'End Stream',
          `Are you sure you want to end "${stream.title}"?`,
          [
            { text: 'Cancel', style: 'cancel' },
            { 
              text: 'End Stream', 
              style: 'destructive',
              onPress: () => {
                endLiveStream(stream.id);
                Alert.alert('Success', 'Stream has been ended.');
              }
            },
          ]
        );
        break;
      case 'details':
        setShowStreamModal(true);
        break;
    }
  };

  const getStreamDuration = (startTime: Date) => {
    const now = new Date();
    const diff = now.getTime() - startTime.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  };

  const formatViewerCount = (viewers: number) => {
    if (viewers >= 1000) {
      return `${(viewers / 1000).toFixed(1)}K`;
    }
    return viewers.toString();
  };

  return (
    <>
      <View className="flex-1 bg-storm-900" style={{ paddingTop: insets.top }}>
        {/* Header */}
        <View className="px-4 py-6 bg-storm-800 border-b border-storm-700">
          <View className="flex-row items-center">
            <Pressable onPress={() => navigation.goBack()} className="mr-4">
              <Ionicons name="chevron-back" size={24} color="#0ea5e9" />
            </Pressable>
            <View>
              <Text className="text-2xl font-bold text-storm-50">Stream Management</Text>
              <Text className="text-lightning-300 mt-1">{filteredStreams.length} streams</Text>
            </View>
          </View>
        </View>

        {/* Filters */}
        <View className="p-4 bg-storm-800 border-b border-storm-700">
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {['all', 'live', 'ended'].map((status) => (
              <Pressable
                key={status}
                onPress={() => setFilterStatus(status as any)}
                className={`mr-3 px-4 py-2 rounded-full border ${
                  filterStatus === status
                    ? 'bg-lightning-500 border-lightning-500'
                    : 'bg-transparent border-storm-600'
                }`}
              >
                <Text className={`text-sm font-medium ${
                  filterStatus === status ? 'text-white' : 'text-storm-300'
                }`}>
                  {status.charAt(0).toUpperCase() + status.slice(1)}
                </Text>
              </Pressable>
            ))}
          </ScrollView>
        </View>

        {/* Streams List */}
        <ScrollView className="flex-1">
          {filteredStreams.map((stream) => {
            const chaser = chasers.find(c => c.id === stream.chaserId);
            return (
              <View key={stream.id} className="border-b border-storm-700">
                <Pressable
                  onPress={() => handleStreamAction(stream, 'details')}
                  className="p-4 bg-storm-900"
                >
                  <View className="flex-row items-start">
                    <View className="w-16 h-12 bg-storm-700 rounded items-center justify-center mr-3">
                      <Text className="text-2xl">{stream.thumbnail}</Text>
                    </View>
                    
                    <View className="flex-1">
                      <View className="flex-row items-center justify-between mb-2">
                        <Text className="text-storm-50 font-semibold flex-1" numberOfLines={1}>
                          {stream.title}
                        </Text>
                        <View className="flex-row items-center ml-2">
                          <View className="w-2 h-2 bg-red-500 rounded-full mr-1" />
                          <Text className="text-red-400 text-xs font-medium">LIVE</Text>
                        </View>
                      </View>
                      
                      <Text className="text-storm-400 text-sm mb-2">{chaser?.name}</Text>
                      <Text className="text-storm-300 text-sm mb-3" numberOfLines={2}>
                        {stream.description}
                      </Text>
                      
                      <View className="flex-row items-center justify-between">
                        <View className="flex-row items-center">
                          <Ionicons name="eye" size={14} color="#64748b" />
                          <Text className="text-storm-400 text-sm ml-1">
                            {formatViewerCount(stream.viewers)} viewers
                          </Text>
                          <Text className="text-storm-500 text-sm ml-3">
                            {getStreamDuration(stream.startTime)}
                          </Text>
                        </View>
                        
                        <View className="flex-row items-center">
                          <Pressable
                            onPress={() => handleStreamAction(stream, 'end')}
                            className="bg-red-600 px-3 py-1 rounded mr-2"
                          >
                            <Text className="text-white text-xs font-medium">End Stream</Text>
                          </Pressable>
                          <Ionicons name="chevron-forward" size={16} color="#64748b" />
                        </View>
                      </View>
                    </View>
                  </View>
                </Pressable>
              </View>
            );
          })}
          
          {filteredStreams.length === 0 && (
            <View className="p-8 items-center">
              <Ionicons name="radio" size={48} color="#64748b" />
              <Text className="text-storm-400 text-center mt-4">
                No streams found matching your criteria
              </Text>
            </View>
          )}
        </ScrollView>
      </View>

      {/* Stream Details Modal */}
      <Modal
        visible={showStreamModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View className="flex-1 bg-storm-900" style={{ paddingTop: insets.top }}>
          {selectedStream && (
            <>
              <View className="flex-row items-center justify-between p-4 border-b border-storm-700">
                <Text className="text-lg font-semibold text-storm-50">Stream Details</Text>
                <Pressable onPress={() => setShowStreamModal(false)}>
                  <Ionicons name="close" size={24} color="#64748b" />
                </Pressable>
              </View>
              
              <ScrollView className="flex-1 p-4">
                {/* Stream Info */}
                <View className="bg-storm-800 rounded-lg p-4 border border-storm-700 mb-4">
                  <View className="flex-row items-center mb-4">
                    <View className="w-16 h-16 bg-storm-700 rounded-lg items-center justify-center mr-4">
                      <Text className="text-3xl">{selectedStream.thumbnail}</Text>
                    </View>
                    <View className="flex-1">
                      <Text className="text-storm-50 font-bold text-lg">{selectedStream.title}</Text>
                      <View className="flex-row items-center mt-1">
                        <View className="w-2 h-2 bg-red-500 rounded-full mr-2" />
                        <Text className="text-red-400 text-sm font-medium">LIVE</Text>
                        <Text className="text-storm-400 text-sm ml-2">
                          {getStreamDuration(selectedStream.startTime)}
                        </Text>
                      </View>
                    </View>
                  </View>
                  
                  <View className="space-y-3">
                    <View>
                      <Text className="text-storm-400 text-sm">Description:</Text>
                      <Text className="text-storm-50">{selectedStream.description}</Text>
                    </View>
                    
                    <View className="flex-row justify-between">
                      <View>
                        <Text className="text-storm-400 text-sm">Viewers:</Text>
                        <Text className="text-storm-50 font-semibold">
                          {selectedStream.viewers.toLocaleString()}
                        </Text>
                      </View>
                      <View>
                        <Text className="text-storm-400 text-sm">Platform:</Text>
                        <Text className="text-storm-50 font-semibold">
                          {selectedStream.platform || 'Native'}
                        </Text>
                      </View>
                    </View>
                    
                    <View>
                      <Text className="text-storm-400 text-sm">Location:</Text>
                      <Text className="text-storm-50">{selectedStream.location}</Text>
                    </View>
                    
                    <View>
                      <Text className="text-storm-400 text-sm">Weather Condition:</Text>
                      <Text className="text-storm-50">{selectedStream.weatherCondition}</Text>
                    </View>
                    
                    <View>
                      <Text className="text-storm-400 text-sm">Started:</Text>
                      <Text className="text-storm-50">{selectedStream.startTime.toLocaleString()}</Text>
                    </View>
                  </View>
                </View>

                {/* Actions */}
                <View className="space-y-3">
                  <Text className="text-storm-50 font-semibold mb-2">Stream Actions</Text>
                  
                  <Pressable
                    onPress={() => {
                      setShowStreamModal(false);
                      // Navigate to stream detail for monitoring
                    }}
                    className="bg-storm-800 rounded-lg p-4 border border-storm-700"
                  >
                    <View className="flex-row items-center">
                      <Ionicons name="eye" size={20} color="#0ea5e9" />
                      <Text className="text-storm-50 ml-3">Monitor Stream</Text>
                    </View>
                  </Pressable>
                  
                  <Pressable
                    onPress={() => {
                      setShowStreamModal(false);
                      handleStreamAction(selectedStream, 'end');
                    }}
                    className="bg-red-900 rounded-lg p-4 border border-red-700"
                  >
                    <View className="flex-row items-center">
                      <Ionicons name="stop-circle" size={20} color="#ef4444" />
                      <Text className="text-red-300 ml-3">End Stream</Text>
                    </View>
                  </Pressable>
                </View>
              </ScrollView>
            </>
          )}
        </View>
      </Modal>
    </>
  );
}