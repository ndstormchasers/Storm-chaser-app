import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, Alert, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/auth';
import { AuthStackParamList } from '../types';

type SignUpScreenNavigationProp = NativeStackNavigationProp<AuthStackParamList, 'SignUp'>;

export default function SignUpScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<SignUpScreenNavigationProp>();
  const { signUp, isLoading } = useAuthStore();

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    location: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.firstName.trim()) {
      newErrors.firstName = 'First name is required';
    }

    if (!formData.lastName.trim()) {
      newErrors.lastName = 'Last name is required';
    }

    if (!formData.username.trim()) {
      newErrors.username = 'Username is required';
    } else if (formData.username.length < 3) {
      newErrors.username = 'Username must be at least 3 characters';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email';
    }

    if (!formData.password.trim()) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    if (!formData.location.trim()) {
      newErrors.location = 'Location is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSignUp = async () => {
    if (!validateForm()) return;

    const success = await signUp({
      firstName: formData.firstName.trim(),
      lastName: formData.lastName.trim(),
      username: formData.username.trim(),
      email: formData.email.trim(),
      password: formData.password,
      location: formData.location.trim(),
      bio: `Storm chaser from ${formData.location.trim()}. Ready to track severe weather!`,
    });

    if (!success) {
      Alert.alert(
        'Sign Up Failed',
        'Unable to create account. Please try again.',
        [{ text: 'OK' }]
      );
    }
  };

  const getRandomAvatar = () => {
    const avatars = ['🌪️', '⛈️', '🌩️', '🌀', '☁️', '🧊'];
    return avatars[Math.floor(Math.random() * avatars.length)];
  };

  const updateField = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <KeyboardAvoidingView 
      className="flex-1 bg-white"
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView className="flex-1" style={{ paddingTop: insets.top }}>
        {/* Header */}
        <View className="px-6 pt-8 pb-6">
          <Pressable 
            onPress={() => navigation.goBack()}
            className="mb-6"
          >
            <Ionicons name="chevron-back" size={24} color="#374151" />
          </Pressable>
          
          <Text className="text-3xl font-bold text-gray-900 mb-2">Join Storm Chasers</Text>
          <Text className="text-gray-600">Create your account to start tracking storms</Text>
        </View>

        {/* Form */}
        <View className="px-6 space-y-4">
          {/* Name Fields */}
          <View className="flex-row space-x-4">
            <View className="flex-1">
              <Text className="text-sm font-medium text-gray-700 mb-2">First Name</Text>
              <TextInput
                value={formData.firstName}
                onChangeText={(text) => updateField('firstName', text)}
                placeholder="John"
                className={`bg-gray-50 border rounded-lg px-4 py-3 ${
                  errors.firstName ? 'border-red-500' : 'border-gray-300'
                }`}
                autoCapitalize="words"
              />
              {errors.firstName && (
                <Text className="text-red-500 text-xs mt-1">{errors.firstName}</Text>
              )}
            </View>

            <View className="flex-1">
              <Text className="text-sm font-medium text-gray-700 mb-2">Last Name</Text>
              <TextInput
                value={formData.lastName}
                onChangeText={(text) => updateField('lastName', text)}
                placeholder="Storm"
                className={`bg-gray-50 border rounded-lg px-4 py-3 ${
                  errors.lastName ? 'border-red-500' : 'border-gray-300'
                }`}
                autoCapitalize="words"
              />
              {errors.lastName && (
                <Text className="text-red-500 text-xs mt-1">{errors.lastName}</Text>
              )}
            </View>
          </View>

          {/* Username */}
          <View>
            <Text className="text-sm font-medium text-gray-700 mb-2">Username</Text>
            <TextInput
              value={formData.username}
              onChangeText={(text) => updateField('username', text.toLowerCase())}
              placeholder="stormchaser2024"
              className={`bg-gray-50 border rounded-lg px-4 py-3 ${
                errors.username ? 'border-red-500' : 'border-gray-300'
              }`}
              autoCapitalize="none"
            />
            {errors.username && (
              <Text className="text-red-500 text-sm mt-1">{errors.username}</Text>
            )}
          </View>

          {/* Email */}
          <View>
            <Text className="text-sm font-medium text-gray-700 mb-2">Email Address</Text>
            <TextInput
              value={formData.email}
              onChangeText={(text) => updateField('email', text)}
              placeholder="john@example.com"
              className={`bg-gray-50 border rounded-lg px-4 py-3 ${
                errors.email ? 'border-red-500' : 'border-gray-300'
              }`}
              keyboardType="email-address"
              autoCapitalize="none"
            />
            {errors.email && (
              <Text className="text-red-500 text-sm mt-1">{errors.email}</Text>
            )}
          </View>

          {/* Location */}
          <View>
            <Text className="text-sm font-medium text-gray-700 mb-2">Location</Text>
            <TextInput
              value={formData.location}
              onChangeText={(text) => updateField('location', text)}
              placeholder="Oklahoma, USA"
              className={`bg-gray-50 border rounded-lg px-4 py-3 ${
                errors.location ? 'border-red-500' : 'border-gray-300'
              }`}
              autoCapitalize="words"
            />
            {errors.location && (
              <Text className="text-red-500 text-sm mt-1">{errors.location}</Text>
            )}
          </View>

          {/* Password */}
          <View>
            <Text className="text-sm font-medium text-gray-700 mb-2">Password</Text>
            <View className="relative">
              <TextInput
                value={formData.password}
                onChangeText={(text) => updateField('password', text)}
                placeholder="Enter your password"
                secureTextEntry={!showPassword}
                className={`bg-gray-50 border rounded-lg px-4 py-3 pr-12 ${
                  errors.password ? 'border-red-500' : 'border-gray-300'
                }`}
              />
              <Pressable
                onPress={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3"
              >
                <Ionicons 
                  name={showPassword ? "eye-off" : "eye"} 
                  size={20} 
                  color="#9CA3AF" 
                />
              </Pressable>
            </View>
            {errors.password && (
              <Text className="text-red-500 text-sm mt-1">{errors.password}</Text>
            )}
          </View>

          {/* Confirm Password */}
          <View>
            <Text className="text-sm font-medium text-gray-700 mb-2">Confirm Password</Text>
            <View className="relative">
              <TextInput
                value={formData.confirmPassword}
                onChangeText={(text) => updateField('confirmPassword', text)}
                placeholder="Confirm your password"
                secureTextEntry={!showConfirmPassword}
                className={`bg-gray-50 border rounded-lg px-4 py-3 pr-12 ${
                  errors.confirmPassword ? 'border-red-500' : 'border-gray-300'
                }`}
              />
              <Pressable
                onPress={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-3 top-3"
              >
                <Ionicons 
                  name={showConfirmPassword ? "eye-off" : "eye"} 
                  size={20} 
                  color="#9CA3AF" 
                />
              </Pressable>
            </View>
            {errors.confirmPassword && (
              <Text className="text-red-500 text-sm mt-1">{errors.confirmPassword}</Text>
            )}
          </View>

          {/* Sign Up Button */}
          <View className="pt-4">
            <Pressable
              onPress={handleSignUp}
              disabled={isLoading}
              className={`py-4 rounded-lg ${
                isLoading ? 'bg-gray-400' : 'bg-red-500'
              }`}
            >
              <View className="flex-row items-center justify-center">
                {isLoading && (
                  <View className="mr-2">
                    <Ionicons name="hourglass" size={20} color="white" />
                  </View>
                )}
                <Text className="text-white font-semibold text-lg">
                  {isLoading ? 'Creating Account...' : 'Create Account'}
                </Text>
              </View>
            </Pressable>
          </View>

          {/* Terms */}
          <Text className="text-gray-600 text-center text-sm pt-4">
            By creating an account, you agree to our{'\n'}
            <Text className="text-red-500 font-medium">Terms of Service</Text> and{' '}
            <Text className="text-red-500 font-medium">Privacy Policy</Text>
          </Text>

          {/* Sign In Link */}
          <View className="flex-row items-center justify-center pt-6 pb-8">
            <Text className="text-gray-600">Already have an account? </Text>
            <Pressable onPress={() => navigation.navigate('Login')}>
              <Text className="text-red-500 font-semibold">Sign In</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}