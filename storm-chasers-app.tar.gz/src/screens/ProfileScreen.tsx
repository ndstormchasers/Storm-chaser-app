import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import { useRoute, RouteProp } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useStormChaserStore } from '../state/stormChasers';
import { RootStackParamList } from '../types';

type ProfileScreenRouteProp = RouteProp<RootStackParamList, 'Profile'>;

export default function ProfileScreen() {
  const route = useRoute<ProfileScreenRouteProp>();
  const { chaserId } = route.params;
  const { chasers, liveStreams } = useStormChaserStore();
  const [isFollowing, setIsFollowing] = useState(false);

  const chaser = chasers.find(c => c.id === chaserId);
  const chaserStreams = liveStreams.filter(s => s.chaserId === chaserId);

  if (!chaser) {
    return (
      <View className="flex-1 items-center justify-center bg-gray-50">
        <Text className="text-gray-600">Profile not found</Text>
      </View>
    );
  }

  return (
    <ScrollView className="flex-1 bg-gray-50">
      {/* Profile Header */}
      <View className="bg-white p-6 border-b border-gray-200">
        <View className="items-center mb-4">
          <View className="w-24 h-24 bg-blue-100 rounded-full items-center justify-center mb-4">
            <Text className="text-5xl">{chaser.avatar}</Text>
          </View>
          {chaser.isLive && (
            <View className="absolute top-0 right-0 bg-red-500 px-2 py-1 rounded-full">
              <Text className="text-white text-xs font-bold">LIVE</Text>
            </View>
          )}
          <Text className="text-2xl font-bold text-gray-900">{chaser.name}</Text>
          <View className="flex-row items-center mt-2">
            <Ionicons name="location" size={16} color="#6b7280" />
            <Text className="text-gray-600 ml-1">{chaser.location}</Text>
          </View>
        </View>

        <View className="flex-row justify-around mb-6">
          <View className="items-center">
            <Text className="text-2xl font-bold text-gray-900">
              {chaser.followers.toLocaleString()}
            </Text>
            <Text className="text-gray-600 text-sm">Followers</Text>
          </View>
          <View className="items-center">
            <Text className="text-2xl font-bold text-gray-900">{chaser.stormsCaught}</Text>
            <Text className="text-gray-600 text-sm">Storms Caught</Text>
          </View>
          <View className="items-center">
            <Text className="text-2xl font-bold text-gray-900">{chaser.yearsExperience}</Text>
            <Text className="text-gray-600 text-sm">Years Experience</Text>
          </View>
        </View>

        <Pressable
          onPress={() => setIsFollowing(!isFollowing)}
          className={`py-3 rounded-lg ${
            isFollowing ? 'bg-gray-200' : 'bg-red-500'
          }`}
        >
          <Text className={`text-center font-semibold ${
            isFollowing ? 'text-gray-700' : 'text-white'
          }`}>
            {isFollowing ? 'Following' : 'Follow'}
          </Text>
        </Pressable>
      </View>

      {/* Bio Section */}
      <View className="bg-white p-6 mb-4 border-b border-gray-200">
        <Text className="font-semibold text-gray-900 mb-3">About</Text>
        <Text className="text-gray-600 leading-6">{chaser.bio}</Text>
      </View>

      {/* Live Streams */}
      {chaserStreams.length > 0 && (
        <View className="bg-white p-6 mb-4">
          <Text className="font-semibold text-gray-900 mb-4">Currently Live</Text>
          <View className="space-y-4">
            {chaserStreams.map((stream) => (
              <View key={stream.id} className="border border-gray-200 rounded-lg p-4">
                <View className="flex-row items-center mb-2">
                  <View className="w-2 h-2 bg-red-500 rounded-full mr-2" />
                  <Text className="font-medium text-gray-900">{stream.title}</Text>
                </View>
                <Text className="text-gray-600 text-sm mb-2">{stream.description}</Text>
                <View className="flex-row items-center justify-between">
                  <View className="flex-row items-center">
                    <Ionicons name="location" size={14} color="#6b7280" />
                    <Text className="text-sm text-gray-600 ml-1">{stream.location}</Text>
                  </View>
                  <View className="flex-row items-center">
                    <Ionicons name="eye" size={14} color="#6b7280" />
                    <Text className="text-sm text-gray-600 ml-1">
                      {stream.viewers.toLocaleString()} viewers
                    </Text>
                  </View>
                </View>
              </View>
            ))}
          </View>
        </View>
      )}

      {/* Stats Section */}
      <View className="bg-white p-6 mb-4">
        <Text className="font-semibold text-gray-900 mb-4">Career Highlights</Text>
        <View className="space-y-3">
          <View className="flex-row items-center justify-between">
            <View className="flex-row items-center">
              <Ionicons name="thunderstorm" size={20} color="#6b7280" />
              <Text className="text-gray-700 ml-3">Tornadoes Documented</Text>
            </View>
            <Text className="font-semibold text-gray-900">
              {Math.floor(chaser.stormsCaught * 0.3)}
            </Text>
          </View>
          <View className="flex-row items-center justify-between">
            <View className="flex-row items-center">
              <Ionicons name="camera" size={20} color="#6b7280" />
              <Text className="text-gray-700 ml-3">Photos Captured</Text>
            </View>
            <Text className="font-semibold text-gray-900">
              {(chaser.stormsCaught * 15).toLocaleString()}
            </Text>
          </View>
          <View className="flex-row items-center justify-between">
            <View className="flex-row items-center">
              <Ionicons name="car" size={20} color="#6b7280" />
              <Text className="text-gray-700 ml-3">Miles Driven</Text>
            </View>
            <Text className="font-semibold text-gray-900">
              {(chaser.yearsExperience * 25000).toLocaleString()}
            </Text>
          </View>
        </View>
      </View>

      {/* Recent Activity */}
      <View className="bg-white p-6 mb-4">
        <Text className="font-semibold text-gray-900 mb-4">Recent Activity</Text>
        <View className="space-y-4">
          <View className="flex-row items-start">
            <View className="w-8 h-8 bg-red-100 rounded-full items-center justify-center mr-3">
              <Ionicons name="radio" size={16} color="#ef4444" />
            </View>
            <View className="flex-1">
              <Text className="text-gray-900 font-medium">Went live</Text>
              <Text className="text-gray-600 text-sm">Tracked supercell in Oklahoma</Text>
              <Text className="text-gray-500 text-xs mt-1">2 hours ago</Text>
            </View>
          </View>
          <View className="flex-row items-start">
            <View className="w-8 h-8 bg-blue-100 rounded-full items-center justify-center mr-3">
              <Ionicons name="camera" size={16} color="#3b82f6" />
            </View>
            <View className="flex-1">
              <Text className="text-gray-900 font-medium">Captured tornado</Text>
              <Text className="text-gray-600 text-sm">EF2 tornado near Moore, OK</Text>
              <Text className="text-gray-500 text-xs mt-1">1 day ago</Text>
            </View>
          </View>
          <View className="flex-row items-start">
            <View className="w-8 h-8 bg-green-100 rounded-full items-center justify-center mr-3">
              <Ionicons name="trophy" size={16} color="#10b981" />
            </View>
            <View className="flex-1">
              <Text className="text-gray-900 font-medium">Milestone reached</Text>
              <Text className="text-gray-600 text-sm">250th storm documented</Text>
              <Text className="text-gray-500 text-xs mt-1">3 days ago</Text>
            </View>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}