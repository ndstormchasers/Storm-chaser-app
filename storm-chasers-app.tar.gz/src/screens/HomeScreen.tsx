import React from 'react';
import { View, Text, ScrollView, Pressable, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { useStormChaserStore } from '../state/stormChasers';
import { useWeatherStore } from '../state/weather';
import { weatherAlertsService } from '../api/weather-alerts';
import { useWeatherAlerts } from '../hooks/useWeatherAlerts';
import { RootStackParamList } from '../types';

type HomeScreenNavigationProp = NativeStackNavigationProp<RootStackParamList, 'Home'>;

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<HomeScreenNavigationProp>();
  const { chasers, liveStreams } = useStormChaserStore();
  const { alerts, currentWeather, alertsEnabled, userLocation } = useWeatherAlerts();
  
  // Force real location display
  React.useEffect(() => {
    if (userLocation) {
      console.log('🏠 HOME SCREEN: Using real location', userLocation);
    }
  }, [userLocation]);

  const liveChasers = chasers.filter(chaser => chaser.isLive);
  const featuredStreams = liveStreams.slice(0, 3);
  const activeAlerts = alerts.filter(alert => alert.severity === 'severe' || alert.severity === 'extreme').slice(0, 2);
  
  // Production mode indicators
  const isProductionMode = chasers.length === 0 && liveStreams.length === 0;

  return (
    <ScrollView 
      className="flex-1 bg-storm-900"
      style={{ paddingTop: insets.top }}
    >
      {/* Header */}
      <View className="px-4 py-6 bg-storm-800 border-b border-storm-700">
        <Text className="text-3xl font-bold text-storm-50">Storm Chasers</Text>
        <Text className="text-lightning-300 mt-1">
          {alerts.length > 0 ? `🌪️ LIVE: ${alerts.length} weather alerts` : 'Professional storm tracking platform'}
        </Text>
      </View>

      {/* Weather Alerts Widget */}
      {alertsEnabled && activeAlerts.length > 0 && (
        <View className="px-4 py-4">
          <View className="flex-row items-center justify-between mb-3">
            <Text className="text-lg font-semibold text-storm-50">⚠️ Weather Alerts</Text>
            <Pressable 
              onPress={() => navigation.navigate('Alerts')}
              className="flex-row items-center"
            >
              <Text className="text-lightning-400 font-medium mr-1">View All</Text>
              <Ionicons name="chevron-forward" size={16} color="#38bdf8" />
            </Pressable>
          </View>
          
          <View className="space-y-2">
            {activeAlerts.map((alert) => (
              <Pressable
                key={alert.id}
                onPress={() => navigation.navigate('Alerts')}
                className="bg-storm-800 rounded-lg p-3 border-l-4 border border-storm-700"
                style={{ borderLeftColor: weatherAlertsService.getSeverityColor(alert.severity) }}
              >
                <View className="flex-row items-center">
                  <Text className="text-xl mr-2">
                    {weatherAlertsService.getSeverityIcon(alert.event)}
                  </Text>
                  <View className="flex-1">
                    <Text className="font-semibold text-storm-50 text-sm">{alert.title}</Text>
                    <Text className="text-storm-400 text-xs capitalize mt-1">
                      {alert.severity} • Expires {alert.expires.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}
                    </Text>
                  </View>
                </View>
              </Pressable>
            ))}
          </View>
        </View>
      )}

      {/* Quick Features Access */}
      <View className="px-4 py-4">
        <Text className="text-lg font-semibold text-storm-50 mb-3">Quick Access</Text>
        <View className="grid grid-cols-2 gap-3">
          <Pressable
            onPress={() => navigation.navigate('WeatherRadar')}
            className="bg-storm-800 rounded-lg p-3 border border-storm-700 active:opacity-80"
          >
            <View className="items-center">
              <Ionicons name="radio" size={24} color="#0ea5e9" />
              <Text className="text-storm-50 font-medium mt-2">Live Radar</Text>
              <Text className="text-storm-400 text-xs">Real-time storms</Text>
            </View>
          </Pressable>
          <Pressable
            onPress={() => navigation.navigate('AIPredictions')}
            className="bg-storm-800 rounded-lg p-3 border border-storm-700 active:opacity-80"
          >
            <View className="items-center">
              <Ionicons name="bulb" size={24} color="#8b5cf6" />
              <Text className="text-storm-50 font-medium mt-2">AI Forecasts</Text>
              <Text className="text-storm-400 text-xs">Smart predictions</Text>
            </View>
          </Pressable>
          <Pressable
            onPress={() => navigation.navigate('Gamification')}
            className="bg-storm-800 rounded-lg p-3 border border-storm-700 active:opacity-80"
          >
            <View className="items-center">
              <Ionicons name="trophy" size={24} color="#f59e0b" />
              <Text className="text-storm-50 font-medium mt-2">Achievements</Text>
              <Text className="text-storm-400 text-xs">Level up chasing</Text>
            </View>
          </Pressable>
          <Pressable
            onPress={() => navigation.navigate('Features')}
            className="bg-gradient-to-r from-lightning-800 to-storm-800 rounded-lg p-3 border border-lightning-600 active:opacity-80"
          >
            <View className="items-center">
              <Ionicons name="apps" size={24} color="#38bdf8" />
              <Text className="text-storm-50 font-medium mt-2">All Features</Text>
              <Text className="text-lightning-300 text-xs">Explore more</Text>
            </View>
          </Pressable>
        </View>
      </View>

      {/* Current Weather Widget */}
      {currentWeather && (
        <View className="px-4">
          <Pressable
            onPress={() => navigation.navigate('Alerts')}
            className="bg-storm-800 rounded-lg p-4 border border-storm-700 mb-4"
          >
            <View className="flex-row items-center justify-between">
              <View>
                <Text className="text-storm-400 text-sm">Current Weather</Text>
                <Text className="text-storm-50 text-xl font-bold">
                  {currentWeather.temperature}°F
                </Text>
                <Text className="text-storm-300 text-sm capitalize">
                  {currentWeather.description}
                </Text>
              </View>
              <View className="items-center">
                <Text className="text-3xl mb-1">
                  {weatherAlertsService.getSeverityIcon(currentWeather.condition)}
                </Text>
                <Text className="text-storm-400 text-xs">
                  {currentWeather.windSpeed} mph
                </Text>
              </View>
            </View>
          </Pressable>
        </View>
      )}

      {/* Live Now Section */}
      <View className="px-4 py-6">
        <View className="flex-row items-center justify-between mb-4">
          <Text className="text-xl font-semibold text-storm-50">Live Now</Text>
          <Pressable 
            onPress={() => navigation.navigate('LiveStreams')}
            className="flex-row items-center"
          >
            <Text className="text-lightning-400 font-medium mr-1">View All</Text>
            <Ionicons name="chevron-forward" size={16} color="#38bdf8" />
          </Pressable>
        </View>

        {featuredStreams.length > 0 ? (
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {featuredStreams.map((stream) => {
              const chaser = chasers.find(c => c.id === stream.chaserId);
              return (
                <Pressable
                  key={stream.id}
                  onPress={() => navigation.navigate('StreamDetail', { streamId: stream.id })}
                  className="mr-4 w-72 bg-storm-800 rounded-lg shadow-lg border border-storm-700"
                >
                  <View className="p-4">
                    <View className="flex-row items-center mb-3">
                      <View className="w-12 h-12 bg-lightning-900 rounded-full items-center justify-center">
                        <Text className="text-2xl">{stream.thumbnail}</Text>
                      </View>
                      <View className="flex-1 ml-3">
                        <Text className="font-semibold text-storm-50">{chaser?.name}</Text>
                        <View className="flex-row items-center mt-1">
                          <View className="w-2 h-2 bg-lightning-400 rounded-full mr-2" />
                          <Text className="text-sm text-lightning-400 font-semibold">LIVE</Text>
                          <Text className="text-sm text-storm-300 ml-2">
                            {stream.viewers.toLocaleString()} viewers
                          </Text>
                        </View>
                      </View>
                    </View>
                    <Text className="font-medium text-storm-50 mb-2">{stream.title}</Text>
                    <Text className="text-sm text-storm-300 mb-3">{stream.description}</Text>
                    <View className="flex-row items-center">
                      <Ionicons name="location" size={14} color="#94a3b8" />
                      <Text className="text-sm text-storm-400 ml-1">{stream.location}</Text>
                    </View>
                  </View>
                </Pressable>
              );
            })}
          </ScrollView>
        ) : (
          <View className="bg-storm-800 rounded-lg p-8 items-center border border-storm-700">
            <Text className="text-6xl mb-4">🌤️</Text>
            <Text className="text-storm-300 text-center">No active storms right now</Text>
          </View>
        )}
      </View>

      {/* Storm Chasers Section */}
      <View className="px-4 py-6">
        <Text className="text-xl font-semibold text-storm-50 mb-4">Featured Chasers</Text>
        <View className="space-y-4">
          {chasers.slice(0, 5).map((chaser) => (
            <Pressable
              key={chaser.id}
              onPress={() => navigation.navigate('Profile', { chaserId: chaser.id })}
              className="bg-storm-800 rounded-lg p-4 shadow-lg border border-storm-700"
            >
              <View className="flex-row items-center">
                <View className="w-16 h-16 bg-lightning-900 rounded-full items-center justify-center">
                  <Text className="text-3xl">{chaser.avatar}</Text>
                </View>
                <View className="flex-1 ml-4">
                  <View className="flex-row items-center">
                    <Text className="font-semibold text-storm-50">{chaser.name}</Text>
                    {chaser.isLive && (
                      <View className="ml-2 px-2 py-1 bg-lightning-500 rounded-full">
                        <Text className="text-white text-xs font-medium">LIVE</Text>
                      </View>
                    )}
                  </View>
                  <View className="flex-row items-center mt-1">
                    <Ionicons name="location" size={14} color="#94a3b8" />
                    <Text className="text-sm text-storm-400 ml-1">{chaser.location}</Text>
                  </View>
                  <View className="flex-row items-center mt-2">
                    <Text className="text-sm text-storm-300">
                      {chaser.followers.toLocaleString()} followers
                    </Text>
                    <Text className="text-sm text-storm-300 ml-4">
                      {chaser.stormsCaught} storms caught
                    </Text>
                  </View>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#475569" />
              </View>
            </Pressable>
          ))}
        </View>
      </View>
    </ScrollView>
  );
}