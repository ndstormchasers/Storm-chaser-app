import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, Pressable, Alert, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useAdminStore } from '../state/admin';
import { useAuthStore } from '../state/auth';

export default function AdminDashboardScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const { user } = useAuthStore();
  const {
    isAdmin,
    stats,
    isLoading,
    error,
    checkAdminAccess,
    fetchAdminData,
    getUserStats,
    getReportStats,
  } = useAdminStore();

  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const hasAccess = checkAdminAccess(user);
    if (hasAccess) {
      fetchAdminData();
    }
  }, [user]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchAdminData();
    setRefreshing(false);
  };

  const userStats = getUserStats();
  const reportStats = getReportStats();

  if (!isAdmin) {
    return (
      <View className="flex-1 bg-storm-900 items-center justify-center" style={{ paddingTop: insets.top }}>
        <Ionicons name="shield-off" size={64} color="#64748b" />
        <Text className="text-storm-50 text-xl font-bold mt-4 mb-2">Access Denied</Text>
        <Text className="text-storm-400 text-center px-8">
          You don't have permission to access the admin dashboard.
        </Text>
        <Pressable
          onPress={() => navigation.goBack()}
          className="bg-lightning-500 py-3 px-6 rounded-lg mt-6"
        >
          <Text className="text-white font-semibold">Go Back</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <ScrollView 
      className="flex-1 bg-storm-900"
      style={{ paddingTop: insets.top }}
      refreshControl={
        <RefreshControl 
          refreshing={refreshing} 
          onRefresh={handleRefresh}
          tintColor="#0ea5e9"
        />
      }
    >
      {/* Header */}
      <View className="px-4 py-6 bg-storm-800 border-b border-storm-700">
        <View className="flex-row items-center justify-between mb-4">
          <View className="flex-1">
            <Text className="text-3xl font-bold text-storm-50">Admin Dashboard</Text>
            <Text className="text-lightning-300 mt-1">Storm Chasers Management</Text>
          </View>
          <View className="w-12 h-12 bg-lightning-500 rounded-full items-center justify-center">
            <Ionicons name="shield-checkmark" size={24} color="white" />
          </View>
        </View>
        
        {/* Back to Home Button */}
        <Pressable
          onPress={() => navigation.navigate('Home')}
          className="bg-storm-700 py-3 px-4 rounded-lg border border-storm-600"
        >
          <View className="flex-row items-center justify-center">
            <Ionicons name="home" size={20} color="#0ea5e9" />
            <Text className="text-lightning-400 font-medium ml-2">Back to Home</Text>
          </View>
        </Pressable>
      </View>

      {/* Quick Stats */}
      <View className="p-4">
        <Text className="text-storm-50 text-xl font-semibold mb-4">Overview</Text>
        
        <View className="flex-row flex-wrap">
          {/* Total Users */}
          <View className="w-1/2 pr-2 mb-4">
            <View className="bg-storm-800 rounded-lg p-4 border border-storm-700">
              <View className="flex-row items-center justify-between">
                <View>
                  <Text className="text-2xl font-bold text-storm-50">{stats.totalUsers}</Text>
                  <Text className="text-storm-400 text-sm">Total Users</Text>
                </View>
                <Ionicons name="people" size={24} color="#0ea5e9" />
              </View>
            </View>
          </View>

          {/* Active Users */}
          <View className="w-1/2 pl-2 mb-4">
            <View className="bg-storm-800 rounded-lg p-4 border border-storm-700">
              <View className="flex-row items-center justify-between">
                <View>
                  <Text className="text-2xl font-bold text-storm-50">{stats.activeUsers}</Text>
                  <Text className="text-storm-400 text-sm">Active Users</Text>
                </View>
                <Ionicons name="person-circle" size={24} color="#10b981" />
              </View>
            </View>
          </View>

          {/* Live Streams */}
          <View className="w-1/2 pr-2 mb-4">
            <View className="bg-storm-800 rounded-lg p-4 border border-storm-700">
              <View className="flex-row items-center justify-between">
                <View>
                  <Text className="text-2xl font-bold text-storm-50">{stats.activeStreams}</Text>
                  <Text className="text-storm-400 text-sm">Live Streams</Text>
                </View>
                <Ionicons name="radio" size={24} color="#ef4444" />
              </View>
            </View>
          </View>

          {/* Reports Today */}
          <View className="w-1/2 pl-2 mb-4">
            <View className="bg-storm-800 rounded-lg p-4 border border-storm-700">
              <View className="flex-row items-center justify-between">
                <View>
                  <Text className="text-2xl font-bold text-storm-50">{stats.reportsToday}</Text>
                  <Text className="text-storm-400 text-sm">Reports Today</Text>
                </View>
                <Ionicons name="flag" size={24} color="#f59e0b" />
              </View>
            </View>
          </View>
        </View>
      </View>

      {/* Quick Actions */}
      <View className="px-4 pb-4">
        <Text className="text-storm-50 text-xl font-semibold mb-4">Quick Actions</Text>
        
        <View className="space-y-3">
          <Pressable
            onPress={() => navigation.navigate('AdminUsers')}
            className="bg-storm-800 rounded-lg p-4 border border-storm-700"
          >
            <View className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                <Ionicons name="people" size={24} color="#0ea5e9" />
                <View className="ml-3">
                  <Text className="text-storm-50 font-semibold">Manage Users</Text>
                  <Text className="text-storm-400 text-sm">
                    {userStats.active} active, {userStats.suspended} suspended
                  </Text>
                </View>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#64748b" />
            </View>
          </Pressable>

          <Pressable
            onPress={() => navigation.navigate('AdminReports')}
            className="bg-storm-800 rounded-lg p-4 border border-storm-700"
          >
            <View className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                <Ionicons name="flag" size={24} color="#f59e0b" />
                <View className="ml-3">
                  <Text className="text-storm-50 font-semibold">Reports & Moderation</Text>
                  <Text className="text-storm-400 text-sm">
                    {reportStats.pending} pending, {reportStats.urgent} urgent
                  </Text>
                </View>
              </View>
              {reportStats.urgent > 0 && (
                <View className="bg-red-500 rounded-full px-2 py-1 mr-2">
                  <Text className="text-white text-xs font-bold">{reportStats.urgent}</Text>
                </View>
              )}
              <Ionicons name="chevron-forward" size={20} color="#64748b" />
            </View>
          </Pressable>

          <Pressable
            onPress={() => navigation.navigate('AdminStreams')}
            className="bg-storm-800 rounded-lg p-4 border border-storm-700"
          >
            <View className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                <Ionicons name="radio" size={24} color="#ef4444" />
                <View className="ml-3">
                  <Text className="text-storm-50 font-semibold">Stream Management</Text>
                  <Text className="text-storm-400 text-sm">
                    {stats.activeStreams} live, {stats.totalStreams} total
                  </Text>
                </View>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#64748b" />
            </View>
          </Pressable>

          <Pressable
            onPress={() => navigation.navigate('AdminAnalytics')}
            className="bg-storm-800 rounded-lg p-4 border border-storm-700"
          >
            <View className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                <Ionicons name="analytics" size={24} color="#8b5cf6" />
                <View className="ml-3">
                  <Text className="text-storm-50 font-semibold">Analytics & Reports</Text>
                  <Text className="text-storm-400 text-sm">View detailed statistics</Text>
                </View>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#64748b" />
            </View>
          </Pressable>
        </View>
      </View>

      {/* Recent Activity */}
      <View className="px-4 pb-8">
        <Text className="text-storm-50 text-xl font-semibold mb-4">Recent Activity</Text>
        
        <View className="bg-storm-800 rounded-lg border border-storm-700">
          <View className="p-4 border-b border-storm-700">
            <View className="flex-row items-center">
              <Ionicons name="person-add" size={16} color="#10b981" />
              <Text className="text-storm-300 text-sm ml-2">New user registered: @newchaser</Text>
            </View>
            <Text className="text-storm-500 text-xs mt-1">2 minutes ago</Text>
          </View>
          
          <View className="p-4 border-b border-storm-700">
            <View className="flex-row items-center">
              <Ionicons name="flag" size={16} color="#f59e0b" />
              <Text className="text-storm-300 text-sm ml-2">New report filed for inappropriate content</Text>
            </View>
            <Text className="text-storm-500 text-xs mt-1">15 minutes ago</Text>
          </View>
          
          <View className="p-4 border-b border-storm-700">
            <View className="flex-row items-center">
              <Ionicons name="radio" size={16} color="#ef4444" />
              <Text className="text-storm-300 text-sm ml-2">Stream "Tornado Alley Chase" went live</Text>
            </View>
            <Text className="text-storm-500 text-xs mt-1">1 hour ago</Text>
          </View>
          
          <View className="p-4">
            <View className="flex-row items-center">
              <Ionicons name="checkmark-circle" size={16} color="#10b981" />
              <Text className="text-storm-300 text-sm ml-2">Report resolved: User warning issued</Text>
            </View>
            <Text className="text-storm-500 text-xs mt-1">3 hours ago</Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}