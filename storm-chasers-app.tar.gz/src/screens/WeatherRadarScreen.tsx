import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Pressable, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { weatherRadarService, StormCell, LightningStrike } from '../api/weather-radar';
import { weatherAlertsService } from '../api/weather-alerts';

export default function WeatherRadarScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const [stormCells, setStormCells] = useState<StormCell[]>([]);
  const [lightningStrikes, setLightningStrikes] = useState<LightningStrike[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedCell, setSelectedCell] = useState<StormCell | null>(null);

  const loadRadarData = async () => {
    try {
      // Try to get real GPS location
      let location = null;
      try {
        location = await weatherAlertsService.getCurrentLocation();
      } catch (error) {
        console.log('Could not get GPS location, using default');
      }
      
      // Use default location if GPS fails
      if (!location) {
        location = { latitude: 35.4676, longitude: -97.5164 };
      }
      
      const [cells, strikes] = await Promise.all([
        weatherRadarService.getStormCells(location),
        weatherRadarService.getLightningStrikes(location)
      ]);
      setStormCells(cells);
      setLightningStrikes(strikes.slice(0, 20));
      
      console.log(`📍 Using your real location: ${location.latitude}, ${location.longitude}`);
    } catch (error) {
      console.error('Failed to load radar data:', error);
    }
  };

  useEffect(() => {
    loadRadarData();
    // Refresh data every 30 seconds
    const interval = setInterval(loadRadarData, 30000);
    return () => clearInterval(interval);
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadRadarData();
    setRefreshing(false);
  };

  const getIntensityColor = (intensity: string) => {
    switch (intensity) {
      case 'weak': return '#22c55e';
      case 'moderate': return '#f59e0b';
      case 'strong': return '#ef4444';
      case 'violent': return '#dc2626';
      default: return '#6b7280';
    }
  };

  const getIntensityIcon = (intensity: string) => {
    switch (intensity) {
      case 'weak': return '🟢';
      case 'moderate': return '🟡';
      case 'strong': return '🟠';
      case 'violent': return '🔴';
      default: return '⚪';
    }
  };

  return (
    <ScrollView 
      className="flex-1 bg-storm-900"
      style={{ paddingTop: insets.top }}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={onRefresh}
          tintColor="#38bdf8"
        />
      }
    >
      {/* Header */}
      <View className="px-4 py-6 bg-storm-800 border-b border-storm-700">
        <View className="flex-row items-center justify-between">
          <View>
            <Text className="text-3xl font-bold text-storm-50">Weather Radar</Text>
            <Text className="text-lightning-300 mt-1">Real-time storm tracking</Text>
          </View>
          <Pressable onPress={() => navigation.goBack()}>
            <Ionicons name="close" size={24} color="#64748b" />
          </Pressable>
        </View>
      </View>

      {/* Stats Overview */}
      <View className="px-4 py-4">
        <View className="grid grid-cols-3 gap-3">
          <View className="bg-storm-800 rounded-lg p-3 border border-storm-700">
            <Text className="text-storm-400 text-xs">Active Storms</Text>
            <Text className="text-storm-50 text-xl font-bold">{stormCells.length}</Text>
          </View>
          <View className="bg-storm-800 rounded-lg p-3 border border-storm-700">
            <Text className="text-storm-400 text-xs">Lightning (10min)</Text>
            <Text className="text-storm-50 text-xl font-bold">{lightningStrikes.length}</Text>
          </View>
          <View className="bg-storm-800 rounded-lg p-3 border border-storm-700">
            <Text className="text-storm-400 text-xs">Severe Cells</Text>
            <Text className="text-storm-50 text-xl font-bold">
              {stormCells.filter(cell => cell.intensity === 'strong' || cell.intensity === 'violent').length}
            </Text>
          </View>
        </View>
      </View>

      {/* Storm Cells */}
      <View className="px-4 pb-4">
        <Text className="text-xl font-semibold text-storm-50 mb-4">Active Storm Cells</Text>
        
        {stormCells.length > 0 ? (
          <View className="space-y-3">
            {stormCells.map((cell) => (
              <Pressable
                key={cell.id}
                onPress={() => setSelectedCell(selectedCell?.id === cell.id ? null : cell)}
                className={`bg-storm-800 rounded-lg p-4 border ${
                  selectedCell?.id === cell.id ? 'border-lightning-500' : 'border-storm-700'
                }`}
              >
                <View className="flex-row items-center justify-between mb-2">
                  <View className="flex-row items-center">
                    <Text className="text-2xl mr-3">
                      {getIntensityIcon(cell.intensity)}
                    </Text>
                    <View>
                      <Text className="font-semibold text-storm-50 capitalize">
                        {cell.intensity} Storm Cell
                      </Text>
                      <Text className="text-storm-400 text-sm">ID: {cell.id}</Text>
                    </View>
                  </View>
                  <View className="items-end">
                    <Text 
                      className="text-sm font-medium px-2 py-1 rounded-full text-white"
                      style={{ backgroundColor: getIntensityColor(cell.intensity) }}
                    >
                      {cell.intensity.toUpperCase()}
                    </Text>
                  </View>
                </View>

                <View className="flex-row items-center justify-between">
                  <View className="flex-row items-center">
                    <Ionicons name="location" size={14} color="#94a3b8" />
                    <Text className="text-storm-300 text-sm ml-1">
                      {cell.latitude.toFixed(3)}, {cell.longitude.toFixed(3)}
                    </Text>
                  </View>
                  <View className="flex-row items-center">
                    <Ionicons name="arrow-forward" size={14} color="#94a3b8" />
                    <Text className="text-storm-300 text-sm ml-1">
                      {cell.movement.direction}° at {cell.movement.speed} mph
                    </Text>
                  </View>
                </View>

                {selectedCell?.id === cell.id && (
                  <View className="mt-3 pt-3 border-t border-storm-700">
                    <Text className="text-storm-50 font-medium mb-2">Storm Attributes:</Text>
                    <View className="space-y-2">
                      <View className="flex-row items-center justify-between">
                        <Text className="text-storm-300">Mesocyclone:</Text>
                        <Text className={`font-medium ${cell.attributes.mesocyclone ? 'text-red-400' : 'text-green-400'}`}>
                          {cell.attributes.mesocyclone ? 'DETECTED' : 'None'}
                        </Text>
                      </View>
                      <View className="flex-row items-center justify-between">
                        <Text className="text-storm-300">Tornado Signature:</Text>
                        <Text className={`font-medium ${cell.attributes.tornado_vortex_signature ? 'text-red-400' : 'text-green-400'}`}>
                          {cell.attributes.tornado_vortex_signature ? 'DETECTED' : 'None'}
                        </Text>
                      </View>
                      <View className="flex-row items-center justify-between">
                        <Text className="text-storm-300">Hail Probability:</Text>
                        <Text className="text-storm-50 font-medium">
                          {(cell.attributes.hail_probability * 100).toFixed(0)}%
                        </Text>
                      </View>
                    </View>
                  </View>
                )}
              </Pressable>
            ))}
          </View>
        ) : (
          <View className="bg-storm-800 rounded-lg p-8 items-center border border-storm-700">
            <Text className="text-6xl mb-4">🌤️</Text>
            <Text className="text-storm-300 text-center">No active storm cells detected</Text>
            <Text className="text-storm-400 text-sm text-center mt-2">
              Pull down to refresh or check back later
            </Text>
          </View>
        )}
      </View>

      {/* Recent Lightning */}
      <View className="px-4 pb-6">
        <Text className="text-xl font-semibold text-storm-50 mb-4">Recent Lightning Activity</Text>
        
        {lightningStrikes.length > 0 ? (
          <View className="space-y-2">
            {lightningStrikes.slice(0, 10).map((strike) => (
              <View
                key={strike.id}
                className="bg-storm-800 rounded-lg p-3 border border-storm-700"
              >
                <View className="flex-row items-center justify-between">
                  <View className="flex-row items-center">
                    <Text className="text-xl mr-3">⚡</Text>
                    <View>
                      <Text className="text-storm-50 font-medium">
                        {strike.latitude.toFixed(3)}, {strike.longitude.toFixed(3)}
                      </Text>
                      <Text className="text-storm-400 text-sm">
                        {strike.timestamp.toLocaleTimeString()}
                      </Text>
                    </View>
                  </View>
                  <View className="items-end">
                    <Text className="text-lightning-400 font-medium">
                      {strike.intensity.toFixed(1)} kA
                    </Text>
                    <Text className="text-storm-400 text-xs capitalize">
                      {strike.type}
                    </Text>
                  </View>
                </View>
              </View>
            ))}
          </View>
        ) : (
          <View className="bg-storm-800 rounded-lg p-6 items-center border border-storm-700">
            <Text className="text-4xl mb-2">⚡</Text>
            <Text className="text-storm-300 text-center">No recent lightning detected</Text>
          </View>
        )}
      </View>
    </ScrollView>
  );
}