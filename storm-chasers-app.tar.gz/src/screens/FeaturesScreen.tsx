import React from 'react';
import { View, Text, ScrollView, Pressable, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { RootStackParamList } from '../types';

type FeaturesScreenNavigationProp = NativeStackNavigationProp<RootStackParamList>;

interface FeatureCard {
  id: string;
  title: string;
  description: string;
  icon: keyof typeof Ionicons.glyphMap;
  iconColor: string;
  bgColor: string;
  screen: string;
  badge?: string;
}

const features: FeatureCard[] = [
  {
    id: 'radar',
    title: 'Weather Radar',
    description: 'Real-time storm tracking with AI-powered cell detection',
    icon: 'radio-outline',
    iconColor: '#0ea5e9',
    bgColor: '#1e293b',
    screen: 'WeatherRadar',
    badge: 'LIVE'
  },
  {
    id: 'ai-predictions',
    title: 'AI Storm Predictions',
    description: 'Advanced atmospheric analysis and chase recommendations',
    icon: 'bulb-outline',
    iconColor: '#8b5cf6',
    bgColor: '#1e293b',
    screen: 'AIPredictions',
    badge: 'AI'
  },
  {
    id: 'gamification',
    title: 'Chase Achievements',
    description: 'Unlock achievements, earn XP, and compete on leaderboards',
    icon: 'trophy-outline',
    iconColor: '#f59e0b',
    bgColor: '#1e293b',
    screen: 'Gamification'
  },
  {
    id: 'multi-camera',
    title: 'Multi-Camera Streaming',
    description: 'Stream with multiple cameras including drone integration',
    icon: 'videocam-outline',
    iconColor: '#ef4444',
    bgColor: '#1e293b',
    screen: 'MultiCamera',
    badge: 'PRO'
  },
  {
    id: 'safety',
    title: 'Safety Center',
    description: 'Emergency contacts, SOS alerts, and safety equipment tracking',
    icon: 'shield-checkmark-outline',
    iconColor: '#10b981',
    bgColor: '#1e293b',
    screen: 'SafetyCenter'
  },
  {
    id: 'education',
    title: 'Chase Academy',
    description: 'Learn meteorology, safety, and photography with certified courses',
    icon: 'school-outline',
    iconColor: '#06b6d4',
    bgColor: '#1e293b',
    screen: 'Education'
  },
  {
    id: 'creator-economy',
    title: 'Creator Hub',
    description: 'Monetize your chasing with subscriptions and merchandise',
    icon: 'cash-outline',
    iconColor: '#22c55e',
    bgColor: '#1e293b',
    screen: 'CreatorEconomy',
    badge: 'NEW'
  },
  {
    id: 'social',
    title: 'Social Integration',
    description: 'Cross-post to all platforms and join community challenges',
    icon: 'share-social-outline',
    iconColor: '#ec4899',
    bgColor: '#1e293b',
    screen: 'SocialIntegration'
  },
  {
    id: 'route-planning',
    title: 'Route Planner',
    description: 'AI-optimized chase routes with team coordination',
    icon: 'map-outline',
    iconColor: '#3b82f6',
    bgColor: '#1e293b',
    screen: 'RoutePlanning'
  },
  {
    id: 'image-recognition',
    title: 'Storm Analysis',
    description: 'AI-powered cloud and tornado identification from photos',
    icon: 'camera-outline',
    iconColor: '#f97316',
    bgColor: '#1e293b',
    screen: 'ImageRecognition',
    badge: 'AI'
  }
];

export default function FeaturesScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<FeaturesScreenNavigationProp>();

  const handleFeaturePress = (screen: string) => {
    // Only navigate to existing screens
    const availableScreens = ['WeatherRadar', 'AIPredictions', 'Gamification'];
    
    if (availableScreens.includes(screen)) {
      // @ts-ignore - Navigate to existing screen
      navigation.navigate(screen);
    } else {
      // Show alert for screens not yet implemented
      Alert.alert(
        'Coming Soon',
        `${screen.replace(/([A-Z])/g, ' $1').trim()} feature is coming in a future update!`,
        [{ text: 'OK' }]
      );
    }
  };

  return (
    <ScrollView 
      className="flex-1 bg-storm-900"
      style={{ paddingTop: insets.top }}
    >
      {/* Header */}
      <View className="px-4 py-6 bg-storm-800 border-b border-storm-700">
        <Text className="text-3xl font-bold text-storm-50">Advanced Features</Text>
        <Text className="text-lightning-300 mt-1">Professional storm chasing tools</Text>
      </View>

      {/* Features Grid */}
      <View className="p-4">
        <View className="grid grid-cols-1 gap-4">
          {features.map((feature) => (
            <Pressable
              key={feature.id}
              onPress={() => handleFeaturePress(feature.screen)}
              className="bg-storm-800 rounded-xl p-4 border border-storm-700 active:opacity-80"
            >
              <View className="flex-row items-start">
                <View 
                  className="w-12 h-12 rounded-lg items-center justify-center mr-4"
                  style={{ backgroundColor: feature.bgColor }}
                >
                  <Ionicons 
                    name={feature.icon} 
                    size={24} 
                    color={feature.iconColor} 
                  />
                </View>
                
                <View className="flex-1">
                  <View className="flex-row items-center justify-between mb-2">
                    <Text className="text-lg font-semibold text-storm-50">
                      {feature.title}
                    </Text>
                    {feature.badge && (
                      <View className="px-2 py-1 bg-lightning-500 rounded-full">
                        <Text className="text-white text-xs font-medium">
                          {feature.badge}
                        </Text>
                      </View>
                    )}
                  </View>
                  
                  <Text className="text-storm-300 text-sm leading-5 mb-3">
                    {feature.description}
                  </Text>
                  
                  <View className="flex-row items-center">
                    <Text className="text-lightning-400 text-sm font-medium">
                      Open Feature
                    </Text>
                    <Ionicons 
                      name="chevron-forward" 
                      size={16} 
                      color="#38bdf8" 
                      style={{ marginLeft: 4 }}
                    />
                  </View>
                </View>
              </View>
            </Pressable>
          ))}
        </View>
      </View>

      {/* Premium Notice */}
      <View className="mx-4 mb-6 p-4 bg-gradient-to-r from-lightning-800 to-storm-800 rounded-xl border border-lightning-600">
        <View className="flex-row items-center mb-2">
          <Ionicons name="star" size={20} color="#fbbf24" />
          <Text className="text-lg font-semibold text-storm-50 ml-2">
            Premium Features
          </Text>
        </View>
        <Text className="text-storm-300 text-sm">
          Some features require a premium subscription for full access. Try them all with a free trial!
        </Text>
      </View>
    </ScrollView>
  );
}