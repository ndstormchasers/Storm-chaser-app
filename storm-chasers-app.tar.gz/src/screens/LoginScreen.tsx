import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, Alert, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/auth';
import { AuthStackParamList } from '../types';

type LoginScreenNavigationProp = NativeStackNavigationProp<AuthStackParamList, 'Login'>;

export default function LoginScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<LoginScreenNavigationProp>();
  const { login, isLoading } = useAuthStore();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});

  const validateForm = () => {
    const newErrors: { email?: string; password?: string } = {};

    if (!email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'Please enter a valid email';
    }

    if (!password.trim()) {
      newErrors.password = 'Password is required';
    } else if (password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleLogin = async () => {
    if (!validateForm()) return;
    
    const success = await login(email.trim(), password);
    
    if (!success) {
      Alert.alert(
        'Login Failed',
        'Please check your credentials and try again.',
        [{ text: 'OK' }]
      );
    }
  };

  return (
    <KeyboardAvoidingView 
      className="flex-1 bg-storm-900"
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView className="flex-1" style={{ paddingTop: insets.top }}>
        {/* Header */}
        <View className="px-6 pt-8 pb-6">
          <Pressable 
            onPress={() => navigation.goBack()}
            className="mb-6"
          >
            <Ionicons name="chevron-back" size={24} color="#374151" />
          </Pressable>
          
          <Text className="text-3xl font-bold text-storm-50 mb-2">Welcome Back</Text>
          <Text className="text-storm-400">Sign in to continue storm chasing</Text>
        </View>

        {/* Form */}
        <View className="px-6 space-y-6">
          {/* Email Field */}
          <View>
            <Text className="text-sm font-medium text-gray-700 mb-2">Email Address</Text>
            <View className="relative">
              <TextInput
                value={email}
                onChangeText={(text) => {
                  setEmail(text);
                  if (errors.email) setErrors(prev => ({ ...prev, email: undefined }));
                }}
                placeholder="Enter your email"
                className={`bg-gray-50 border rounded-lg px-4 py-3 pr-12 ${
                  errors.email ? 'border-red-500' : 'border-gray-300'
                }`}
                keyboardType="email-address"
                autoCapitalize="none"
                autoComplete="email"
              />
              <View className="absolute right-3 top-3">
                <Ionicons name="mail" size={20} color="#9CA3AF" />
              </View>
            </View>
            {errors.email && (
              <Text className="text-red-500 text-sm mt-1">{errors.email}</Text>
            )}
          </View>

          {/* Password Field */}
          <View>
            <Text className="text-sm font-medium text-gray-700 mb-2">Password</Text>
            <View className="relative">
              <TextInput
                value={password}
                onChangeText={(text) => {
                  setPassword(text);
                  if (errors.password) setErrors(prev => ({ ...prev, password: undefined }));
                }}
                placeholder="Enter your password"
                secureTextEntry={!showPassword}
                className={`bg-gray-50 border rounded-lg px-4 py-3 pr-12 ${
                  errors.password ? 'border-red-500' : 'border-gray-300'
                }`}
                autoComplete="password"
              />
              <Pressable
                onPress={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3"
              >
                <Ionicons 
                  name={showPassword ? "eye-off" : "eye"} 
                  size={20} 
                  color="#9CA3AF" 
                />
              </Pressable>
            </View>
            {errors.password && (
              <Text className="text-red-500 text-sm mt-1">{errors.password}</Text>
            )}
          </View>

          {/* Forgot Password */}
          <View className="items-end">
            <Pressable onPress={() => navigation.navigate('ForgotPassword')}>
              <Text className="text-red-500 font-medium">Forgot Password?</Text>
            </Pressable>
          </View>

          {/* Login Button */}
          <Pressable
            onPress={handleLogin}
            disabled={isLoading}
            className={`py-4 rounded-lg ${
              isLoading ? 'bg-gray-400' : 'bg-red-500'
            }`}
          >
            <View className="flex-row items-center justify-center">
              {isLoading && (
                <View className="mr-2">
                  <Ionicons name="hourglass" size={20} color="white" />
                </View>
              )}
              <Text className="text-white font-semibold text-lg">
                {isLoading ? 'Signing In...' : 'Sign In'}
              </Text>
            </View>
          </Pressable>

          {/* Demo Account Info */}
          <View className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-6">
            <View className="flex-row items-center mb-2">
              <Ionicons name="information-circle" size={20} color="#2563eb" />
              <Text className="text-blue-800 font-semibold ml-2">Demo Account</Text>
            </View>
            <Text className="text-blue-700 text-sm">
              Use any email address and password to sign in for the demo.
            </Text>
          </View>

          {/* Sign Up Link */}
          <View className="flex-row items-center justify-center pt-6">
            <Text className="text-gray-600">Don't have an account? </Text>
            <Pressable onPress={() => navigation.navigate('SignUp')}>
              <Text className="text-red-500 font-semibold">Sign Up</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}