import React from 'react';
import { View, Dimensions, Platform } from 'react-native';

interface WebLayoutProps {
  children: React.ReactNode;
}

export default function WebLayout({ children }: WebLayoutProps) {
  const { width } = Dimensions.get('window');
  
  if (Platform.OS !== 'web') {
    return <>{children}</>;
  }

  // Desktop layout for web
  if (width > 1024) {
    return (
      <View style={{ 
        flex: 1, 
        flexDirection: 'row',
        backgroundColor: '#0f172a',
        minHeight: '100vh' 
      }}>
        {/* Main content - constrained width for desktop */}
        <View style={{ 
          flex: 1, 
          maxWidth: 1200,
          alignSelf: 'center',
          backgroundColor: '#0f172a'
        }}>
          {children}
        </View>
      </View>
    );
  }

  // Mobile layout for web (tablet/phone)
  return (
    <View style={{ 
      flex: 1, 
      backgroundColor: '#0f172a',
      minHeight: '100vh' 
    }}>
      {children}
    </View>
  );
}